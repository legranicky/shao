# db-utils
The repository [db-utils](https://stash.zalando.net/projects/DATABASE/repos/pg_dist/) has useful tools to work
within our environment.
If you add the git directory to your path you will have `psql_` shortcuts to all the databases running on the 
legacy platform. These shortcuts all point to a `_psql_switch.sh` shell script which is a handy wrapper for
working with our databases, a few examples:

- `pg_view`: a top-like view of the PostgreSQL cluster [repository](https://github.com/zalando/pg_view)
- access to slaves
- `taillog`: show the log entries as they are coming in

        # In bash
        _psql_switch.sh --help
        # psql_fashionadvice_integration --command="SELECT current_catalog"

Another very useful tool is `niceupdate`: It can do data migrations in slices. This comes in handy if you need to
do any operation that changes a lot of data. The name is `niceupdate`, but it can also do `nicedelete` or `nicearchive`
if you write the correct queries.

# DDS
DDS is the database discovery service, providing information about our legacy systems.
You can look at it yourself [dds.zalando.net](http://dds.zalando.net)

Simple filtering can be done by applying filters to the URL:

- http://dds.zalando.net/environment/release
- http://dds.zalando.net/environment/LIVE/database/customer

Tools that use information from dds:

- zmon
- \_psql\_switch.sh
- scheduled tasks
