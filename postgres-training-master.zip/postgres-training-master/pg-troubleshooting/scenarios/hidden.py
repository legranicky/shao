from run_scenario import Scenario
import logging
import psycopg2

class Hidden(Scenario):
    """ This scenario creates a function, and allows the application user to execute it
        However, we disallow usage of the schema for the user.
        This scenario should aid in understanding the impact of search_path and permissions. """

    def prepare(self):
        conn = self.connect()
        cursor = conn.cursor()
        try:
            cursor.execute("SELECT 'trouble_fancy'::regproc")
        except psycopg2.ProgrammingError as pe:
            ## If the function does not yet exist, we create it and revoke usage on the schema
            if pe.pgcode or '' == '42883':
                conn.rollback()
                cursor.execute("CREATE FUNCTION trouble_fancy() RETURNS INTEGER LANGUAGE SQL AS $$ SELECT 1 $$;")
                cursor.execute("""
SELECT format('%I', nspname)
  FROM pg_proc AS p
  JOIN pg_namespace AS n ON (p.pronamespace=n.oid)
 WHERE p.oid='trouble_fancy'::regproc""")
                row = cursor.fetchone()
                cursor.execute("GRANT EXECUTE ON FUNCTION trouble_fancy() TO application".format(row[0]))
                cursor.execute("REVOKE USAGE ON SCHEMA {} FROM application".format(row[0]))
                conn.commit()
                cursor.close()
                conn.close()
            else:
                raise pe

    def run(self):
        conn = self.connect()
        cursor = conn.cursor()
        cursor.execute("SELECT EXISTS(SELECT FROM pg_roles WHERE rolname='application')")
        userexists = cursor.fetchone()[0]
        if not userexists:
            print("""\
You need to run the warmup scenario first.
SELECT * FROM run_scenario('warmup');""")
            return

        self.prepare()

        self.connection_params['user'] = 'application'
        try:
            self.connect().cursor().execute("SELECT trouble_fancy()")
        except psycopg2.ProgrammingError as pe:
            if pe.pgcode != '42883':
                raise pe
            print(pe.pgerror)
            return

        print("""Yeah! You solved the problem!""")

def main(**kwargs):
    Hidden(args=kwargs).run()

if __name__ == '__main__':
    main()
