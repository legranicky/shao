import os
from run_scenario import Scenario

""" This scenario breaks the target directory of the archive_command """

def main(**kwargs):
    scenario = Scenario(args=kwargs)

    waldir='/postgres/wal'
    os.remove(waldir)
    os.symlink('/dev/full', waldir)

    queries = ['SELECT pg_switch_xlog(); SELECT txid_current()' for i in range(0,32)]

    conn = scenario.connect(autocommit=True)
    scenario.perform(queries, conn=conn)

    print("""The monitoring system is showing that the pg_xlog directory is steadily increasing in size.
In the current rate you will be out of disk space in 2 hours.

Find out what is causing this and fix the issue""")

if __name__ == '__main__':
    main()
