from run_scenario import Scenario
import time
from psycopg2 import OperationalError
from random import shuffle
import datetime

class Index(Scenario):
    """This scenario tries to illustrate when an index is ignored"""

    def run(self):
        conn = self.connect(autocommit=True)
        cursor = conn.cursor()
        cursor.execute('DROP TABLE IF EXISTS trouble_index CASCADE')
        cursor.execute("""
CREATE TABLE trouble_index (
    id          serial         primary key,
    purchased   timestamptz(0) not null default now(),
    amount      integer        not null check(amount>0)
)
""")
        cursor=conn.cursor()
        cursor.execute('CREATE INDEX ON trouble_index(purchased)')
        cursor.execute("""
INSERT INTO trouble_index(purchased, amount)
SELECT now() - random() * interval '10000 days', (random()*100)::int+1
  FROM generate_series(1,1000000)
""")
        cursor.execute("""
CREATE OR REPLACE FUNCTION trouble_index_summary(days date [] default ARRAY[current_date])
RETURNS TABLE (day date,
               count bigint,
               amount bigint)
LANGUAGE SQL
AS
$BODY$
    SELECT purchased::date,
           count(*),
           sum(amount)::bigint
      FROM trouble_index
     WHERE purchased::date = ANY(days)
  GROUP BY purchased::date
$BODY$
;""")

        cursor.execute("""
CREATE OR REPLACE FUNCTION trouble_index_summary_ok(days date [] default ARRAY[current_date])
RETURNS TABLE (day date,
               count bigint,
               amount bigint)
LANGUAGE SQL
AS
$BODY$
-- By converting a date into 2 timestamps we can use an operator supported
-- by the index on trouble_index (purchased)
-- To ensure we do as little work as possible, we add a DISTINCT to reduce
-- the number of days to match against.
WITH times (min, max) AS (
    SELECT DISTINCT
           d::timestamptz,
           (d+1)::timestamptz
      FROM unnest(days) AS sub(d)
)
    SELECT purchased::date,
           count(*),
           sum(amount)::bigint
      FROM trouble_index
      JOIN times ON (purchased >= min AND purchased < max)
  GROUP BY purchased::date
$BODY$
;""")

        cursor.execute("""
CREATE OR REPLACE FUNCTION trouble_index_benchmark(
    INOUT num_dates integer default 10,
      OUT trouble_index_summary double precision,
      OUT trouble_index_summary_ok double precision
)
LANGUAGE PLPGSQL
AS
$BODY$
DECLARE
    started timestamptz;
    dates   date[];
BEGIN
    SELECT array_agg(
                current_date - (random()*10000)::int
           )
      INTO dates
      FROM generate_series(1,num_dates);

    started := clock_timestamp();
    PERFORM count(*)
       FROM trouble_index_summary(dates);
    trouble_index_summary := extract(epoch from clock_timestamp() - started);

    started := clock_timestamp();
    PERFORM count(*)
       FROM trouble_index_summary_ok(dates);
    trouble_index_summary_ok := extract(epoch from clock_timestamp() - started);
END;
$BODY$;""")

        ## Fill the shared_buffers
        cursor.execute('SELECT DISTINCT purchased::date FROM trouble_index LIMIT 100')
        rows = cursor.fetchall()
        dates = [r[0] for r in rows]

        print("""\
Below you can find some benchmark numbers. You can see how fast both functions
return results given the amount of input dates.
""")


        num_dates = [0, 1, 10, 1000, 5000, 10000]
        print("""
                                benchmark

 num_dates | trouble_index_summary | trouble_index_summary_ok | slower
-----------+-----------------------+--------------------------+--------""")
        query = """
SELECT num_dates,
       trouble_index_summary,
       trouble_index_summary_ok,
       trouble_index_summary/nullif(trouble_index_summary_ok,0)
  FROM trouble_index_benchmark(%s)
"""

        for n in num_dates:
            cursor.execute(query, (n,))
            row = cursor.fetchone()
            print('{:10d} | {:21.6f} | {:24.6f} | {:7.1f}'.format(row[0], row[1], row[2], row[3]))

        print('-----------+-----------------------+--------------------------+--------')
        print('')

        print("""\
You can now try to improve the function 'trouble_index_summary'. To run another
benchmark, use the function 'trouble_index_benchmark(num_dates)', for example:

    SELECT * FROM trouble_index_benchmark(10);
    SELECT * FROM trouble_index_benchmark(1000);

Try to get the 'trouble_index_summary' to be as fast as 'trouble_index_summary_ok'
""")

def main(**kwargs):
    Index(args=kwargs).run()

if __name__ == '__main__':
    main()
