from run_scenario import Scenario
import time
from psycopg2 import OperationalError

class Flipflop(Scenario):
    """This scenario tries to generate a table with such a distribution and limited statistics_target
       that flipping plans may be shown"""

    def prepare(self):
        cursor = self.connect().cursor()
        cursor.execute('DROP TABLE IF EXISTS trouble_flipflop CASCADE')
        cursor.execute('DROP TYPE IF EXISTS trouble_flipflop_status')
        cursor.execute('COMMIT')
        cursor.execute("CREATE TYPE trouble_flipflop_status AS ENUM ('DONE', 'PROCESSING', 'ERROR', 'QUEUED')")
        cursor.execute("CREATE TABLE trouble_flipflop (id serial primary key, status trouble_flipflop_status, value text)")
        cursor.execute("CREATE INDEX ON trouble_flipflop (status)")
        cursor.execute("CREATE INDEX ON trouble_flipflop (value)")
        cursor.execute("""CREATE VIEW view_flipflop AS
SELECT a.*
  FROM trouble_flipflop AS a
  JOIN trouble_flipflop AS b ON (a.value = b.value)
 WHERE a.status = 'PROCESSING'
""")
        cursor.execute("ALTER TABLE trouble_flipflop ALTER COLUMN id SET statistics 2")
        cursor.execute("ALTER TABLE trouble_flipflop ALTER COLUMN status SET statistics 2")
        cursor.execute("ALTER TABLE trouble_flipflop ALTER COLUMN value SET statistics 2")

        distribution = {'DONE': 1000000, 'ERROR':497900, 'QUEUED': 2000, 'PROCESSING': 100}

        for status, count in distribution.items():
            cursor.execute("""INSERT INTO trouble_flipflop (status, value)
                            SELECT %s, md5(random()::text) FROM generate_series(1,%s)""", (status, count))

    def loop(self):
        conn = self.connect(autocommit=True)
        query =  'ANALYZE trouble_flipflop'
        for i in range(0,7200):
            self.perform(query, conn=conn)
            time.sleep(1)

    def run(self):
        self.prepare()
        self.loop()

def main(**kwargs):
    Flipflop(args=kwargs).run()

if __name__ == '__main__':
    main()
