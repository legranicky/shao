from run_scenario import Scenario
import logging
import psycopg2

class Warmup(Scenario):
    """ This scenario tries to login using the user application (which doesn't exist) """

    def run(self):
        conn = self.connect()
        cursor = conn.cursor()

        self.connection_params['user'] = 'application'
        self.connect()

        print("""Yeah! You solved the problem!""")

def main(**kwargs):
    Warmup(args=kwargs).run()

if __name__ == '__main__':
    main()
