#!/usr/bin/env python
# -*- coding: utf-8 -*-

import argparse
import psycopg2
import logging
import atexit
import os

def parse_args():
    argp = argparse.ArgumentParser(description='Scenario runner', add_help=False)
    argp.add_argument('scenario', help='Which scenario to run', type=str)
    argp.add_argument('-U', '--username', dest='user', help='The PostgreSQL username', type=str)
    argp.add_argument('-p', '--port', help='The PostgreSQL port', type=str, default=os.environ.get('PGPORT','5432'))
    argp.add_argument('-h', '--host', help='The PostgreSQL host', type=str)
    argp.add_argument('-d', '--dbname', dest='dbname', help='The PostgreSQL database', type=str)
    argp.add_argument('-l', '--loglevel', help='Set the loglevel', type=str, default='warning')
    argp.add_argument('--search-path', help='Set the search path', type=str)

    return vars(argp.parse_args())

class Scenario():

    def __init__(self, args):
        self.args = args


        libpq_allowed = ['application_name', 'client_encoding', 'connect_timeout', 'dbname', 'fallback_application_name', 'gsslib', 'host', 'hostaddr', 'keepalives', 'keepalives_count', 'keepalives_idle', 'keepalives_interval', 'krbsrvname', 'options', 'password', 'port', 'requirepeer', 'requiressl', 'service', 'sslcert', 'sslcrl', 'sslkey', 'sslmode', 'sslrootcert', 'tty', 'user']
        self.connection_params = dict()
        for key in libpq_allowed:
            if key in args:
                self.connection_params[key] = self.args[key]

        if 'application_name' not in args:
            self.connection_params['application_name'] = 'Trouble generator'

    def connect(self, autocommit=False):
        conn = psycopg2.connect(**self.connection_params)
        conn.set_session(autocommit=autocommit)

        if self.args['search_path']:
            cursor = conn.cursor()
            cursor.execute("SET search_path TO {}".format(self.args['search_path']))
            cursor.close()

        return conn

    def perform(self, sql, params=[], conn=None, reraise=False):
        try:
            if conn is None:
                conn = self.connect()

            if isinstance(sql, str):
                sql = [sql]

            cursor = conn.cursor()
            for s in sql:
                cursor.execute(s, params)
        except (psycopg2.OperationalError, psycopg2.ProgrammingError) as e:
            print(e.pgerror or e)
            if reraise:
                raise e

def main():
    args = parse_args()
    logging.basicConfig(format='%(asctime)s - %(levelname)s - %(threadName)s - %(message)s', level=args['loglevel'].upper())

    scenario = args['scenario']

    os.chdir( os.path.dirname(os.path.realpath(__file__)) )

    if not os.path.isfile(scenario+'.py'):
        logging.error('Scenario "{}" does not exist'.format(args['scenario']))
        return

    try:
        run = getattr(__import__(scenario, fromlist=['main']), 'main')
        run(**args)
    except (psycopg2.OperationalError, psycopg2.ProgrammingError) as e:
        print(e.pgerror or e)
        logging.error('Running scenario {} failed'.format(args['scenario']))
        return
    except:
        logging.exception('Running scenario {} failed'.format(args['scenario']))
        return

if __name__ == '__main__':
    main()
