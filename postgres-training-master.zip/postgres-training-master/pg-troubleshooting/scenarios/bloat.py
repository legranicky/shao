from run_scenario import Scenario
import time
from psycopg2 import OperationalError
from random import shuffle
import datetime

class Bloat(Scenario):
    """This scenario tries to illustrate when an index is ignored"""

    def run(self):
        conn = self.connect(autocommit=True)
        cursor = conn.cursor()
        cursor.execute('DROP TABLE IF EXISTS trouble_bloat CASCADE')
        cursor.execute("""
CREATE TABLE trouble_bloat (
    id          serial primary key,
    purchased   timestamptz not null
)
""")
        cursor=conn.cursor()
        cursor.execute('CREATE INDEX ON trouble_bloat(purchased)')
        cursor.execute("""
INSERT INTO trouble_bloat(purchased)
SELECT now() - random() * interval '20000 days'
  FROM generate_series(1,1000000) AS sub(i)
""")

        ## WE make sure the last row is the only one still in the table
        ## Vacuum is unable to reclaim space because of this
        cursor.execute('delete from trouble_bloat where ctid < (SELECT max(ctid) FROM trouble_bloat)')
        cursor.execute('UPDATE trouble_bloat SET id=1')
        cursor.execute('VACUUM ANALYZE trouble_bloat')

        print("""\
Please have a look at the table trouble_bloat:

SELECT * FROM trouble_bloat;

-- size of the table
\\\\dt+ trouble_bloat

-- size of the indexes
\\\\di+ trouble_bloat*


The size of the table and the indexes seem to be totally out of proportion for
storing just 1 row. Reduce the size of the table and indexes without dropping and
recreating the table or its constraints.
""")

def main(**kwargs):
    Bloat(args=kwargs).run()

if __name__ == '__main__':
    main()
