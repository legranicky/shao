from run_scenario import Scenario
import time
from psycopg2 import OperationalError

class Sorry(Scenario):
    """This scenario will consume all available connections and then release 1.

       This allows for troubleshooting the cluster, but it may throw people
       into investigating the wrong things as well"""

    def run(self):
        # We'll try to consume all connections
        concurrency = 20000
        conns = list()
        for i in range(0, concurrency):
            try:
                conns.append(self.connect())
            except OperationalError as e:
                if not 'sorry, too many clients already' in format(e):
                    raise e
                break
        ## We close 1 connection, to enable troubleshooting
        conns[0].close()
        time.sleep(60)

        print("""The problem has magically disappeared
please re-execute the scenario to trigger the problem again""")

def main(**kwargs):
    Sorry(args=kwargs).run()

if __name__ == '__main__':
    main()
