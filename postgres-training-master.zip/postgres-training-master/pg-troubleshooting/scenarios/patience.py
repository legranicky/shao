from run_scenario import Scenario
import threading
import time
from random import random

class Patience(Scenario):
    """ This scenario creates sessions that are blocking eachother. Killing the most obvious connection
        will not solve the issue, as the sessions are waiting upon eachother"""

    def prepare(self):
        queries = ['DROP TABLE IF EXISTS trouble_patience',
                   'CREATE TABLE trouble_patience(id serial primary key, value text not null)',
                   'CREATE UNIQUE INDEX ON trouble_patience(lower(value))',
                   'COMMIT',
                   "INSERT INTO trouble_patience (value) VALUES ('0')",
                   'SELECT pg_sleep(600)']
        self.perform(queries)

    def run(self):
        concurrency = 20

        threads = list()
        threads.append( threading.Thread(target=self.prepare) )

        queries = ['SELECT pg_sleep(%(sleep)s)',
                   'INSERT INTO trouble_patience (value) VALUES (%(id)s)',
                   'INSERT INTO trouble_patience (value) VALUES (%(block)s)',
                   'SELECT pg_sleep(10)']

        for i in range(0, concurrency):
            params = {'sleep': i*0.1,
                      'id': str(i),
                      'block': str(int(random()*i))}
            threads.append( threading.Thread(target=self.perform, args=(queries, params)) )

        for t in threads:
            t.daemon = True
            t.start()


def main(**kwargs):
    Patience(args=kwargs).run()
    sleep = 600
    time.sleep(sleep)

if __name__ == '__main__':
    main()
