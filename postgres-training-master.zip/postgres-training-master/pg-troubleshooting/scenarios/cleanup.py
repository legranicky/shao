from run_scenario import Scenario
import os

def main(**kwargs):
    scenario = Scenario(args=kwargs)
    conn = scenario.connect()
    cursor = conn.cursor()
    cursor.execute("""
            WITH ids AS (
                            SELECT *
                              FROM pg_stat_activity
                             WHERE application_name='Trouble generator'
                               AND pid <> pg_backend_pid()
                        )
                        SELECT *, pg_terminate_backend(pid)
                          FROM ids""")

    cursor.execute('DROP function IF EXISTS trouble_fancy()')
    conn.commit()

    ## Restore correct symlink for waldirectory
    waldir='/postgres/wal'
    if os.path.islink(waldir):
        os.remove(waldir)
        os.symlink('/dev/null', waldir)



if __name__ == '__main__':
    main()
