# Situation

Before reading the situation, start the scenario, as it may take a minute to setup.

**psql**
```sql
SELECT run_scenario('flipflop');
```

In your company, many packages are sent everyday. The status of the package is recorded in the table
`trouble_flipflop`. Normally the queries that hit this table are fast (< 1ms). But since last night, sometimes
it happens that some (not all) queries take almost a second. If these queries run this long it means labels
are not printed, packages are not sent and revenue is lost.

You need to keep this scenario running during troubleshooting, after you fixed the issue, you can cancel the query.

# Troubleshooting
One of the applications that is reported as having problems is always consulting the view `view_flipflop`.
To troubleshoot this yourself, try out the following:

**psql**
```
\timing on
SELECT count(*) FROM view_flipflop;
```
Keep repeating the query to see the behaviour change. It may take many iterations (up to 100) to see a behaviour change.

To help you in troubleshooting this further, some tools are at your disposal:

* [EXPLAIN](http://www.postgresql.org/docs/current/static/sql-explain.html)

## Hints
These hints are here to help you out if you are stuck. We advise you not to use them until you are stuck.

1. [hint](https://sql-intermediate.acid.zalan.do/explain/)
1. [hint](http://www.postgresql.org/docs/current/static/view-pg-stats.html)
2. [hint](http://www.postgresql.org/docs/current/static/runtime-config-query.html)
3. [hint](http://www.postgresql.org/docs/current/static/sql-altertable.html#AEN69653)
4. [search for the word 'alternatively'](http://www.postgresql.org/docs/current/static/sql-altertable.html#AEN69653)
5. [Solution](solutions/#flipflop)

# Verification
Ensure that the time it takes to query `view_flipflop` is always below 10ms.
