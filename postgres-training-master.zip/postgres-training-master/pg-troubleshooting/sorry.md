# Sorry

**psql**
```sql
SELECT * FROM run_scenario('sorry');
```

# Situation
An application running on tens of application servers has some intermittent issues. The logfiles of the application show
the following:

```text
nested exception is java.sql.SQLException: Timed out waiting for a free available connection.
JDBC url: jdbc:postgresql:localhost:5432/training101
```
