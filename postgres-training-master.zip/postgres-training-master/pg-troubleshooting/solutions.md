# Solutions
This page holds some answers to the problems you may face. Please use these as a last resort, as by just learning the
answers, you will not learn any troubleshooting skills.

<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
# Flipflop

## Analysis
The data distribution of this table is very skewed, let's have a look at it:

**psql**
```sql
WITH numbers (status, statuscount, totalcount) AS (
    SELECT status,
           count(*),
           sum(count(*)) over ()
      FROM trouble_flipflop
  GROUP BY status
)
  SELECT status,
         statuscount,
         totalcount,
         round(statuscount*100.0/totalcount,3) AS percent
    FROM numbers
ORDER BY statuscount;
```
**output**
```text
   status   | statuscount | totalcount | percent
------------+-------------+------------+---------
 PROCESSING |         100 |    1500000 |   0.007
 QUEUED     |        2000 |    1500000 |   0.133
 ERROR      |      497900 |    1500000 |  33.193
 DONE       |     1000000 |    1500000 |  66.667
```

The statistics gathered for this table do not accurately reflect the data distribution.

You can see the current distribution in the catalog for the status column like this:

**psql**
```sql
SELECT most_common_vals,
       most_common_freqs,
       histogram_bounds
  FROM pg_stats
 WHERE tablename='trouble_flipflop'
   AND attname='status';
```

Some sample output, which correlates with slow/fast plans:

* fast


         most_common_vals |  most_common_freqs  | histogram_bounds
        ------------------+---------------------+------------------
         {DONE,ERROR}     | {0.708333,0.291667} |

* slow


         most_common_vals | most_common_freqs | histogram_bounds
        ------------------+-------------------+------------------
         {DONE}           | {0.69}            | {ERROR,QUEUED}


## Solution
The current `STATISTICS TARGET` for the table `trouble_flipflop` is set very low to demonstrate the flipping of the
query plan. Therefore it sometimes happens that during statistics gathering some values are over- or
underrepresented in the sample.

**psql**
```sql
\d+ trouble_flipflop
ALTER TABLE trouble_flipflop ALTER COLUMN status SET STATISTICS -1;
\d+ trouble_flipflop
```
**output**
```text
                        Table "public.trouble_flipflop"
 Column |          Type           | Modifiers | Storage  | Stats target | Description
--------+-------------------------+-----------+----------+--------------+-------------
 id     | integer                 | [...]     | plain    | 2            |
 status | trouble_flipflop_status |           | plain    | 2            |
 value  | text                    |           | extended | 2            |
[...]
ALTER TABLE
                        Table "public.trouble_flipflop"
 Column |          Type           | Modifiers | Storage  | Stats target | Description
--------+-------------------------+-----------+----------+--------------+-------------
 id     | integer                 | [...]     | plain    | 2            |
 status | trouble_flipflop_status |           | plain    |              |
 value  | text                    |           | extended | 2            |
[...]

```

You may want to increase the statistics target to a higher value than the default for very skewed data distributions
and/or very large tables, like this:

**psql**
```sql
ALTER TABLE trouble_flipflop ALTER COLUMN status SET STATISTICS 1000;
ANALYZE trouble_flipflop;
SELECT most_common_vals,
       most_common_freqs,
       histogram_bounds
  FROM pg_stats
 WHERE tablename='trouble_flipflop'
   AND attname='status';
```
**output**
```text
        most_common_vals        |        most_common_freqs         | histogram_bounds
--------------------------------+----------------------------------+------------------
 {DONE,ERROR,QUEUED,PROCESSING} | {0.667343,0.331297,0.0013,6e-05} |
```

<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
# xlog

## Analysis

## Solution
Make sure the that the target disk for the `archive_command` can be written to. In the Docker setup, we accomplish
this by swapping a symlink:

**bash**
```bash
ls -ld /postgres/wal
rm /postgres/wal
ln -s /dev/null /postgres/wal
```
