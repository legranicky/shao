# Pending doom

The situation for this scenario will be shown in your `psql` session.

**psql**
```sql
SELECT * from run_scenario('xlog');
```
# Hidden function

You rolled out a release on the database, but now the developers complain the new application version is not
working.

**psql**
```sql
SELECT run_scenario('hidden');
```
Repeate the scenario until you have fixed the problem.

# Bloat

**psql**
```sql
select run_scenario('bloat');
```
