# Situation

Start the scenario, this may take some time to setup:

**psql**
```sql
select run_scenario('index');
```

A new service is being built, and for this service a developer wrote the function (a.k.a. sproc)
`trouble_index_summary(date[])`.

He expects the sproc to be very fast (<1ms) for a small amount of dates, but the function is slower than that:

**psql**
```sql
\timing on
SELECT count(*) FROM trouble_index_summary(ARRAY['2008-12-21','2009-12-21']::date[]);
```
**output**
```text
 count
-------
     2
(1 row)
```

# Troubleshooting
Try to find out what happens inside the sproc and use `EXPLAIN` to gather information about the execution of this
sproc. You cannot simple execute `EXPLAIN SELECT * FROM trouble_index_summary()` to find the explain plan of
the function. You will need to open up the function definition to EXPLAIN it.

To see a function definition use `\sf`

**psql**
```
\sf hello_world
```
**output**
```text
CREATE OR REPLACE FUNCTION feike.hello_world(name text)
 RETURNS text
 LANGUAGE sql
AS $function$
SELECT format('Hello, %s!', name)
$function$
```

A good way to EXPLAIN a simple SQL function would be as follows:

- get the query from the function
- use `PREPARE` to be able to bind variables
- use `EXECUTE` to execute the SQL
- use `EXPLAIN EXECUTE` to explain the query

For example:

**full session log**
```text
mydb=# PREPARE my_plan (text) AS SELECT format('Hello, %s!', $1);
PREPARE
mydb=# EXECUTE my_plan('John');
    format
--------------
 Hello, John!
(1 row)

mydb=# EXPLAIN EXECUTE my_plan('John');
                QUERY PLAN
------------------------------------------
 Result  (cost=0.00..0.01 rows=1 width=0)
(1 row)
```




- Try to tweak the query
- You can use the benchmark `trouble_index_benchmark(num_dates)` to verify your tweaks, example:


        # SELECT * FROM trouble_index_benchmark(500);
         num_dates | trouble_index_summary | trouble_index_summary_ok
        -----------+-----------------------+--------------------------
               500 |              0.293998 |                 0.007502
        (1 row)

# Hints

- The column purchased is used in the `WHERE` clause of the function
- You can try to create an index on an expression
- Last resort: There is another sproc, which is fast: `trouble_index_summary_ok(date[])`.
