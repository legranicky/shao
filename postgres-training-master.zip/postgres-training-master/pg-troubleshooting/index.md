# Introduction
This training consists of some troubleshooting exercises you can do in postgres.
Some of these issues will be related to only PostgreSQL, whereas others will be related to the environment.

# Prerequisites

- Working Docker environment
- Internet connection
- Experience in working in a terminal environment
- Finish this introduction, make sure you can verify the setup is working

# Set-up
The scenario's are part of the training Docker image. To get yourself up and running, do the following in your shell:

```bash
docker run -d --name=pg-troubleshooting registry.opensource.zalan.do/acid/postgres-training:1.0-SNAPSHOT
```

Use your `docker` tooling to stop, start or restart your container if necessary.

Now test if the container is running as expected:

# Verify your setup
```bash
docker exec -ti pg-troubleshooting psql -AtX --command='SELECT current_catalog'
```

This should yield:
```text
training101
```

