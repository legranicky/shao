# What are we waiting for

**psql**
```sql
SELECT run_scenario('patience');
```

# Situation
Developers are flocking around your desk. They claim the database is frozen and demand you restart it.
Restarting is not an option however, as this cluster is serving multiple databases and many more applications which
cannot handle connection interruptions. Find out what is going on.

Hints:

- The developers are complaining about the table `trouble_patience`
