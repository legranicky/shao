# Tools

For the duration of the course you will need to do troubleshooting. This means you will need to use
all the tools you can find. To get you started, a non-exhaustive list of how to get some tools running if
you have started the Docker as described in the introduction.

* `psql`

        docker exec -ti pg-troubleshooting psql

* `bash`

        docker exec -ti pg-troubleshooting bash

* `pg_view`

        docker exec -ti pg-troubleshooting pg_view

Once you have your system up and running, it would be good to get some applications open:

1. `psql`: to execute the scenario
2. `psql`: to troubleshoot using SQL
3. `bash`: to troubleshoot on the system
4. `pg_view`: to keep a live eye on the system

Whenever we ask you to execute something it will be in a code block, like this:

**psql**
```sql
SELECT 'psql example';
```

**bash**
```bash
tail -f /postgres/data/test.log
```


# Situation
A helpdesk ticket was created to create a database. The developer is complaining that he can't connect to
the database.

**psql**
```sql
SELECT count(*) FROM run_scenario('warmup');
```

By executing the above SQL, you have run the warmup scenario. As long as the count is larger than 5, the problem
is still not solved.

Try to find out what the issue is by
looking at the PostgreSQL log files. To find out where the log files are stored you can issue the following statement:

**psql**
```sql
SELECT current_setting('log_directory');
```

This scenario is non-blocking and can be repeated at will. It may be useful to tail the latest logfile for example:
**bash**
```bash
tail -f $PGDATA/pg_log/*.csv
```

If you need more details about what happened, some scenario's will give you feedback. Instead of just counting
the output of the scenario, do a `SELECT *`:

**psql**
```sql
SELECT * FROM run_scenario('warmup');
```

# Cleanup
It may happen, if a scenario is not fully completed that some sessions are still blocking other sessions.
You can clean up in many ways yourself, but as a convenience you can call the `cleanup` scenario to do this for you:


**psql**
```sql
SELECT * FROM run_scenario('cleanup');
```

