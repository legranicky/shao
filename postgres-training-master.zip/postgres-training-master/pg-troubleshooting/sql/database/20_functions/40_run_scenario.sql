CREATE OR REPLACE FUNCTION public.run_scenario(scenario text)
RETURNS SETOF text
STRICT
LANGUAGE plpgsql
AS
$BODY$
DECLARE
    script_directory text := '/home/postgres/postgres-training/pg-troubleshooting/scenarios';
    command          text;
BEGIN

    command := format($$python "%s/run_scenario.py" -U "%s" -d "%s" "%s" --search-path '%s' 2>&1$$,
                      script_directory, session_user, current_catalog, scenario,
                      current_setting('search_path'));

    CREATE TEMPORARY TABLE output(i serial, t text);
    EXECUTE format($$COPY pg_temp.output(t) FROM PROGRAM $p$%s$p$ $$, command);
    FOR command IN
        SELECT t
          FROM pg_temp.output
      ORDER BY i ASC
    LOOP
        RETURN NEXT command;
    END LOOP;
    DROP TABLE pg_temp.output;

    RETURN;
END;
$BODY$
SECURITY DEFINER;
