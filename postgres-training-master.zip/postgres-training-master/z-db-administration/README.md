# Training about PostgreSQL Administration

We will setup and failover a PostgreSQL Database.

**The trainer** should rollout public ssh keys on itr-dbfailovertest0{1,2}.
These addresses as well as failovertest.db.zalando should be resolveable by participants via Wifi and VPN.

**Participants** should bring their laptop which has openVPN2, psql, db-utils, python, git, ssh installed.
They should have passed the DB-Deployer Training already.
Please checkout the following repositories:
- ssh://git@stash.zalando.net:7999/database/pg_dist.git
- ssh://git@stash.zalando.net:7999/database/zmon2-database-checks.git

In order to present first time you have to install dependencies

    $ npm install

The presentation mode is started then via

    $ grunt serve

Use `space` key in order to navigate to the next slide.

If you happen to install `npm` on Ubuntu, you may have to do some additional steps:

    $ npm install grunt --save-dev 

And add a link to the nodejs executable:

    $ sudo ln -s /usr/bin/nodejs /usr/bin/node
