# Agenda

Zalando Cluster Setup

Hands On

Monitoring

Questionaire



## Zalando Cluster Setup


## Overview

![cluster overview](images/cluster_setup.png)

Note:

- Block
- Data Files
- WAL
    - Recovery or REDO
    - PITR
    - Replication


## WAL

- `checkpoint` syncs shared buffers with data files
- Write Ahead Log protocols modifications of blocks
- WAL allows Recovery as well as PITR
- Standby instance is recovering
- Streaming Replication sends WAL before closing segments


WAL Shipping

![process overview](images/wal_shipping_process_overview.png "Titel")

Note:
Stop archive in case disk becomes full


Routing Interroute

![Routing in ITR](images/route_itr.jpg)



## Hands On

Build a Master

Build a Slave

Failover to Slave

Restart Old Master as Slave


## Sources

- ssh://git@stash.zalando.net:7999/database/pg_dist.git

- ssh://git@stash.zalando.net:7999/database/zmon2-database-checks.git

- [Techwiki Cluster Instance with details](https://techwiki.zalando.net/display/DT/Create+a+Database+Cluster+Instance)

- [Replication Setup](https://techwiki.zalando.net/display/DT/PG+Replication+Setup)

Note:
- find . -name "*.sql" | sort -V | xargs cat | psql_failovertest


## Build a Master

- get a service name pointing to a service ip
    - `failovertest.db.zalando`
- locally edit config.yml
- build configuration
- add a pg_hba.conf
- check in to SCM
- `ssh postgres@itr-dbfailovertest0{1,2}`
- pull on all hosts
- invoke `prepare_warm_standby.py`
- enable mutual postgres ssh acccess

Note:
- inspect the files
- remove the cluster
- mention LDAP (option in config.yml)
- observe ZMON


## Configuration

- config.yml
    - dds.zalando.net
    - Zmon
    - psql_switch
- crontab
    - `jobs/pg_assemble_crontab`

- pgbouncer
- pgq


## Sanity Checks

- mount points

  - /server/postgres
  - /data/
  - /data1

- ./git/pg_dist/bin/host_audit.sh
- CMDB settings


## Manual Failover

- Current Master
    - run `checkpoint`
    - stop cluster
    - remove service ip

- Promote Standby
    - Create triggerfile
    - add service ip



## Monitoring

- https://zmon2.zalando.net/#/dashboards/view/37
- `pg_view`
- `pg_taillog`
- `pg_badger`
- Pgobserver
  - Performance Issues
  - Blocking
  - Bloated Tables
  - Background Writer

- Logdb


## ZMON System information

- Important Alerts for Check for cluster instance system information
    - XLOG partition
    - DATA partition size
    - Free Memory
    - Fast growing load
    - High load


## ZMON Instance information

- Important Alerts for Check for cluster instance information
    - No database connection
    - Master and slave mode matches config
    - Free connection count
    - Idle Connection
    - Oldest transaction age
    - WAL archiving is temporary disabled
    - WAL delay to master instance



## Questionaire

- How can you check whether or not you are connected to the slave?

- In which database `zmon_utils` shall be installed?

- How do you check which service IP address is assigned to your system?

- What is the path to the WAL file archive directory?

- What has to be done to increase the `shared_buffers`?


## Questionaire 2

- Why should we execute a `checkpoint` before shutting down a cluster?

- What has to be executed to promote a standby database?

- Why is it necessary that postgres listens to `'*'`?

- Which command do you use in order to kill a session?

