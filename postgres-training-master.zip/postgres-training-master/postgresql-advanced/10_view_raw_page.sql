CREATE OR REPLACE FUNCTION view_raw_page(relname text, blkno int, maxwidth int default 32, bytesperchar int default 8)
RETURNS TABLE(id smallint, raw_page text, from_byte integer, to_byte integer)
LANGUAGE plpgsql
AS
$body$
DECLARE
    block           bytea;
    blocksize       int;
    hexblock        text;
    width           int;
    height          int;
    blockchar       text;
    nullstring      text := '00';
BEGIN
    block    := get_raw_page(relname, blkno);
    hexblock := encode(block,'hex');
    width := maxwidth;

    -- Get dimensions
    blocksize   := length(block);
    height      := ceil(blocksize::real/width/bytesperchar);

    WHILE bytesperchar*2 > length(nullstring) LOOP
        nullstring := nullstring || '00';
    END LOOP;


    to_byte := 0;
    FOR h in 1..height LOOP
        raw_page := '';
        id := h;
        from_byte := to_byte+1;
        to_byte := least(h*width*bytesperchar,blocksize);
        FOR j in 1..width LOOP
            blockchar := substr(hexblock,1,bytesperchar*2);
            hexblock  := substr(hexblock,bytesperchar*2+1);

            IF nullstring = blockchar THEN
                raw_page := raw_page||' ';
            ELSIF length(blockchar)=0 THEN
                raw_page := raw_page||'.';
            ELSE
                raw_page := raw_page||'X';
            END IF;

        END LOOP;
        return next;
    END LOOP;

    return;
END;
$body$
;