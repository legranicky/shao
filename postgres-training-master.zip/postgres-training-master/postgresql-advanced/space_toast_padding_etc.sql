

CREATE TABLE space (
    s_id integer,
    s_created timestamptz,
    s_count bigint
);

\dt+ space

INSERT INTO space
SELECT 1, now(), 1;

\dt+ space


CREATE TABLE text_space (
    ts_id integer,
    ts_created timestamptz,
    ts_name text
);

\dt+ text_space

-- huh?
\d+ text_space -- extended!

INSERT INTO text_space
SELECT 1, now(), 'blahblah';

\dt+ text_space


SELECT oid, datname  FROM pg_database ;
SELECT 'text_space'::regclass::oid;

-- ll base/32770/182716
-- size is 8 kB - where is the rest?
-- toast:

SELECT nspname, relname, relfilenode
  FROM pg_class
  JOIN pg_namespace n ON relnamespace = n.oid
 WHERE relname LIKE '%182716%';

-- SELECT relname, relfilenode, relnamespace::regnamespace FROM pg_class WHERE relname LIKE '%182716%'; -- for 9.5


SELECT s_id,
       pg_column_size(s_id) AS int4,
       pg_column_size(s_created) AS tstz,
       pg_column_size(s_count) AS int8
  FROM space As n;

-- 20 B versus 48:

SELECT s_id, pg_column_size(n.*) FROM space As n;


CREATE TABLE space2 (
    s_id integer,
    s_useless integer,
    s_created timestamptz,
    s_count bigint
);

INSERT INTO space2
SELECT 1, 1, now(), 1;

SELECT s_id, pg_column_size(n.*) FROM space2 As n; -- also 48 B!

INSERT INTO space2
SELECT 2, NULL, now(), 1;

INSERT INTO space2
SELECT 3, 1, NULL, 1;

INSERT INTO space2
SELECT 4, 1, now(), NULL;

SELECT s_id, pg_column_size(n.*) FROM space2 As n; -- 40 is also possible!
