\set ECHO queries

\prompt '=============== we create two very similar tables ===============' dummy

CREATE TABLE playground1 (
    p_id integer,
    p_toy_count bigint,
    p_annual_budget_in_cents integer
);

CREATE TABLE playground2 (
    p_id integer,
    p_annual_budget_in_cents integer,
    p_toy_count bigint
);

\prompt '=============== note the difference in column order ===============' dummy

\prompt '=============== we add some data to both ===============' dummy

INSERT INTO playground1 (p_id, p_annual_budget_in_cents, p_toy_count)
SELECT i, (random() * 1000000)::integer, (i % 7) + 1
  FROM generate_series(1, 10000) t(i);

INSERT INTO playground2 (p_id, p_annual_budget_in_cents, p_toy_count)
SELECT i, (random() * 1000000)::integer, (i % 7) + 1
  FROM generate_series(1, 10000) t(i);

\prompt '=============== what do we see when checking the sizes? ===============' dummy

\dt+ playground*

\prompt '=============== surprise! ===============' dummy

\echo
\echo
\echo
\echo
\echo
\echo
\echo
\echo
\echo
\echo

\prompt '=============== check the row size ===============' dummy

SELECT pg_column_size(p.*) FROM playground1 AS p LIMIT 1;
SELECT pg_column_size(p.*) FROM playground2 AS p LIMIT 1;


\prompt '=============== a look at how many rows fit into a page ===============' dummy
SELECT *, ctid
  FROM playground1
 WHERE p_id = 1;

SELECT max(ctid::text)
  FROM playground1
 WHERE ctid::text < '(1';

\prompt '=============== compare this with the other playground ===============' dummy

SELECT max(ctid::text)
  FROM playground2
 WHERE ctid::text < '(1';

\prompt '=============== That''s because of padding ===============' dummy


\prompt '=============== Let''s see what''s on our pages! ===============' dummy

TRUNCATE playground1;

INSERT INTO playground1 (p_id, p_annual_budget_in_cents, p_toy_count)
SELECT i, (random() * 1000000)::integer, (i % 7) + 1
  FROM generate_series(1, 156) t(i);

SELECT * FROM view_raw_page('playground1', 0);

\prompt '=============== How our data looks like? ===============' dummy
SELECT * FROM view_raw_page('playground1', 1); -- ERROR
\prompt '=============== only one page ===============' dummy

INSERT INTO playground1 (p_id, p_annual_budget_in_cents, p_toy_count)
SELECT 157, (random() * 1000000)::integer, 157;

SELECT * FROM view_raw_page('playground1', 0);

\prompt '=============== The gap is filled in ===============' dummy


INSERT INTO playground1 (p_id, p_annual_budget_in_cents, p_toy_count)
SELECT 158, (random() * 1000000)::integer, 158;

INSERT INTO playground1 (p_id, p_annual_budget_in_cents, p_toy_count)
SELECT 159, (random() * 1000000)::integer, 159;

SELECT * FROM view_raw_page('playground1', 1);

\prompt '=============== New page! ===============' dummy

UPDATE playground1 SET p_toy_count = (p_id % 7) + 1 WHERE p_id = 159;

SELECT * FROM view_raw_page('playground1', 1);

UPDATE playground1 SET p_toy_count = (p_id % 7) + 1 WHERE p_id = 158;

SELECT * FROM view_raw_page('playground1', 1);

\prompt '=============== More data? only physically, but: ===============' dummy


VACUUM VERBOSE  playground1;

SELECT * FROM view_raw_page('playground1', 1);

\prompt '=============== Nothing seems to have changed ===============' dummy

UPDATE playground1 SET p_toy_count = (p_id % 7) + 1 WHERE p_id = 157;

SELECT * FROM view_raw_page('playground1', 1);

\prompt '=============== But this does not consume more space! ===============' dummy

