BEGIN;

                                    BEGIN;

SELECT * FROM my_favourite_table;
 id
────
(0 rows)

                                    INSERT INTO my_favourite_table VALUES (1);
                                    INSERT 0 1

                                    COMMIT;

SELECT * FROM my_favourite_table;
 id
────
  1

COMMIT;



BEGIN TRANSACTION ISOLATION LEVEL REPEATABLE READ ;

                                    BEGIN;

SELECT * FROM my_favourite_table;
 id
────
(0 rows)

                                    INSERT INTO my_favourite_table VALUES (1);
                                    INSERT 0 1

                                    COMMIT;

SELECT * FROM my_favourite_table;
 id
────
  1

COMMIT;



