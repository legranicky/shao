# Window functions
Documentation: [Window Functions](http://www.postgresql.org/docs/current/static/tutorial-window.html)

## Introduction
> A window function performs a calculation across a set of table rows that are somehow related to the current row.

What if we wanted to ask the following of the database:

List every city that has more than 55% of the population of cities that share the same countrycode.

Without Window Functions this would require scanning `city` once, to find the population per countrycode,
and then scanning `city` to compare these values.

Something like:

```sql
WITH countrycode_population(countrycode, population) AS (
    SELECT countrycode,
           sum(population)
      FROM city
  GROUP BY countrycode
)
SELECT city.countrycode,
       name
  FROM city
  JOIN countrycode_population ON (city.countrycode = countrycode_population.countrycode)
 WHERE city.population > .55 * countrycode_population.population;
```

# The `OVER` clause
With `Window Functions` this becomes easier to do, first we need to establish the part
*somehow related to the current row*. An important part is the `OVER` clause that is introduced:

> The OVER clause determines exactly how the rows of the query are split up for processing

It is doing this using the following clauses within the `OVER` clause

- `PARTITION BY` How should sets be grouped
- `ORDER BY` What is the order in which to determine things (What row is a *previous* row)

Let's build up to the solution starting out with a simple example:

## The window contains all rows
```sql
SELECT name,
       avg(population) OVER (),
       sum(population) OVER (),
       rank()          OVER ()
  FROM city;
```

## The window contains related rows
What if we want to see the avg(population) when comparing to the continent?:

```sql
SELECT name,
       avg(population) OVER (PARTITION BY continent),
       sum(population) OVER (PARTITION BY continent),
       rank()          OVER (PARTITION BY continent)
  FROM city;
```

To make life easier, we will now use the named `WINDOW` using the following syntax, this query
is semantically the same as the one above:

```sql
SELECT name,
       avg(population) OVER (w),
       sum(population) OVER (w),
       rank()          OVER (w)
  FROM city
WINDOW w AS (PARTITION BY continent);
```

## The window contains related rows, and has an ordering
When we add an `ORDER BY` to the `WINDOW` clause, we add meaning to the `rank()` function, but the behaviour of
`sum(population)` also changes.

```sql
SELECT name,
       avg(population) OVER (w),
       sum(population) OVER (w),
       rank()          OVER (w)
  FROM city
WINDOW w AS (PARTITION BY continent ORDER BY population DESC);
```

What if we now want to answer the original question?

- We can't use `WHERE`, as it applies to single records only
- We can't use `HAVING` as it requires `GROUP BY`
- We have to use a subquery

This would be a working example:

```sql
WITH city_population (name, population, population_pct) AS (
    SELECT name,
           population,
           population::real / sum(population) over (PARTITION BY countrycode) as population_pct
      FROM city
)
SELECT *
  FROM city_population
 WHERE population_pct > 0.55;
```

The difference between the query we started with and this subquery may not seem obvious, but some key differences:

- Without the `WINDOW` function it is scanning the `city` table twice
- Memory requirements are very different: In the last query it needs to keep much more in memory

It does not mean one query is better than the other query. It would require some investigating using `EXPLAIN` to 
pick out a **winner** when comparing these two queries.

# Combining GROUP BY and WINDOW functions

A more advanced use case of a `WINDOW` function could be to compare the amount of orders between consecutive days,
and between weeks, we will now combine `GROUP BY` with a `WINDOW` function:

```sql
  SELECT orderdate,
         count(*)                                         AS ordercount,
         count(*) - lag(count(*))    OVER (daily)         AS delta_orders_day,
         count(*) - lag(count(*), 7) OVER (daily)         AS delta_orders_week,
         sum(count(*))               OVER (monthly_asc)   AS running_total_month
    FROM orders
GROUP BY orderdate
  WINDOW daily       AS (ORDER BY orderdate),
         monthly_asc AS (PARTITION BY extract(month FROM orderdate) ORDER BY orderdate)
ORDER BY orderdate;
```

# Hands-on
1. List all the cities and rank them according to the size of the population
2. List all the cities and rank them according to the size of the population inside their country
3. Install some views and look at how different queries (with the same result) can behave very differently.

        -- it is assumed you are inside the sql directory of this course, if not, explictly add the correct path
        \i views_ordercount.sql
        SELECT *
          FROM compare_ordercount_views;

        SELECT *
          FROM compare_artificialcount_views;

4. You can investigate further by comparing the output of `EXPLAIN ANALYZE`:

        EXPLAIN ANALYZE
        SELECT *
          FROM ordercount_nowindow;

        EXPLAIN ANALYZE
        SELECT *
          FROM ordercount_recursive;

        EXPLAIN ANALYZE
        SELECT *
          FROM ordercount_window;
