# Grouping sets
Documentation: [GROUP BY clause](http://www.postgresql.org/docs/current/static/sql-select.html#SQL-GROUPBY)

## Group by
We start out with revisiting the grouping of sets. Grouping in sets is very common and very powerful if combined with
the use of aggregate functions. For example, if we wanted to know the amount of cities per country
we could use the following query:

        SELECT countrycode,
               count(*)
          FROM city
      GROUP BY countrycode;

What if we only want those countries with > 50 cities? We can't use the `WHERE` clause directly in this query
as the `WHERE` clause filters records. We can however use the `HAVING` clause if we are using `GROUP BY`:

## Having
The `HAVING` clause is similar to the `WHERE` clause: It filters. The distinction is to what it filters:

- `WHERE` filters records
- `HAVING` filters groups.

The following query shows the sum of the populations of the cities per country,
but only for countries with more than 50 cities:

        SELECT countrycode,
               sum(population)
          FROM city
      GROUP BY countrycode 
        HAVING count(*) > 50;

As you can see, the `SELECT` list and the `HAVING` clause do not necessarily need to match. The same goes
for the `GROUP BY` list and the `SELECT` list:

      SELECT avg(population)
        FROM city
    GROUP BY countrycode
      HAVING count(*) > 20;

# Hands-on

1. List only those countrycodes with less than 5 cities
2. List the continents and the amount of cities
3. List the continents in ascending order and the countries (ascending) with:
    - more than 40 cities
    - average city population > 250000
<!---
  SELECT continent,
         country.name
    FROM country
    JOIN city ON (city.countrycode = country.code)
GROUP BY continent, country.name
  HAVING count(*) > 40
         AND
         avg(city.population) > 250000
ORDER BY continent, country.name;
-->
4. List the customers that have no orders before 2004-10-01

<!---
   SELECT customers.customerid
     FROM customers
LEFT JOIN orders ON (orders.customerid = customers.customerid AND orderdate < '2004-10-01')
    WHERE orderdate IS NULL;

or

SELECT customerid
     FROM customers
LEFT JOIN orders USING (customerid)
 GROUP BY customerid
   HAVING sum(CASE WHEN orderdate < '2004-10-01' THEN 1 ELSE 0 END) = 0;

or (9.4+)

   SELECT customerid
     FROM customers
LEFT JOIN orders USING (customerid)
 GROUP BY customerid
   HAVING count(1) FILTER (WHERE orderdate < '2004-10-01') = 0;

-->
