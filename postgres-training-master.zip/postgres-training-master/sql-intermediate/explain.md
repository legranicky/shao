# Introduction
Documentation:

- [EXPLAIN](http://www.postgresql.org/docs/current/static/sql-explain.html)
- [query path](http://www.postgresql.org/docs/current/static/query-path.html)

When writing queries we are normally concerned with asking the RDBMS *what* we want, not *how* we want it to be done.
With less than trivial queries, we do however sometimes need to know *how* PostgreSQL is doing something. To do this
we can use `EXPLAIN`.

Before diving into the use of `EXPLAIN` let's quickly go through some of the stages after you transmit a query:

1. `parser`: checks syntax and builds a *query tree*
2. `rewrite system`: transforms the *query tree* if necessary with rules (example: views)
3. `planner/optimizer`: creates a *query plan* based upon the (rewritten) *query tree*
4. `executor`: Executes the generated *query plan* and returns results

The `EXPLAIN` command has 2 basic variants, with and without `ANALYZE`:

- `EXPLAIN`:
    - displays the *query plan*
    - displays estimates (rowcount, costs)
- `EXPLAIN ANALYZE`:
    - displays the *query plan*
    - displays estimates (rowcount, costs)
    - **executes** the *query plan*
    - displays **actual** (rowcount, costs)
    - displays **actual** timing

If we are only interested in *how* PostgreSQL will execute a query, an `EXPLAIN` normally is sufficient. If we however
want to see actual values an `EXPLAIN ANALYZE` needs to be executed.

# EXPLAIN
Let's begin by explaining a relatively simple query and step trough the output:

```sql
EXPLAIN
SELECT *
  FROM country;
```

The output will be looking something like this:
```
 Seq Scan on country  (cost=0.00..7.39 rows=239 width=270)
```

This plan can be divided as follows

- `Seq Scan on country`: Query plan
- `(cost=0.00..7.39 rows=239 width=270)`: Estimates
    - cost
        - 0.00: The first row will be returned with 0.00 costs
        - 7.39: The full result will cost 7.39
    - rows
        - 239: There will be 239 rows returned
    - width
        - 270: The width of 1 row is 270 bytes

# EXPLAIN ANALYZE
**NOTE**: Whenever you are using `EXPLAIN ANALYZE` you have to keep in mind you are actually executing the query.
Even though the actual result of the query is not returned to you, all side effects of any DML in the query will still
take place. Even a simple `SELECT * FROM function` can have DML being executed in the background.
Therefore it would be wise to wrap any non-trivial `EXPLAIN ANALYZE` into a transaction which is rolled back.

Let's go through the explain plan for the following query:
```sql
EXPLAIN ANALYZE
SELECT *
  FROM country
 WHERE name LIKE '%er%';
```
Example output:
```
 Seq Scan on country  (cost=0.00..7.99 rows=48 width=270) (actual time=0.019..0.071 rows=25 loops=1)
   Filter: (name ~~ '%er%'::text)
   Rows Removed by Filter: 214
```

This top node of this plan can be divided as follows

- `Seq Scan on country`: Query plan
- `(cost=0.00..7.99 rows=48 width=270)`: Estimates
    - cost
        - 0.00: The first row will be returned with 0.00 costs
        - 7.99: The full result will cost 7.99
    - rows
        - 48: There will be 48 rows returned
    - width
        - 270: The width of 1 row is 270 bytes
- `(actual time=0.010..0.051 rows=25 loops=1)`: Measured values
    - actual time
        - 0.019: The first row was returned after 0.000019 seconds
        - 0.071: The final row was returned after 0.000071 seconds
    - rows
        - 25: There were 25 rows returned
    - loops
        - 1: This subplan node was executed 1 times



# Tools
Explain plans can become harder to read once they grow in complexity and size. If we explain the following query:
```sql
SELECT creditcardtype
  FROM customers
  JOIN orders     ON (customers.customerid = orders.customerid)
  JOIN orderlines ON (orders.orderid       = orderlines.orderid)
 WHERE country = 'Germany';
```
We get the following output, which probably doesn't fit your terminal anymore:
```sql
Nested Loop  (cost=750.84..1397.22 rows=3028 width=4) (actual time=4.869..10.484 rows=2927 loops=1)
  ->  Hash Join  (cost=750.55..1021.57 rows=602 width=8) (actual time=4.815..8.022 rows=579 loops=1)
        Hash Cond: (orders.customerid = customers.customerid)
        ->  Seq Scan on orders  (cost=0.00..220.00 rows=12000 width=8) (actual time=0.005..1.551 rows=12000 loops=1)
        ->  Hash  (cost=738.00..738.00 rows=1004 width=8) (actual time=4.775..4.775 rows=1004 loops=1)
              Buckets: 1024  Batches: 1  Memory Usage: 40kB
              ->  Seq Scan on customers  (cost=0.00..738.00 rows=1004 width=8) (actual time=1.989..4.616 rows=1004 loops=1)
                    Filter: ((country)::text = 'Germany'::text)
                    Rows Removed by Filter: 18996
  ->  Index Only Scan using ix_orderlines_orderid on orderlines  (cost=0.29..0.57 rows=5 width=4) (actual time=0.003..0.004 rows=5 loops=579)
        Index Cond: (orderid = orders.orderid)
        Heap Fetches: 2927
```

2 nice tools that aid you in interpreting explain plans are:
## [explain.depesz.com](http://explain.depesz.com)
[Direct link to this output](http://explain.depesz.com/s/AZ0)
![Explain output of explain.depesz.com](explain.depesz.com.png)

The colour coding of the output shows you which part of the plan is taking a lot of time.
## [pgAdmin III](http://www.pgadmin.org/): A freely available GUI for PostgreSQL
![pgAdmin II output of explain analyze](pgadmin3.png)

The thickness of the lines show the relative costs of these steps: it is quite clear the scan on orderlines is
a cheap part of the whole plan

# Interpreting explain plans
With this `EXPLAIN ANALYZE` output we can start to actually compare some stuff, we can see the following:

- 25 actual rows
- 48 estimated rows

These kinds of estimates are normally good enough. The *query plan* that is generated will be based upon the
estimates. If these are off by a large amount (say 1-2 order of magnitudes), the plan it chooses may very well be 
a bad plan. For example:

- A nested loop is quick for a small number of rows
- A hash join is a fast method to join a large number of rows

If the estimates are correct, the planner will choose the appropriate strategy.

# Hands-on

1. `EXPLAIN` following query:
        
        SELECT orderid
          FROM orders
         WHERE totalamount > 430;

    - What happens during this query?
    - How many rows are expected to be returned?

2. `EXPLAIN ANALYZE` the query from (1)
    - How many rows were actually returned?
    - How long did the execution of the query take?

3. To see how PostgreSQL uses indexes if appropriate, we will create an index to aid
    the query we are investigating. Execute the following:

        CREATE INDEX ON orders(totalamount);
    
    And do another `EXPLAIN ANALYZE` of the same query.

    - What happens during this query?
    - How long did the execution of the query take? 

4. Statistics are the information the planner bases its decisions on. We'll create a contrived example.
    
    Let's try to `EXPLAIN ANALYZE` the following query:

        SELECT *
          FROM orders
         WHERE orderdate BETWEEN '2004-01-01' AND '2004-12-31';
          
    - how many rows does it expect to return
    - how many rows does it actually return
        
    Let us now update the table:

        UPDATE orders SET orderdate=orderdate + interval '1 year';

    Let's try to `EXPLAIN ANALYZE` the same query again.

    - how many rows does it expect to return
    - how many rows does it actually return
        
