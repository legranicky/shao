CREATE OR REPLACE FUNCTION compare_views(viewnames text[] default ARRAY[]::text[], iterations integer default 1)
RETURNS TABLE (
    viewname            name,
    duration            interval,
    queries_per_second  numeric(15,2)
)
LANGUAGE plpgsql
STRICT
AS
$BODY$
DECLARE
    started timestamptz;
BEGIN
    FOREACH viewname IN ARRAY viewnames
    LOOP
        -- warmup, not explicitly necessary, but just in case
        EXECUTE format('SELECT * FROM %I', viewname);
        started := clock_timestamp();
        FOR i IN 1..iterations LOOP
            EXECUTE format('SELECT * FROM %I', viewname);
        END LOOP;
        duration := (clock_timestamp() - started)/iterations;
        queries_per_second := ((1*iterations)/extract(epoch from duration))::numeric(15,2);
        RETURN NEXT;
    END LOOP;
END;
$BODY$;
