CREATE OR REPLACE VIEW artificialcount_window AS
      SELECT orderdate                                AS orderdate,
             count                                    AS ordercount,
             count - lag(count)    OVER (daily)       AS delta_orders_day,
             count - lag(count, 7) OVER (daily)       AS delta_orders_week,
             sum(count)            OVER (monthly_asc) AS running_total_month
        FROM artificial_order
      WINDOW daily       AS (ORDER BY orderdate),
             monthly_asc AS (PARTITION BY extract(year FROM orderdate), extract(month FROM orderdate) ORDER BY orderdate)
    ORDER BY orderdate;
