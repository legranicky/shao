CREATE OR REPLACE VIEW compare_ordercount_views AS
SELECT viewname,
       duration,
       queries_per_second
  FROM compare_views(viewnames := ARRAY['ordercount_nowindow','ordercount_recursive','ordercount_window'], iterations := 10);

CREATE OR REPLACE VIEW compare_artificialcount_views AS
SELECT viewname,
       duration,
       queries_per_second
  FROM compare_views(viewnames := ARRAY['artificialcount_nowindow','artificialcount_recursive', 'artificialcount_window'], iterations := 1);

