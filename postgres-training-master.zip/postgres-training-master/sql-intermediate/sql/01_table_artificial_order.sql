-- By doing this, random will return a repeatable sequence of random numbers
SELECT setseed(0.9870978);

CREATE TABLE artificial_order (orderdate, count) AS
        SELECT series.day::date,
               (random()*50)::int
          FROM generate_series('2000-01-01'::date, '2015-06-06', interval '1 day') AS series(day);

-- Make sure statistics are up to date
ANALYZE artificial_order;
