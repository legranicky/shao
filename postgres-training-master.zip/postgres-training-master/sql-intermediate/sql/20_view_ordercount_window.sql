CREATE OR REPLACE VIEW ordercount_window AS
      SELECT series.day::date                                           AS orderdate,
             count(orderid)                                             AS ordercount,
             count(orderid) - lag(count(orderid))    OVER (daily)       AS delta_orders_day,
             count(orderid) - lag(count(orderid), 7) OVER (daily)       AS delta_orders_week,
             sum(count(orderid))                     OVER (monthly_asc) AS running_total_month
        FROM generate_series(   (SELECT min(orderdate) FROM orders),
                                    (SELECT max(orderdate) FROM orders),
                                    interval '1 day') AS series(day)
   LEFT JOIN orders ON (series.day = orders.orderdate)
    GROUP BY series.day
      WINDOW daily       AS (ORDER BY series.day),
             monthly_asc AS (PARTITION BY extract(month FROM series.day) ORDER BY series.day)
    ORDER BY series.day;
