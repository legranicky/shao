\i ../../demo-dataset/dellstore/dellstore2-normal-1.0.sql
\i ../../demo-dataset/world/world.sql
\i views_ordercount.sql
