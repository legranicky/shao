CREATE OR REPLACE VIEW ordercount_nowindow AS
WITH grouped (orderdate, count) AS (
      SELECT series.day::date,
             count(orderid)
        FROM generate_series(   (SELECT min(orderdate) FROM orders),
                                (SELECT max(orderdate) FROM orders),
                                interval '1 day') AS series(day)
   LEFT JOIN orders ON (orders.orderdate = series.day)
    GROUP BY series.day
),  deltas(orderdate, ordercount, delta_orders_day, delta_orders_week) AS (
    SELECT base.orderdate,
           base.count,
           base.count - prevday.count,
           base.count - prevweek.count
      FROM grouped AS base
 LEFT JOIN grouped AS prevday  ON (base.orderdate -1 = prevday.orderdate)
 LEFT JOIN grouped AS prevweek ON (base.orderdate -7 = prevweek.orderdate)
)
    SELECT deltas.*,
           sum(running_total.count) AS running_total_month
      FROM deltas
 LEFT JOIN grouped AS running_total
            ON (running_total.orderdate between date_trunc('month', deltas.orderdate) AND deltas.orderdate)
  GROUP BY deltas.orderdate, ordercount, delta_orders_day, delta_orders_week
  ORDER BY deltas.orderdate;
