CREATE OR REPLACE VIEW ordercount_recursive AS
WITH RECURSIVE grouped (orderdate, count) AS (
      SELECT series.day::date,
             count(orders.orderid)
        FROM generate_series(   (SELECT min(orderdate) FROM orders),
                                (SELECT max(orderdate) FROM orders),
                                interval '1 day') AS series(day)
   LEFT JOIN orders ON (series.day::date = orders.orderdate)
    GROUP BY series.day::date
),  walkthrough (orderdate, count, prevcounts, running_total) AS (
    SELECT orderdate,
           count,
           ARRAY[null,null,null,null,null,null,null]::bigint[],
           count
      FROM grouped
     WHERE orderdate = (SELECT min(orderdate) FROM grouped)
    UNION ALL
    SELECT next.orderdate,
           next.count,
           prev.count || prev.prevcounts[1:6],
           CASE
                WHEN date_trunc('month', next.orderdate)::date = next.orderdate
                THEN next.count
                ELSE prev.running_total + next.count
           END
      FROM walkthrough AS prev
      JOIN grouped     AS next ON (prev.orderdate + 1 = next.orderdate)
)
SELECT orderdate,
       count                 AS ordercount,
       count - prevcounts[1] AS delta_orders_day,
       count - prevcounts[7] AS delta_orders_week,
       running_total         AS running_total_month
  FROM walkthrough;
