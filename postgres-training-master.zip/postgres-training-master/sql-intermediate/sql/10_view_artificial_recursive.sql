CREATE OR REPLACE VIEW artificialcount_recursive AS 
WITH RECURSIVE walkthrough (orderdate, count, prevcounts, running_total) AS (
    SELECT orderdate,
           count,
           ARRAY[null,null,null,null,null,null,null]::bigint[],
           count
      FROM artificial_order
     WHERE orderdate = (SELECT min(orderdate) FROM artificial_order)
    UNION ALL
    SELECT next.orderdate,
           next.count,
           prev.count::bigint || prev.prevcounts[1:6],
           CASE
                WHEN date_trunc('month', next.orderdate)::date = next.orderdate
                THEN next.count
                ELSE prev.running_total + next.count
           END
      FROM walkthrough      AS prev
      JOIN artificial_order AS next ON (prev.orderdate + 1 = next.orderdate)
)
SELECT orderdate,
       count                 AS ordercount,
       count - prevcounts[1] AS delta_orders_day,
       count - prevcounts[7] AS delta_orders_week,
       running_total         AS running_total_month
  FROM walkthrough;
