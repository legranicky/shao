CREATE OR REPLACE VIEW artificialcount_nowindow AS 
WITH deltas(orderdate, ordercount, delta_orders_day, delta_orders_week) AS (
    SELECT base.orderdate,
           base.count,
           base.count - prevday.count,
           base.count - prevweek.count
      FROM artificial_order AS base
 LEFT JOIN artificial_order AS prevday  ON (base.orderdate -1 = prevday.orderdate)
 LEFT JOIN artificial_order AS prevweek ON (base.orderdate -7 = prevweek.orderdate)
)
    SELECT deltas.*,
           sum(running_total.count) AS running_total_month
      FROM deltas
 LEFT JOIN artificial_order AS running_total
            ON (running_total.orderdate between date_trunc('month', deltas.orderdate) AND deltas.orderdate)
  GROUP BY deltas.orderdate, ordercount, delta_orders_day, delta_orders_week
  ORDER BY deltas.orderdate;
