Introduction
============

This course covers the following topics:

- Having Clause
- Window functions.
- Indexes (types of indexes, multicolumn index, partial index, index and operation)
- Order by using indexes
- Reading and Understanding of Explain command
- CTE

Prerequisites
=============
For this workshop there are some strict prerequirements:

- You have a working PostgreSQL environment, version 9.3+
- You have previously completed the [sql-101 training](https://sql-101.acid.zalan.do/) or you have basic skills
with PostgreSQL
- You have basic knowledge of the `psql` commandline client
- You have a PostgreSQL cluster available for the demo
- For some Hands-on additional scripts from the repository are needed:
    [acid/postgres-training](https://github.bus.zalan.do/acid/postgres-training/tree/master/sql-intermediate/sql)

All commands that need to be executed should be executed using the `psql` tool unless otherwise stated. Other tools
(think: pgAdminIII) are not supported during the workshop,
although many tasks can be executed directly from those tools as well.

You can download the demo database from the sql-101 course:

**psql**

* Download file: [training101.backup.sql](https://sql-101.acid.zalan.do/download/training101.backup.sql)
* Detailed instructions: [https://sql-101.acid.zalan.do/psql/#create-and-fill-the-training101-database](https://sql-101.acid.zalan.do/psql/#create-and-fill-the-training101-database)

This creates the database `training101`.

**pgAdmin**

* Download file: [training101.backup](https://sql-101.acid.zalan.do/download/training101.backup)
* Detailed instructions: [https://sql-101.acid.zalan.do/pgadmin3/#creating-a-new-database](https://sql-101.acid.zalan.do/pgadmin3/#creating-a-new-database)

Please verify these conditions are met **before** this workshop commences. Approach one of the database engineers
or your mentor if you need help to meet these prerequisites.
