Dell Store 2
============

http://linux.dell.com/dvdstore/

PostgreSQL port of the Dell Store 2 database

INSTALL
-------

Execute this file in a PostgreSQL database

From the psql prompt, as a user allowed to create databases:

	CREATE DATABASE dellstore2;
	\connect dellstore2
	\i dellstore2-normal-1.0.sql
