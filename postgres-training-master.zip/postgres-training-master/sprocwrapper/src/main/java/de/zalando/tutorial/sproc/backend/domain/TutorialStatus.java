/**
 *
 */
package de.zalando.tutorial.sproc.backend.domain;

import de.zalando.typemapper.annotations.DatabaseType;


/**
 * @author  cvandrei
 */
@DatabaseType(name = "tutorial_status")
public enum TutorialStatus {

    NEW, IN_PROGRESS, SUCCESS, FAILURE;

}
