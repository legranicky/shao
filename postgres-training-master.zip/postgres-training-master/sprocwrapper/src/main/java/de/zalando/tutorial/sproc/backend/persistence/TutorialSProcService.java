/**
 *
 */
package de.zalando.tutorial.sproc.backend.persistence;

import java.util.List;

import org.springframework.jdbc.UncategorizedSQLException;

import de.zalando.sprocwrapper.SProcCall;
import de.zalando.sprocwrapper.SProcParam;
import de.zalando.sprocwrapper.SProcService;

import de.zalando.tutorial.sproc.backend.domain.DbConnectionStatus;
import de.zalando.tutorial.sproc.backend.domain.Tutorial;
import de.zalando.tutorial.sproc.backend.domain.TutorialStatus;

/**
 * @author  cvandrei
 */
@SProcService
public interface TutorialSProcService {

    /**
     * Load the id of a ztutorial_data.tutorial records based on it's name.<br/>
     * sql location = <i>database/tutorial/20_api/05_stored_procedures/20_step_01_get_id_by_name.sql</i><br/>
     * stored procedure name = <i>step_01_get_id_by_name</i>
     *
     * @param   name  not null
     *
     * @return  null if nothing is found
     *
     * @throws  IllegalArgumentException  missing or invalid input
     */
    @SProcCall
    Long step01GetIdByName(@SProcParam String name);

    /**
     * Load a ztutorial_data.tutorial record with all it's columns. The mapping to {@link Tutorial} is done
     * automatically by sproc wraper.<br/>
     * sql location = <i>database/tutorial/20_api/05_stored_procedures/20_step_02_get_record_by_name.sql</i><br/>
     * stored procedure name = <i>step_02_get_record_by_name</i>
     *
     * @param   name  not null
     *
     * @return  null if nothing is found
     *
     * @throws  IllegalArgumentException  missing or invalid input
     */
    @SProcCall
    Tutorial step02GetRecordByName(@SProcParam String name);

    /**
     * Load the {@link TutorialStatus} (as string) for to the given name.<br/>
     * sql location = <i>database/tutorial/20_api/05_stored_procedures/20_step_03_get_status_by_name.sql</i><br/>
     * stored procedure name = <i>step_03_get_status_by_name</i>
     *
     * @param   name  not null
     *
     * @return  null if nothing is found
     *
     * @throws  IllegalArgumentException  missing or invalid input
     */
    @SProcCall
    String step03GetStatusStringByName(@SProcParam String name);

    /**
     * Load the {@link TutorialStatus} for to the given name.<br/>
     * sql location = <i>database/tutorial/20_api/05_stored_procedures/20_step_03_get_status_by_name.sql</i><br/>
     * stored procedure name = <i>step_03_get_status_by_name</i>
     *
     * @param   name  not null
     *
     * @return  null if nothing is found
     *
     * @throws  IllegalArgumentException  missing or invalid input
     */
    TutorialStatus step03GetStatusByName(String name);

    /**
     * Insert a record into table "tutorial" with the given name.<br/>
     * sql location = <i>database/tutorial/20_api/05_stored_procedures/20_step_04_insert_tutorial.sql</i><br/>
     * stored procedure name = <i>step_04_insert_tutorial</i>
     *
     * @param   name  not null
     *
     * @throws  IllegalArgumentException  missing or invalid input
     */
    @SProcCall
    void step04InsertTutorial(@SProcParam String name);

    /**
     * Updates a ztutorial_data.tutorial record (identified by it's name) with the given status.<br/>
     * sql location = <i>database/tutorial/20_api/05_stored_procedures/20_step_05_update_tutorial_status.sql</i><br/>
     * stored procedure name = <i>step_05_update_tutorial_status</i>
     *
     * @param   name    not null
     * @param   status  not null
     *
     * @throws  IllegalArgumentException   missing or invalid input
     * @throws  UncategorizedSQLException  found no record with given name
     */
    @SProcCall
    void step05UpdateTutorialStatus(@SProcParam String name, @SProcParam TutorialStatus status);

    /**
     * Selects the names of all ztutorial_data.tutorial records with {@link TutorialStatus#NEW} and updates it to
     * {@link TutorialStatus#IN_PROGRESS}. The last modified date is updated well.<br/>
     * sql location = <i>
     * database/tutorial/20_api/05_stored_procedures/20_step_06_select_status_new_and_update_to_in_progress.sql</i><br/>
     * stored procedure name = <i>step_06_select_status_new_and_update_to_in_progress</i>
     *
     * @return  never null; empty if no records with status NEW have been found
     */
    @SProcCall
    List<String> step06SelectStatusNewAndUpdateToInProgress();

    @SProcCall
    void step07Sharding();

    @SProcCall
    Long getBackendId();

    @SProcCall
    DbConnectionStatus getConnectionStatus();

    @SProcCall
    DbConnectionStatus getConnectionStatusAndWait();
}
