package de.zalando.tutorial.sproc.backend.domain;

import de.zalando.typemapper.annotations.DatabaseField;


public class DbConnectionStatus {
    @DatabaseField long backendId;
    @DatabaseField long connectionCount;

    public long getBackendId() {
        return backendId;
    }

    public void setBackendId(final Long backendId) {
        this.backendId = backendId;
    }

    public long getConnectionCount() {
        return connectionCount;
    }

    public void setConnectionCount(final Long connectionCount) {
        this.connectionCount = connectionCount;
    }

}
