/**
 *
 */
package de.zalando.tutorial.sproc.backend.persistence.impl;

import static com.google.common.base.Preconditions.checkArgument;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import org.springframework.stereotype.Service;

import de.zalando.sprocwrapper.AbstractSProcService;
import de.zalando.sprocwrapper.SProcCall;
import de.zalando.sprocwrapper.dsprovider.DataSourceProvider;

import de.zalando.tutorial.sproc.backend.domain.DbConnectionStatus;
import de.zalando.tutorial.sproc.backend.domain.Tutorial;
import de.zalando.tutorial.sproc.backend.domain.TutorialStatus;
import de.zalando.tutorial.sproc.backend.persistence.TutorialSProcService;

/**
 * @author  cvandrei
 */
@Service(TutorialSProcServiceImpl.SPRING_BEAN_NAME)
public class TutorialSProcServiceImpl extends AbstractSProcService<TutorialSProcService, DataSourceProvider>
    implements TutorialSProcService {

    public static final String SPRING_BEAN_NAME = "tutorialSProcService";

    @Autowired
    public TutorialSProcServiceImpl(@Qualifier("tutorialDataSourceProvider") final DataSourceProvider provider) {
        super(provider, TutorialSProcService.class);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Long step01GetIdByName(final String name) {

        checkArgument(name != null, "name may not be null");

        return sproc.step01GetIdByName(name);

    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Tutorial step02GetRecordByName(final String name) {

        checkArgument(name != null, "name may not be null");

        return sproc.step02GetRecordByName(name);

    }

    /**
     * {@inheritDoc}
     */
    @Override
    public String step03GetStatusStringByName(final String name) {

        checkArgument(name != null, "name may not be null");

        return sproc.step03GetStatusStringByName(name);

    }

    /**
     * {@inheritDoc}
     */
    @Override
    public TutorialStatus step03GetStatusByName(final String name) {

        final String s = step03GetStatusStringByName(name);

        return s == null ? null : TutorialStatus.valueOf(s);

    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void step04InsertTutorial(final String name) {

        checkArgument(name != null, "name may not be null");

        sproc.step04InsertTutorial(name);

    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void step05UpdateTutorialStatus(final String name, final TutorialStatus status) {

        checkArgument(name != null, "name may not be null");
        checkArgument(status != null, "status may not be null");

        sproc.step05UpdateTutorialStatus(name, status);

    }

    /**
     * {@inheritDoc}
     */
    @Override
    public List<String> step06SelectStatusNewAndUpdateToInProgress() {
        return sproc.step06SelectStatusNewAndUpdateToInProgress();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void step07Sharding() {
        sproc.step07Sharding();
    }

    @Override
    @SProcCall
    public Long getBackendId() {

        return sproc.getBackendId();
    }

    @Override
    @SProcCall
    public DbConnectionStatus getConnectionStatus() {

        return sproc.getConnectionStatus();
    }

    @Override
    @SProcCall
    public DbConnectionStatus getConnectionStatusAndWait() {

        return sproc.getConnectionStatusAndWait();
    }
}
