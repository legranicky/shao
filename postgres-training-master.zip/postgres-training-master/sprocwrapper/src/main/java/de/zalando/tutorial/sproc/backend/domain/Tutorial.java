/**
 *
 */
package de.zalando.tutorial.sproc.backend.domain;

import de.zalando.typemapper.annotations.DatabaseField;

import java.util.Date;


/**
 * @author  cvandrei
 */
public class Tutorial {

    @DatabaseField(name = "t_id")
    private Long id;

    @DatabaseField(name = "t_name")
    private String name;

    @DatabaseField(name = "t_touch_count")
    private Integer touchCount;

    @DatabaseField(name = "t_status")
    private TutorialStatus tutorialStatus;

    @DatabaseField(name = "t_created")
    private Date created;

    @DatabaseField(name = "t_modified")
    private Date modified;

    public Long getId() {
        return id;
    }

    public void setId(final Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(final String name) {
        this.name = name;
    }

    public Integer getTouchCount() {
        return touchCount;
    }

    public void setTouchCount(final Integer touchCount) {
        this.touchCount = touchCount;
    }

    public TutorialStatus getTutorialStatus() {
        return tutorialStatus;
    }

    public void setTutorialStatus(final TutorialStatus tutorialStatus) {
        this.tutorialStatus = tutorialStatus;
    }

    public Date getCreated() {
        return created;
    }

    public void setCreated(final Date created) {
        this.created = created;
    }

    public Date getModified() {
        return modified;
    }

    public void setModified(final Date modified) {
        this.modified = modified;
    }

    @Override public String toString() {
        final StringBuilder builder = new StringBuilder();
        builder.append("Tutorial [id=");
        builder.append(id);
        builder.append(", name=");
        builder.append(name);
        builder.append(", touchCount=");
        builder.append(touchCount);
        builder.append(", tutorialStatus=");
        builder.append(tutorialStatus);
        builder.append(", created=");
        builder.append(created);
        builder.append(", modified=");
        builder.append(modified);
        builder.append("]");

        return builder.toString();
    }

    @Override public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = (prime * result) +
            ((created == null) ? 0 : created.hashCode());
        result = (prime * result) + ((id == null) ? 0 : id.hashCode());
        result = (prime * result) +
            ((modified == null) ? 0 : modified.hashCode());
        result = (prime * result) + ((name == null) ? 0 : name.hashCode());
        result = (prime * result) +
            ((touchCount == null) ? 0 : touchCount.hashCode());
        result = (prime * result) +
            ((tutorialStatus == null) ? 0 : tutorialStatus.hashCode());

        return result;
    }

    @Override public boolean equals(final Object obj) {

        if (this == obj) {
            return true;
        }

        if (obj == null) {
            return false;
        }

        if (getClass() != obj.getClass()) {
            return false;
        }

        final Tutorial other = (Tutorial) obj;

        if (created == null) {

            if (other.created != null) {
                return false;
            }
        } else if (!created.equals(other.created)) {
            return false;
        }

        if (id == null) {

            if (other.id != null) {
                return false;
            }
        } else if (!id.equals(other.id)) {
            return false;
        }

        if (modified == null) {

            if (other.modified != null) {
                return false;
            }
        } else if (!modified.equals(other.modified)) {
            return false;
        }

        if (name == null) {

            if (other.name != null) {
                return false;
            }
        } else if (!name.equals(other.name)) {
            return false;
        }

        if (touchCount == null) {

            if (other.touchCount != null) {
                return false;
            }
        } else if (!touchCount.equals(other.touchCount)) {
            return false;
        }

        if (tutorialStatus != other.tutorialStatus) {
            return false;
        }

        return true;
    }

}
