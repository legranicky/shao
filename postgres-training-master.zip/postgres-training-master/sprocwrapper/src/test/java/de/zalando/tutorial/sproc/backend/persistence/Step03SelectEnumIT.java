/**
 *
 */
package de.zalando.tutorial.sproc.backend.persistence;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.jdbc.core.JdbcTemplate;

import de.zalando.tutorial.sproc.backend.domain.TutorialStatus;
import de.zalando.tutorial.sproc.base.AbstractTutorialTest;
import de.zalando.tutorial.sproc.testutil.db.TutorialTestUtil;

/**
 * @author  cvandrei
 */
public class Step03SelectEnumIT extends AbstractTutorialTest {

    @Autowired
    private TutorialSProcService tutorialSProcService;

    private JdbcTemplate jdbc;

    @Before
    public void before() {

        this.jdbc = getJdbcTemplate();

        TutorialTestUtil.deleteAll(this.jdbc);

    }

    @Test(expected = IllegalArgumentException.class)
    public void shouldNotAllowNullInput() {
        this.tutorialSProcService.step03GetStatusByName(null);
    }

    @Test
    public void shouldNotReturnRecordEmptyTable() {

        // prepare
        assertSame(0, TutorialTestUtil.all(this.jdbc).size());

        // test
        final TutorialStatus s = this.tutorialSProcService.step03GetStatusByName("foo");

        // verify
        assertNull(s);

    }

    @Test
    public void shoudlFindExactRecordByName() {

        // prepare
        assertSame(0, TutorialTestUtil.all(this.jdbc).size());

        final String name = "some name";
        assertTrue(TutorialTestUtil.insert(this.jdbc, name));

        // test
        final TutorialStatus s = this.tutorialSProcService.step03GetStatusByName(name);

        // verify
        assertNotNull(s);

    }

    @Test
    public void shouldNotFindPrefixedName() {

        // prepare
        assertSame(0, TutorialTestUtil.all(this.jdbc).size());

        final String name = "some name";
        assertTrue(TutorialTestUtil.insert(this.jdbc, name));

        // test
        final TutorialStatus s = this.tutorialSProcService.step03GetStatusByName("X" + name);

        // verify
        assertNull(s);

    }

    @Test
    public void shouldNotFindPrefixedAndPostfixedName() {

        // prepare
        assertSame(0, TutorialTestUtil.all(this.jdbc).size());

        final String name = "some name";
        assertTrue(TutorialTestUtil.insert(this.jdbc, name));

        // test
        final TutorialStatus s = this.tutorialSProcService.step03GetStatusByName("X" + name + "X");

        // verify
        assertNull(s);

    }

    @Test
    public void shouldNotFindPostfixedName() {

        // prepare
        assertSame(0, TutorialTestUtil.all(this.jdbc).size());

        final String name = "some name";
        assertTrue(TutorialTestUtil.insert(this.jdbc, name));

        // test
        final TutorialStatus s = this.tutorialSProcService.step03GetStatusByName(name + "X");

        // verify
        assertNull(s);

    }

}
