/**
 *
 */
package de.zalando.tutorial.sproc.base;

import de.zalando.testutils.mockresource.TestResourceInjectionListener;

import org.junit.runner.RunWith;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import org.springframework.context.ApplicationContext;

import org.springframework.jdbc.core.JdbcTemplate;

import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestExecutionListeners;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import javax.sql.DataSource;


/**
 * @author cvandrei
 */
@RunWith(SpringJUnit4ClassRunner.class)
@TestExecutionListeners(TestResourceInjectionListener.class)
@ContextConfiguration(locations = { "classpath:backendContextTest.xml" })
public abstract class AbstractTutorialTest {
    private final Logger tracer = LoggerFactory.getLogger(getClass().getName());

    @Autowired private ApplicationContext applicationContext;

    @Autowired
    @Qualifier("dataSourceTutorial")
    private DataSource tutorialDataSource;

    private JdbcTemplate jdbcTutorialTemplate = null;

    protected Logger getTracer() {
        return tracer;
    }

    public ApplicationContext getApplicationContext() {
        return applicationContext;
    }

    public JdbcTemplate getJdbcTemplate() {

        jdbcTutorialTemplate = new JdbcTemplate(tutorialDataSource);

        return jdbcTutorialTemplate;

    }

}
