/**
 *
 */
package de.zalando.tutorial.sproc.testutil.db;

import de.zalando.tutorial.sproc.backend.domain.Tutorial;
import de.zalando.tutorial.sproc.backend.domain.TutorialStatus;

import de.zalando.typemapper.core.TypeMapper;
import de.zalando.typemapper.core.TypeMapperFactory;

import org.springframework.jdbc.core.JdbcTemplate;

import java.util.List;


/**
 * @author  cvandrei
 */
public class TutorialTestUtil {

    private static final String TABLE = "ztutorial_data.tutorial";

    private static final TypeMapper<Tutorial> TYPE_MAPPER = TypeMapperFactory
        .createTypeMapper(Tutorial.class);

    private TutorialTestUtil() {
    }

    public static void deleteAll(final JdbcTemplate jdbc) {
        jdbc.execute("delete from " + TABLE);
    }

    public static List<Tutorial> all(final JdbcTemplate jdbc) {

        final String selectSql =
            "SELECT t_id, t_name, t_touch_count, t_status::text, t_created, t_modified FROM " +
            TABLE;

        final List<Tutorial> l = jdbc.query(selectSql, TYPE_MAPPER);

        return l;

    }

    public static Tutorial load(final JdbcTemplate jdbc, final String name) {

        final String selectSql = String.format(
                "SELECT t_id, t_name, t_touch_count, t_status::text, t_created, t_modified FROM %s WHERE t_name = '%s'",
                TABLE, name);

        final List<Tutorial> l = jdbc.query(selectSql, TYPE_MAPPER);

        final Tutorial t = ((l == null) || (l.size() == 0)) ? null : l.get(0);

        return t;

    }

    public static boolean insert(final JdbcTemplate jdbc, final String name) {

        final String insertSql = String.format(
                "INSERT INTO %s (t_name) VALUES('%s')", TABLE, name);

        final int inserted = jdbc.update(insertSql);

        return inserted == 1;

    }

    public static boolean insert(final JdbcTemplate jdbc, final String name,
        final Integer touchCount) {

        final String insertSql = String.format(
                "INSERT INTO %s (t_name, t_touch_count) VALUES('%s', %s)",
                TABLE, name, touchCount);

        final int inserted = jdbc.update(insertSql);

        return inserted == 1;

    }

    public static boolean insert(final JdbcTemplate jdbc, final String name,
        final TutorialStatus status) {

        final String insertSql = String.format(
                "INSERT INTO %s (t_name, t_status) VALUES('%s', '%s')", TABLE,
                name, status.name());

        final int inserted = jdbc.update(insertSql);

        return inserted == 1;

    }

    public static boolean insert(final JdbcTemplate jdbc, final String name,
        final Integer touchCount, final TutorialStatus status) {

        final String insertSql = String.format(
                "INSERT INTO %s (t_name, t_touch_count, t_status) VALUES('%s', %s, '%s')",
                TABLE, name, touchCount, status.name());

        final int inserted = jdbc.update(insertSql);

        return inserted == 1;

    }

    public static boolean insert(final JdbcTemplate jdbc, final Long id,
        final String name, final Integer touchCount,
        final TutorialStatus status) {

        if (name == null) {

            final String insertSql = String.format(
                    "INSERT INTO %s (t_id, t_name, t_touch_count, t_status) VALUES(%s, null, %s, '%s')",
                    TABLE, id, touchCount, status.name());

            final int inserted = jdbc.update(insertSql);

            return inserted == 1;

        } else {

            final String insertSql = String.format(
                    "INSERT INTO %s (t_id, t_name, t_touch_count, t_status) VALUES(%s, '%s', %s, '%s')",
                    TABLE, id, name, touchCount, status.name());

            final int inserted = jdbc.update(insertSql);

            return inserted == 1;

        }

    }

    public static boolean insert(final JdbcTemplate jdbc, final Long id,
        final String name, final Integer touchCount, final String status) {

        if (name == null) {

            final String insertSql = String.format(
                    "INSERT INTO %s (t_id, t_name, t_touch_count, t_status) VALUES(%s, null, %s, '%s')",
                    TABLE, id, touchCount, status);

            final int inserted = jdbc.update(insertSql);

            return inserted == 1;

        } else {

            final String insertSql = String.format(
                    "INSERT INTO %s (t_id, t_name, t_touch_count, t_status) VALUES(%s, '%s', %s, '%s')",
                    TABLE, id, name, touchCount, status);

            final int inserted = jdbc.update(insertSql);

            return inserted == 1;

        }

    }

}
