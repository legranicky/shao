/**
 *
 */
package de.zalando.tutorial.sproc.backend.persistence;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;

import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.jdbc.core.JdbcTemplate;

import de.zalando.tutorial.sproc.backend.domain.Tutorial;
import de.zalando.tutorial.sproc.backend.domain.TutorialStatus;
import de.zalando.tutorial.sproc.base.AbstractTutorialTest;
import de.zalando.tutorial.sproc.testutil.db.TutorialTestUtil;

/**
 * @author  cvandrei
 */
public class Step00CreateTableIT extends AbstractTutorialTest {

    private JdbcTemplate jdbc;

    @Before
    public void before() {

        this.jdbc = getJdbcTemplate();

        TutorialTestUtil.deleteAll(this.jdbc);

    }

    @Test
    public void emptyTable() {

        // test
        final List<Tutorial> l = TutorialTestUtil.all(this.jdbc);

        // verify
        assertSame(0, l.size());

    }

    @Test
    public void validRecord() {

        for (final TutorialStatus s : TutorialStatus.values()) {

            // prepare
            TutorialTestUtil.deleteAll(getJdbcTemplate());

            final Long id = 47L;
            final String name = "Some Random Name";
            final Integer touchCount = 23;

            // test
            assertTrue(TutorialTestUtil.insert(this.jdbc, id, name, touchCount, s));

            // verify
            final List<Tutorial> l = TutorialTestUtil.all(this.jdbc);
            assertSame(1, l.size());

            final Tutorial t = l.get(0);
            assertEquals(id, t.getId());
            assertEquals(name, t.getName());
            assertEquals(touchCount, t.getTouchCount());
            assertEquals("failed for TutorialStatus=" + s, s, t.getTutorialStatus());
            assertNotNull(t.getCreated());
            assertNotNull(t.getModified());

        }

    }

    @Test(expected = DataIntegrityViolationException.class)
    public void invalidTutorialStatus() {

        // prepare
        final Long id = 47L;
        final String name = "Some Random Name";
        final Integer touchCount = 23;
        final String status = "UNKNOWN";

        try {
            TutorialStatus.valueOf(status);
            Assert.fail("TutorialStatus is not supposed to exist: " + status);
        } catch (final IllegalArgumentException e) {
            // expected
        }

        // test
        TutorialTestUtil.insert(this.jdbc, id, name, touchCount, status);

    }

    @Test(expected = DuplicateKeyException.class)
    public void shouldNotAllowDuplicateId() {

        // prepare
        final Long id = 47L;
        final String name1 = "First Random Name";
        final String name2 = "Second Random Name";
        final Integer touchCount = 23;
        final TutorialStatus status = TutorialStatus.NEW;

        // test
        assertTrue(TutorialTestUtil.insert(this.jdbc, id, name1, touchCount, status));
        TutorialTestUtil.insert(this.jdbc, id, name2, touchCount, status);

    }

    @Test (expected = DataIntegrityViolationException.class)
    public void shouldNotAcceptNullName() {

        // prepare
        final Long id = 47L;
        final Integer touchCount = 23;
        final TutorialStatus status = TutorialStatus.NEW;

        // test
        TutorialTestUtil.insert(this.jdbc, id, null, touchCount, status);

    }

    @Test
    public void defaultTouchCount() {

        // prepare
        final String name = "Some Random Name";
        final TutorialStatus status = TutorialStatus.NEW;

        // test
        assertTrue(TutorialTestUtil.insert(this.jdbc, name, status));

        // verify
        final List<Tutorial> l = TutorialTestUtil.all(this.jdbc);
        assertSame(1, l.size());

        final Tutorial t = l.get(0);
        assertNotNull(t.getId());
        assertEquals(name, t.getName());
        assertSame(0, t.getTouchCount());
        assertEquals(status, t.getTutorialStatus());
        assertNotNull(t.getCreated());
        assertNotNull(t.getModified());

    }

    @Test
    public void defaultTutorialStatus() {

        // prepare
        final String name = "Some Random Name";
        final Integer touchCount = 23;

        // test
        assertTrue(TutorialTestUtil.insert(this.jdbc, name, touchCount));

        // verify
        final List<Tutorial> l = TutorialTestUtil.all(this.jdbc);
        assertSame(1, l.size());

        final Tutorial t = l.get(0);
        assertNotNull(t.getId());
        assertEquals(name, t.getName());
        assertEquals(touchCount, t.getTouchCount());
        assertEquals(TutorialStatus.NEW, t.getTutorialStatus());
        assertNotNull(t.getCreated());
        assertNotNull(t.getModified());

    }

    @Test
    public void idMinValue() {

        // prepare
        final Long id = Long.MIN_VALUE;
        final String name = "Some Random Name";
        final Integer touchCount = 23;
        final TutorialStatus status = TutorialStatus.NEW;

        // test
        assertTrue(TutorialTestUtil.insert(this.jdbc, id, name, touchCount, status));

        // verify
        final List<Tutorial> l = TutorialTestUtil.all(this.jdbc);
        assertSame(1, l.size());

        final Tutorial t = l.get(0);
        assertEquals(id, t.getId());
        assertEquals(name, t.getName());
        assertEquals(touchCount, t.getTouchCount());
        assertEquals(status, t.getTutorialStatus());
        assertNotNull(t.getCreated());
        assertNotNull(t.getModified());

    }

    @Test
    public void idMaxValue() {

        // prepare
        final Long id = Long.MAX_VALUE;
        final String name = "Some Random Name";
        final Integer touchCount = 23;
        final TutorialStatus status = TutorialStatus.NEW;

        // test
        assertTrue(TutorialTestUtil.insert(this.jdbc, id, name, touchCount, status));

        // verify
        final List<Tutorial> l = TutorialTestUtil.all(this.jdbc);
        assertSame(1, l.size());

        final Tutorial t = l.get(0);
        assertEquals(id, t.getId());
        assertEquals(name, t.getName());
        assertEquals(touchCount, t.getTouchCount());
        assertEquals(status, t.getTutorialStatus());
        assertNotNull(t.getCreated());
        assertNotNull(t.getModified());

    }

    @Test
    public void notUniqueTouchCount() {

        // prepare
        final String name1 = "First Random Name";
        final String name2 = "Second Random Name";
        final Integer touchCount = 23;

        // test
        assertTrue(TutorialTestUtil.insert(this.jdbc, name1, touchCount));
        assertTrue(TutorialTestUtil.insert(this.jdbc, name2, touchCount));

        // verify
        assertSame(2, TutorialTestUtil.all(this.jdbc).size());

    }

    @Test
    public void notUniqueStatus() {

        // prepare
        final String name1 = "First Random Name";
        final String name2 = "Second Random Name";
        final TutorialStatus s = TutorialStatus.FAILURE;

        // test
        assertTrue(TutorialTestUtil.insert(this.jdbc, name1, s));
        assertTrue(TutorialTestUtil.insert(this.jdbc, name2, s));

        // verify
        assertSame(2, TutorialTestUtil.all(this.jdbc).size());

    }

}
