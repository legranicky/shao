/**
 *
 */
package de.zalando.tutorial.sproc.backend.persistence;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.jdbc.UncategorizedSQLException;
import org.springframework.jdbc.core.JdbcTemplate;

import de.zalando.tutorial.sproc.backend.domain.TutorialStatus;
import de.zalando.tutorial.sproc.base.AbstractTutorialTest;
import de.zalando.tutorial.sproc.testutil.db.TutorialTestUtil;

/**
 * @author  cvandrei
 */
public class Step05UpdateIT extends AbstractTutorialTest {

    @Autowired
    private TutorialSProcService tutorialSProcService;

    private JdbcTemplate jdbc;

    @Before
    public void before() {

        this.jdbc = getJdbcTemplate();

        TutorialTestUtil.deleteAll(this.jdbc);

    }

    @Test(expected = IllegalArgumentException.class)
    public void shouldNotAllowNullInput() {
        this.tutorialSProcService.step05UpdateTutorialStatus(null, null);
    }

    @Test(expected = IllegalArgumentException.class)
    public void shouldNotAllowInputNameNull() {
        this.tutorialSProcService.step05UpdateTutorialStatus(null, TutorialStatus.IN_PROGRESS);
    }

    @Test(expected = IllegalArgumentException.class)
    public void shouldNotAllowInputStatusNull() {
        this.tutorialSProcService.step05UpdateTutorialStatus("random name", null);
    }

    @Test(expected = UncategorizedSQLException.class)
    public void shouldNotUpdateRecordDoesntExist() {

        // prepare
        assertSame(0, TutorialTestUtil.all(this.jdbc).size());

        // test
        this.tutorialSProcService.step05UpdateTutorialStatus("some name", TutorialStatus.SUCCESS);

    }

    @Test
    public void shouldUpdateExistingRecord() {

        // prepare
        assertSame(0, TutorialTestUtil.all(this.jdbc).size());

        final String name = "some name";
        final TutorialStatus originalStatus = TutorialStatus.NEW;
        final TutorialStatus newStatus = TutorialStatus.IN_PROGRESS;

        assertTrue(TutorialTestUtil.insert(this.jdbc, name, originalStatus));
        assertEquals(originalStatus, TutorialTestUtil.all(this.jdbc).get(0).getTutorialStatus());

        // test
        this.tutorialSProcService.step05UpdateTutorialStatus(name, newStatus);

        // verify
        assertEquals(newStatus, TutorialTestUtil.all(this.jdbc).get(0).getTutorialStatus());

    }

}
