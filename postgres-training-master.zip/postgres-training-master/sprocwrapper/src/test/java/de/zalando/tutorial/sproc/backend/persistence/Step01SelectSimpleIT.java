/**
 *
 */
package de.zalando.tutorial.sproc.backend.persistence;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;

import de.zalando.tutorial.sproc.base.AbstractTutorialTest;
import de.zalando.tutorial.sproc.testutil.db.TutorialTestUtil;

/**
 * @author  cvandrei
 */
public class Step01SelectSimpleIT extends AbstractTutorialTest {

    @Autowired
    private TutorialSProcService tutorialSProcService;

    private JdbcTemplate jdbc;

    @Before
    public void before() {

        this.jdbc = getJdbcTemplate();

        TutorialTestUtil.deleteAll(this.jdbc);

    }

    @Test (expected = IllegalArgumentException.class)
    public void shouldNotAcceptNullName() {
        this.tutorialSProcService.step01GetIdByName(null);
    }

    @Test
    public void shouldReturnNull4EmptyTable() {

        // prepare
        assertSame(0, TutorialTestUtil.all(this.jdbc).size());

        // test
        final Long id = this.tutorialSProcService.step01GetIdByName("foo");

        // verify
        assertNull(id);

    }

    @Test
    public void shouldFindRecordByName() {

        // prepare
        assertSame(0, TutorialTestUtil.all(this.jdbc).size());

        final String name = "some name";
        assertTrue(TutorialTestUtil.insert(this.jdbc, name));

        // test
        final Long id = this.tutorialSProcService.step01GetIdByName(name);

        // verify
        assertNotNull(id);

    }

    @Test
    public void shouldNotFindPrefixedName() {

        // prepare
        assertSame(0, TutorialTestUtil.all(this.jdbc).size());

        final String name = "some name";
        assertTrue(TutorialTestUtil.insert(this.jdbc, name));

        // test
        final Long id = this.tutorialSProcService.step01GetIdByName("X" + name);

        // verify
        assertNull(id);

    }

    @Test
    public void shouldNotFindPrefixedAndPostfixedName() {

        // prepare
        assertSame(0, TutorialTestUtil.all(this.jdbc).size());

        final String name = "some name";
        assertTrue(TutorialTestUtil.insert(this.jdbc, name));

        // test
        final Long id = this.tutorialSProcService.step01GetIdByName("X" + name + "X");

        // verify
        assertNull(id);

    }

    @Test
    public void shouldNotFindPostfixedName() {

        // prepare
        assertSame(0, TutorialTestUtil.all(this.jdbc).size());

        final String name = "some name";
        assertTrue(TutorialTestUtil.insert(this.jdbc, name));

        // test
        final Long id = this.tutorialSProcService.step01GetIdByName(name + "X");

        // verify
        assertNull(id);

    }

}
