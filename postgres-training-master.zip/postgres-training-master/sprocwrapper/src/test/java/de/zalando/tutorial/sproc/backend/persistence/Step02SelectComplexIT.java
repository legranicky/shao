/**
 *
 */
package de.zalando.tutorial.sproc.backend.persistence;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.jdbc.core.JdbcTemplate;

import de.zalando.tutorial.sproc.backend.domain.Tutorial;
import de.zalando.tutorial.sproc.base.AbstractTutorialTest;
import de.zalando.tutorial.sproc.testutil.db.TutorialTestUtil;

/**
 * @author  cvandrei
 */
public class Step02SelectComplexIT extends AbstractTutorialTest {

    @Autowired
    private TutorialSProcService tutorialSProcService;

    private JdbcTemplate jdbc;

    @Before
    public void before() {

        this.jdbc = getJdbcTemplate();

        TutorialTestUtil.deleteAll(this.jdbc);

    }

    @Test(expected = IllegalArgumentException.class)
    public void shouldNotAllowNullInput() {
        this.tutorialSProcService.step02GetRecordByName(null);
    }

    @Test
    public void shouldNotReturnRecordEmptyTable() {

        // prepare
        assertSame(0, TutorialTestUtil.all(this.jdbc).size());

        // test
        final Tutorial t = this.tutorialSProcService.step02GetRecordByName("foo");

        // verify
        assertNull(t);

    }

    @Test
    public void shoudlFindExactRecordByName() {

        // prepare
        assertSame(0, TutorialTestUtil.all(this.jdbc).size());

        final String name = "some name";
        assertTrue(TutorialTestUtil.insert(this.jdbc, name));

        // test
        final Tutorial t = this.tutorialSProcService.step02GetRecordByName(name);

        // verify
        assertNotNull(t);
        assertNotNull(t.getId());
        assertEquals(name, t.getName());

    }

    @Test
    public void shouldNotFindPrefixedName() {

        // prepare
        assertSame(0, TutorialTestUtil.all(this.jdbc).size());

        final String name = "some name";
        assertTrue(TutorialTestUtil.insert(this.jdbc, name));

        // test
        final Tutorial t = this.tutorialSProcService.step02GetRecordByName("X" + name);

        // verify
        assertNull(t);

    }

    @Test
    public void shouldNotFindPrefixedAndPostfixedName() {

        // prepare
        assertSame(0, TutorialTestUtil.all(this.jdbc).size());

        final String name = "some name";
        assertTrue(TutorialTestUtil.insert(this.jdbc, name));

        // test
        final Tutorial t = this.tutorialSProcService.step02GetRecordByName("X" + name + "X");

        // verify
        assertNull(t);

    }

    @Test
    public void shouldNotFindPostfixedName() {

        // prepare
        assertSame(0, TutorialTestUtil.all(this.jdbc).size());

        final String name = "some name";
        assertTrue(TutorialTestUtil.insert(this.jdbc, name));

        // test
        final Tutorial t = this.tutorialSProcService.step02GetRecordByName(name + "X");

        // verify
        assertNull(t);

    }

}
