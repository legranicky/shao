/**
 *
 */
package de.zalando.tutorial.sproc.backend.persistence;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertSame;

import java.util.List;

import org.junit.Before;
import org.junit.Test;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.dao.DuplicateKeyException;

import org.springframework.jdbc.core.JdbcTemplate;

import de.zalando.tutorial.sproc.backend.domain.Tutorial;
import de.zalando.tutorial.sproc.backend.domain.TutorialStatus;
import de.zalando.tutorial.sproc.base.AbstractTutorialTest;
import de.zalando.tutorial.sproc.testutil.db.TutorialTestUtil;

/**
 * @author  cvandrei
 */
public class Step04InsertIT extends AbstractTutorialTest {

    @Autowired
    private TutorialSProcService tutorialSProcService;

    private JdbcTemplate jdbc;

    @Before
    public void before() {

        this.jdbc = getJdbcTemplate();

        TutorialTestUtil.deleteAll(this.jdbc);

    }

    @Test(expected = IllegalArgumentException.class)
    public void shouldNotAllowNullInput() {
        this.tutorialSProcService.step04InsertTutorial(null);
    }

    @Test
    public void shouldAllowEmptyName() {

        // prepare
        assertSame(0, TutorialTestUtil.all(this.jdbc).size());

        final String name = "";

        // test
        this.tutorialSProcService.step04InsertTutorial(name);

        // verify
        final List<Tutorial> l = TutorialTestUtil.all(this.jdbc);
        assertSame(1, l.size());

        final Tutorial t = l.get(0);
        assertNotNull(t.getId());
        assertEquals(name, t.getName());
        assertSame(0, t.getTouchCount());
        assertEquals(TutorialStatus.NEW, t.getTutorialStatus());
        assertNotNull(t.getCreated());
        assertNotNull(t.getModified());

    }

    @Test
    public void shouldInsertNameUnmodified() {

        // prepare
        assertSame(0, TutorialTestUtil.all(this.jdbc).size());

        final String name = "random name";

        // test
        this.tutorialSProcService.step04InsertTutorial(name);

        // verify
        final List<Tutorial> l = TutorialTestUtil.all(this.jdbc);
        assertSame(1, l.size());

        final Tutorial t = l.get(0);
        assertNotNull(t.getId());
        assertEquals(name, t.getName());
        assertSame(0, t.getTouchCount());
        assertEquals(TutorialStatus.NEW, t.getTutorialStatus());
        assertNotNull(t.getCreated());
        assertNotNull(t.getModified());

    }

    @Test(expected = DuplicateKeyException.class)
    public void shouldNotAllowSameNameTwice() {

        // prepare
        assertSame(0, TutorialTestUtil.all(this.jdbc).size());

        final String name = "random name";
        this.tutorialSProcService.step04InsertTutorial(name);

        final List<Tutorial> l = TutorialTestUtil.all(this.jdbc);
        assertSame(1, l.size());

        final Tutorial t = l.get(0);
        assertEquals(name, t.getName());

        // test
        this.tutorialSProcService.step04InsertTutorial(name);

    }

}
