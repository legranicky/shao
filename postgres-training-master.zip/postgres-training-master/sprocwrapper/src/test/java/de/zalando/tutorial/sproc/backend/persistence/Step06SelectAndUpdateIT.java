/**
 *
 */
package de.zalando.tutorial.sproc.backend.persistence;

import de.zalando.tutorial.sproc.backend.domain.Tutorial;
import de.zalando.tutorial.sproc.backend.domain.TutorialStatus;
import de.zalando.tutorial.sproc.base.AbstractTutorialTest;
import de.zalando.tutorial.sproc.testutil.db.TutorialTestUtil;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.jdbc.core.JdbcTemplate;

import java.util.Date;
import java.util.List;


/**
 * @author  cvandrei
 */
public class Step06SelectAndUpdateIT extends AbstractTutorialTest {

    @Autowired private TutorialSProcService tutorialSProcService;

    private JdbcTemplate jdbc;

    @Before public void before() {

        this.jdbc = getJdbcTemplate();

        TutorialTestUtil.deleteAll(this.jdbc);

    }

    @Test public void shouldReturnEmptyListEmptyTable() {

        // prepare
        assertSame(0, TutorialTestUtil.all(this.jdbc).size());

        // test
        final List<String> l = this.tutorialSProcService
            .step06SelectStatusNewAndUpdateToInProgress();

        // verify
        assertSame(0, l.size());

    }

    @Test public void shouldReturnTwoRecordsFromStatusNew() throws InterruptedException {

        // prepare
        assertSame(0, TutorialTestUtil.all(this.jdbc).size());

        final String name1 = "first random name";
        final String name2 = "second random name";
        assertTrue(TutorialTestUtil.insert(this.jdbc, name1,
                TutorialStatus.NEW));
        assertTrue(TutorialTestUtil.insert(this.jdbc, name2,
                TutorialStatus.NEW));

        final Tutorial tutorialBefore1 = TutorialTestUtil.load(this.jdbc,
                name1);
        final Tutorial tutorialBefore2 = TutorialTestUtil.load(this.jdbc,
                name2);

        Thread.sleep(2000); // last modified precision is 1 second...hence wait so we see a difference

        // test
        final List<String> l = this.tutorialSProcService
            .step06SelectStatusNewAndUpdateToInProgress();

        // verify
        assertSame(2, l.size());
        assertTrue(l.contains(name1));
        assertTrue(l.contains(name2));

        final Tutorial tutorialAfter1 = TutorialTestUtil.load(this.jdbc, name1);
        verifyUpdatesOnTutorial(tutorialBefore1, tutorialAfter1);

        final Tutorial tutorialAfter2 = TutorialTestUtil.load(this.jdbc, name2);
        verifyUpdatesOnTutorial(tutorialBefore2, tutorialAfter2);

    }

    @Test public void shouldReturnOneFromTwoRecordsOneNewOneNotNew() throws InterruptedException {

        // prepare
        for (final TutorialStatus ts : TutorialStatus.values()) {

            if (ts != TutorialStatus.NEW) {

                TutorialTestUtil.deleteAll(this.jdbc);

                final String name1 = "first random name";
                final String name2 = "second random name";
                assertTrue("failed for TutorialStatus=" + ts,
                    TutorialTestUtil.insert(this.jdbc, name1,
                        TutorialStatus.NEW));
                assertTrue("failed for TutorialStatus=" + ts,
                    TutorialTestUtil.insert(this.jdbc, name2, ts));

                final Tutorial tutorialBefore1 = TutorialTestUtil.load(
                        this.jdbc, name1);
                final Tutorial tutorialBefore2 = TutorialTestUtil.load(
                        this.jdbc, name2);

                Thread.sleep(2000); // last modified precision is 1 second...hence wait so we see a difference

                // test
                final List<String> l = this.tutorialSProcService
                    .step06SelectStatusNewAndUpdateToInProgress();

                // verify
                assertSame("failed for TutorialStatus=" + ts, 1, l.size());
                assertTrue("failed for TutorialStatus=" + ts,
                    l.contains(name1));

                final Tutorial tutorialAfter1 = TutorialTestUtil.load(this.jdbc,
                        name1);
                verifyUpdatesOnTutorial(tutorialBefore1, tutorialAfter1);

                final Tutorial tutorialAfter2 = TutorialTestUtil.load(this.jdbc,
                        name2);
                assertEquals("failed for TutorialStatus=" + ts, tutorialBefore2,
                    tutorialAfter2);

            }

        }

    }

    @Test public void shouldReturnZeroFromOneRecordNotNew() throws InterruptedException {

        for (final TutorialStatus ts : TutorialStatus.values()) {

            if (ts != TutorialStatus.NEW) {

                // prepare
                TutorialTestUtil.deleteAll(this.jdbc);

                final String name = "first random name";
                assertTrue(TutorialTestUtil.insert(this.jdbc, name, ts));

                final Tutorial tutorialBefore = TutorialTestUtil.load(this.jdbc,
                        name);

                // test
                final List<String> l = this.tutorialSProcService
                    .step06SelectStatusNewAndUpdateToInProgress();

                // verify
                assertSame(0, l.size());

                final Tutorial tutorialAfter = TutorialTestUtil.load(this.jdbc,
                        name);
                assertEquals("failed for TutorialStatus=" + ts, tutorialBefore,
                    tutorialAfter);

            }

        }

    }

    /*
     * test helpers
     ******************************************************************************************************************/

    /**
     * This check ensures that only the status and lastModified have changed.
     *
     * @param   before  not null
     * @param   after   not null
     *
     * @throws  IllegalArgumentException  missing or invalid input
     */
    private void verifyUpdatesOnTutorial(final Tutorial before,
        final Tutorial after) {

        assertNotNull(before);
        assertNotNull(after);

        assertEquals(TutorialStatus.IN_PROGRESS, after.getTutorialStatus());

        final Date modifiedBefore = before.getModified();
        final Date modifiedAfter = after.getModified();
        assertTrue(modifiedBefore.before(modifiedAfter));

        before.setTutorialStatus(after.getTutorialStatus());
        before.setModified(modifiedAfter);
        assertEquals(after, before);

    }

}
