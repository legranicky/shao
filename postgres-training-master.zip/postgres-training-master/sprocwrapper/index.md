# Precondition

For this tutorial you should be able to

- use git
- use maven
- set up a local PostgreSQL database (VM, Docker, ..)
- have basic knowlegde of SQL
- use a development environment of your choice.

# Introduction

The goal of this workshop is to get you started with [sprocwrapper](https://github.com/zalando/java-sproc-wrapper).
This library makes PostgreSQL stored procedures available in Java by naming conventions. Objects are serialized to
plpgsql data structures.  You are given an
interface (`de.zalando.tutorial.sproc.backend.persistence.TutorialSProcService`\) , it's implementation
(`de.zalando.tutorial.sproc.backend.persistence.impl.TutorialSProcServiceImpl`)
and several (failing) integration tests.  There is a separate integration test
class for each step checking the correctness of your implementation.The
goal is to fix the integration tests by implementing the stored procedures.

It is recommended that you read
[TechWiki:PostgreSQL Database Stored Procedures](https://techwiki.zalando.net/display/DT/PG+Stored+Procedures).

Checkout the repository:

    $ git clone git@github.bus.zalan.do:acid/postgres-training.git
    $ cd postgres-training/sprocwrapper/

To allow maven to connect to your local database you should save your credentials locally in the `~/.m2/settings.xml`.
There you navigate to the servers section and add server section similar to the
following (the value of `id` element is mandatory):

     <server>
       <id>testdb</id>
       <username>postgres</username>
       <password>your-secret-password</password>
     </server>

These settings are necessary for bootstrapping the database from within maven. The test runner opens its own connection.
It takes the credentials from `src/test/resources/application.test.properties`
file. Please adjust the values for `tutorial.sproc.datasource.username` and
`tutorial.sproc.datasource.password` accordingly.  

# STEP 0

In the first step you'll write sql creating an [enum
type](http://www.postgresql.org/docs/current/static/datatype-enum.html) and a [ table
](http://www.postgresql.org/docs/current/static/sql-createtable.html). They will be accessed by the
stored procedures.

Ensure your local database is running and accessible via localhost on port 5432 (to get a local database running please
follow the instructions at [TechWiki:Running Postgres in
VirtualBox](https://techwiki.zalando.net/display/DT/Preparing+PostgreSQL+Database)).

In this step you should fix `de.zalando.tutorial.sproc.backend.persistence.Step00CreateTableIT`.
To see if this works we now open a shell, switch to the directory of the
tutorial project (where the pom.xml resides) and execute the following
command

    mvn verify -Pintegration-test

This bootstraps the database and executes all the integration tests. If you
want to execute only a specific test class please call

    mvn verify -Pintegration-test -Dit.test=Step00CreateTableIT

Now we proceed with the specification for the sql you're about to write.

## Specification Enum Type

+ name     = tutorial_status
+ schema   = ztutorial_data
+ values   = {NEW, IN_PROGRESS, SUCCESS, FAILURE}
+ sql file = `database/tutorial/10_data/03_types/20_tutorial_status.sql`

## Specification Table

+ name     = tutorial
+ schema   = ztutorial_data
+ sql file = `database/tutorial/10_data/04_tables/20_tutorial.sql`

### Required columns
| name          | type            | nullable  | constraints  | default value          |  
|:--------------|:----------------|:----------|:-------------|:-----------------------|  
| t_id          | bigint          | false     | primary key  | automatically assigned |  
| t_name        | text            | false     | unique       | ---                    |  
| t_touch_count | integer         | false     | ---          | 0                      |  
| t_status      | tutorial_status | false     | ---          | 'NEW'                  |  
| t_created     | timestamp       | false     | ---          | clock_timestamp()      |  
| t_modified    | timestamp       | false     | ---          | clock_timestamp()      |  

# STEP 01-06

With having written and bootstrapped a database type and table you can now
start writing sprocs. Which ones and what they're supposed to do is defined by
the interface
src/main/java/de.zalando.tutorial.sproc.backend.persistence.TutorialSProcService.
Each step is equivalent to one method and has it's own integration test (e.g.
*src/test/java/de.zalando.tutorial.sproc.backend.persistence.Step01SelectSimpleIT*).

