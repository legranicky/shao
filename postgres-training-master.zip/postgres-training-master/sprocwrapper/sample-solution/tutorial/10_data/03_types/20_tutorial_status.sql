-- Type: tutorial_status

-- DROP TYPE tutorial_status;

CREATE TYPE ztutorial_data.tutorial_status AS ENUM
    ('NEW',
    'IN_PROGRESS',
    'SUCCESS',
    'FAILURE');
