CREATE TABLE ztutorial_data.tutorial(
    t_id           bigserial                       PRIMARY KEY,
    t_name         text                            NOT NULL UNIQUE,
    t_touch_count  integer                         NOT NULL DEFAULT 0,
    t_status       ztutorial_data.tutorial_status  NOT NULL DEFAULT 'NEW',
    t_created      timestamp                       NOT NULL DEFAULT clock_timestamp(),
    t_modified     timestamp                       NOT NULL DEFAULT clock_timestamp()
);

