CREATE OR REPLACE FUNCTION step_06_select_status_new_and_update_to_in_progress(
  OUT r_name  text
)
  RETURNS setof text AS
$BODY$
BEGIN

    RETURN QUERY
    UPDATE ztutorial_data.tutorial
       SET t_status = 'IN_PROGRESS',
           t_modified = clock_timestamp()
     WHERE t_status = 'NEW'
     RETURNING t_name;

END;
$BODY$
  LANGUAGE 'plpgsql' VOLATILE SECURITY DEFINER
  COST 100;
