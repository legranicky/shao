CREATE OR REPLACE FUNCTION step_03_get_status_string_by_name(
  p_name        varchar,
  OUT r_status  text
)
  RETURNS text AS
$BODY$
 SELECT t_status::text
   FROM ztutorial_data.tutorial
 WHERE t_name = $1::text;
$BODY$
  LANGUAGE 'sql' VOLATILE SECURITY DEFINER
  COST 100;
