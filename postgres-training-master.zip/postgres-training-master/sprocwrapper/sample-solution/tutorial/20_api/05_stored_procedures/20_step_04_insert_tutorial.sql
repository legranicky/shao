CREATE OR REPLACE FUNCTION step_04_insert_tutorial(
  p_name        varchar
)
  RETURNS void AS
$BODY$
 INSERT INTO ztutorial_data.tutorial(t_name)
 VALUES ($1::text);

$BODY$
  LANGUAGE 'sql' VOLATILE SECURITY DEFINER
  COST 100;
