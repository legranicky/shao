CREATE OR REPLACE FUNCTION step_05_update_tutorial_status(
  p_name        varchar,
  p_new_status  ztutorial_data.tutorial_status
)
  RETURNS void AS
$BODY$
BEGIN
    perform 1
    FROM ztutorial_data.tutorial
    WHERE t_name = p_name;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'tutorial record not found : name := %', p_name;
    END IF;

    UPDATE ONLY ztutorial_data.tutorial
      SET t_status = p_new_status
      WHERE t_name = p_name;
END;
$BODY$
  LANGUAGE 'plpgsql' VOLATILE SECURITY DEFINER
  COST 100;
