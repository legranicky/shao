CREATE OR REPLACE FUNCTION step_02_get_record_by_name(
  p_name             varchar,
  OUT t_id           bigint,
  OUT t_name         text,
  OUT t_touch_count  integer,
  OUT t_status       text,
  OUT t_created      timestamp,
  OUT t_modified     timestamp
)
  RETURNS SETOF RECORD AS
$BODY$
BEGIN
  RETURN QUERY
  SELECT t.t_id, t.t_name, t.t_touch_count, t.t_status::text, t.t_created, t.t_modified
      FROM ONLY ztutorial_data.tutorial t
      WHERE t.t_name = p_name::text;
END;
$BODY$
  LANGUAGE 'plpgsql' VOLATILE SECURITY DEFINER
  COST 100;
