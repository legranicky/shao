CREATE OR REPLACE FUNCTION step_01_get_id_by_name(
  p_name    varchar,
  OUT r_id  bigint
)
  RETURNS bigint AS
$BODY$
 SELECT t_id
   FROM ztutorial_data.tutorial
 WHERE t_name = $1::text;

$BODY$
  LANGUAGE 'sql' VOLATILE SECURITY DEFINER
  COST 100;
