RESET role;

CREATE SCHEMA ztutorial_api;

SET search_path to ztutorial_api, public;
