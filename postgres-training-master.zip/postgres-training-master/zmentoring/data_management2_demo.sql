-- Author: Feike Steenbergen
--
-- This script is a demonstration of index usage, database bootstrapping etc.
-- It requires:
-- * psql as a client >= 9.3 (It uses \gset)
-- * superuser access to a cluster
--
\x off
\pset pager off
\echo 'Cleaning up previous sessions'
\c feike
\set demo_schema mentoring
DROP SCHEMA IF EXISTS :demo_schema CASCADE;
CREATE SCHEMA :demo_schema;
set search_path=:demo_schema,pg_catalog,pg_temp;
\timing on
\echo
\echo
\echo
\echo
\echo
\echo
\echo
\echo
\echo
\echo
\echo
\echo
\echo
\echo
\echo
\echo
\echo
\echo
\echo
\echo
\echo
\echo
\echo
\echo
\echo
\echo
\echo
\echo
\echo
\echo
\echo
\echo
\echo
\echo
\echo
\echo
\echo
\echo
\echo
\echo
\echo
\echo
\echo
\echo
\echo
\echo
\echo
\echo
\echo
\echo
\echo
\echo
\echo
\echo
\echo
\echo
\echo
\echo
\echo
\echo
\echo
\echo
\echo
\echo
\echo
\echo
\echo
\echo
\echo
\echo
\echo
\echo
\echo
\echo
\set ECHO queries
\echo
\echo
\echo
\echo
\echo
\echo
\echo
\echo
\echo
\echo
\echo
\echo
\echo
\echo
\echo
\echo
\echo
\echo
\echo
\echo
\echo
\echo
\echo
\echo
\echo
\echo
\echo
\echo
\echo
\prompt '-------------------------- Let''s create tables to play with           ' dummy
\echo
\echo
\echo
CREATE TABLE t1 (
    f1  integer PRIMARY KEY,
    f2  text
);
CREATE TABLE t2 (
    f3 integer PRIMARY KEY
);
\echo
\prompt '-------------------------- Put some data in it           ' dummy
\echo
INSERT INTO t2 (f3)     SELECT i FROM generate_series(1,240000,5) AS sub(i);
INSERT INTO t1 (f1, f2)     SELECT i, md5(random()::text) FROM generate_series(3,100000,3) AS sub(i);

\echo
\prompt '-------------------------- Makes sure the statistics are up to date;      ' dummy
\echo
ANALYZE t1;
ANALYZE t2;

\echo
\prompt '-------------------------- So what happens when we execute this update?    ' dummy
\echo

\d t1
UPDATE t1 set f1 = 55 WHERE f1::text ='9';


\echo
\prompt '-------------------------- Let''s see what has happened when we executed this update      ' dummy
\echo
EXPLAIN ANALYZE
UPDATE t1 set f1 = 55 WHERE f1::text ='9';

\echo
\prompt '-------------------------- Is this what you would expect?      ' dummy
\echo

\echo
\prompt '-------------------------- What if we do not cast the column to the variable type, but the variable type to the column type?    ' dummy
\echo
EXPLAIN ANALYZE
UPDATE t1 set f1 = 55 WHERE f1::text ='9';
EXPLAIN ANALYZE
UPDATE t1 set f1 = 55 WHERE f1 ='9'::int;

\echo
\prompt '-------------------------- Let''s look at some loops vs an Atomic query, starting with a LOOP   ' dummy
\echo
DO
LANGUAGE plpgsql
$BODY$
DECLARE
    started  timestamptz;
    duration interval;
    rowcount numeric;
BEGIN

    started := clock_timestamp();

    FOR i IN 1..100000 LOOP
        UPDATE t1
           SET f2 = 'done'
         WHERE f1 = i
           AND EXISTS (SELECT 1
                         FROM t2
                        WHERE t2.f3 = t1.f1);
    END LOOP;

    duration := clock_timestamp() - started;

    SELECT count(*)
      INTO rowcount
      FROM t1
     WHERE f2 = 'done';

    RAISE NOTICE 'Rows updated: %, duration: %, Rows per second: %', rowcount, duration, (rowcount/extract(epoch from duration))::integer;

END;
$BODY$;

\echo
\prompt '-------------------------- And now an Atomic query   ' dummy
\echo
DO
LANGUAGE plpgsql
$BODY$
DECLARE
    started  timestamptz;
    duration interval;
    rowcount numeric;
BEGIN

    started := clock_timestamp();

    UPDATE t1
       SET f2 = 'done2'
      FROM t2
     WHERE t2.f3 = t1.f1
       AND f1 BETWEEN 1 AND 100000;

    duration := clock_timestamp() - started;

    SELECT count(*)
      INTO rowcount
      FROM t1
     WHERE f2 = 'done2';

    RAISE NOTICE 'Rows updated: %, duration: %, Rows per second: %', rowcount, duration, (rowcount/extract(epoch from duration))::integer;

END;
$BODY$;


\echo
\prompt '-------------------------- Let''s see the planner change plans by supplying different values   ' dummy
\echo
UPDATE t1 SET f2 = 'done'
 WHERE f1 BETWEEN 1 AND 100
   AND EXISTS
        (SELECT 1
           FROM t2
          WHERE t2.f3= t1.f1);

\echo
\prompt '-------------------------- So, what happened?   ' dummy
\echo
EXPLAIN
UPDATE t1 SET f2 = 'done'
 WHERE f1 BETWEEN 1 AND 100
   AND EXISTS
        (SELECT 1
           FROM t2
          WHERE t2.f3= t1.f1);

\echo
\prompt '-------------------------- And what if we need a bigger part of all the data?      ' dummy
\echo
EXPLAIN
UPDATE t1 SET f2 = 'done'
 WHERE f1 BETWEEN 1 AND 100000
   AND EXISTS
        (SELECT 1
           FROM t2
          WHERE t2.f3= t1.f1);

\echo
\prompt '-------------------------- Let''s create a fully bootstrapped database      ' dummy
\echo
DROP DATABASE local_test_db;
CREATE DATABASE local_test_db;
\c local_test_db

\echo


\echo
\prompt '-------------------------- We clone the git repo (normally inject a dependency in your pom.xml) ' dummy
\echo
\! git clone ssh://git@stash.zalando.net:7999/platform/config.git /tmp/zalando-db-commons/
\echo
\prompt '-------------------------- Install zalando-db-commons: ' dummy
\echo
\! find /opt/git/platform/config/zalando-db-commons -name '*.sql' | sort -d | xargs cat > bootstrap
\i bootstrap
RESET ROLE;
\echo
\prompt '-------------------------- So this is how we bootstrap a database:      ' dummy
\echo
\echo find database/ -name '*.sql' | sort -d | xargs cat | psql_target_database --file=- --single_transaction --ON_ERROR_STOP=1
\echo
\prompt '-------------------------- find database/ -name '*.sql' | sort -d    ' dummy
\echo
\! find database/ -name '*.sql' | sort -d
\echo
\prompt '-------------------------- And then execute it:     ' dummy
\echo
\! find database/ -name '*.sql' | sort -d | xargs cat > bootstrap
\i bootstrap
RESET ROLE;

\echo
\prompt '-------------------------- What schema''s do we have?     ' dummy
\echo
\echo '\dn'
\dn

\echo
\prompt '-------------------------- And what tables are in the zment_data schema?     ' dummy
\echo
\echo '\dt zment_data.*'
\dt zment_data.*

\echo
\prompt '-------------------------- Let''s set the search path so we will only see this schema     ' dummy
\echo
SET search_path to zment_data;

\echo
\prompt '-------------------------- What does this table look like?     ' dummy
\echo
\echo '\dt+ main'
\dt+ main

\echo
\prompt '-------------------------- We use explain to look at how a query might be executed:     ' dummy
\echo
explain
select count(*)
  from main
 where m_value = 59;

\echo
\prompt '-------------------------- We do it again, but now it will actually run the query:     ' dummy
\echo
explain (analyze on, buffers on)
SELECT count(*)
  FROM main
 WHERE m_value = 59;

\echo
\prompt '-------------------------- So what if we create an index that might be useful for this query?     ' dummy
\echo
create index main_m_value_idx on main (m_value);

\echo
\prompt '-------------------------- This is the explain plan now:     ' dummy
\echo
explain (analyze on, buffers on)
SELECT count(*)
  FROM main
 WHERE m_value = 59;

\echo
\prompt '-------------------------- Another example of a query we might be able to speed up     ' dummy
\echo
explain (analyze on, buffers on)
SELECT count(*),
       l_time
  FROM main
  JOIN lookup on m_lookup_id = l_id
 WHERE m_value = 59
GROUP BY l_time;

\echo
\prompt '-------------------------- Create an index:      ' dummy
\echo
create index lookup_l_id_idx on lookup (l_id);

\echo
\prompt '-------------------------- Let''s have another look at the explain plan:     ' dummy
\echo
explain (analyze on, buffers on)
SELECT count(*),
       l_time
  FROM main
  JOIN lookup on m_lookup_id = l_id
 WHERE m_value = 59
GROUP BY l_time;

\echo
\prompt '-------------------------- Another query which demonstrates the ability to use indexes     ' dummy
\echo

explain analyze
 select count(1),
      l_time
 from main
inner join lookup on m_lookup_id = l_id
where m_lookup_id = 5
  and m_value = 59
group by l_time;

\echo
\prompt '-------------------------- Now we will look at a function (sproc, stored procedure):     ' dummy
\echo
\ef zment_api_r14_00_35.lookup_and_transform_single_value

\echo
\prompt '-------------------------- If we set the search path we may not need to qualify every function call     ' dummy
\echo
set search_path to zment_api_r14_00_35;
select * from lookup_and_transform_single_value (59);

\echo
\prompt '-------------------------- If the api schema is not in the search path, we will have to qualify the function call     ' dummy
\echo
set search_path to zment_data;
select * from zment_api_r14_00_35.lookup_and_transform_single_value (59);

\echo
\prompt '-------------------------- So what if we want to analyze/profile a function ?     ' dummy
\echo
explain analyze
select * from zment_api_r14_00_35.lookup_and_transform_single_value (59);

\echo
\prompt '-------------------------- A usefull step might be to generate a prepared plan:     ' dummy
\echo
prepare abc (integer) AS
  SELECT count(1)
    FROM main
   WHERE m_value = $1;

\echo
\prompt '-------------------------- Which can then be analyzed:     ' dummy
\echo
explain analyze execute abc(59);
