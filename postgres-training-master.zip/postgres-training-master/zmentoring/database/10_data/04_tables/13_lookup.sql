create table zment_data.lookup (l_id serial, l_time timestamptz);
