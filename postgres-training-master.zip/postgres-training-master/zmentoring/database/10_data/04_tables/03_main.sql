create table zment_data.main (m_id serial,
                   m_lookup_id integer, 
                   m_value integer);

