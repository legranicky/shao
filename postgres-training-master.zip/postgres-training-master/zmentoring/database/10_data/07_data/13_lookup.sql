insert into zment_data.lookup (l_time)
select generate_series(current_timestamp,
                       current_timestamp + interval '1 month',
                       '1 second'::interval);

