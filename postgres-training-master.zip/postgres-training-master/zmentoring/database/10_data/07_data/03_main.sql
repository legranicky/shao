insert into zment_data.main (m_lookup_id,m_value)
select (random()*9+1)::integer,
       (random()*99+1)::integer
  from generate_series (1,999999);
