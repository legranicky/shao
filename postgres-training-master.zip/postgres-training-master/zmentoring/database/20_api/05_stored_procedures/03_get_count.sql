CREATE OR REPLACE FUNCTION lookup_and_transform_single_value(
  IN p_m_value                  integer,
  OUT results_header		text,
  OUT results_count       	integer
  )
  RETURNS setof record AS
$$

DECLARE
  l_results_count               integer;

BEGIN


  RAISE NOTICE  ': %', p_m_value;

  SELECT count(1)
    FROM main
   WHERE m_value = p_m_value
    INTO l_results_count;
 
  RAISE NOTICE 'results: %',l_results_count;

  -- Return Query
  RETURN QUERY 
  SELECT 'results_count'::text, l_results_count;

END;
$$
  LANGUAGE 'plpgsql'; 
