reset role;
SELECT zz_utils.create_project_schema_api_env(schema_name:='zment_api_r14_00_35', data_schema_names:=ARRAY['zment_data']);
