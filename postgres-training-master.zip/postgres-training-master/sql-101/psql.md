#psql
**NOTE:** If you are going to use pgAdmin3 for this course, you can skip this step and go to [pgAdmin3](/pgadmin3)

`psql` is a great command line interface to a PostgreSQL database.
It has many options and features which make it useful
both for interactive sessions as for automated tasks.

## Connecting to a database

Depending on your installation and setup you may need to change some of the parameters used for connecting to 
PostgreSQL. You may also be prompted for a password.

```bash
## Run this inside your shell
psql --host=localhost --dbname=postgres --user=postgres
```


Once connected, the following command should print `SUCCESS`:

```sql
SELECT CASE WHEN null::json IS NULL THEN 'SUCCESS' ELSE 'FAILURE' END;
```

An example session:

```text
$ psql --host=localhost --dbname=postgres --user=postgres
Password for user postgres:
psql (9.4.4)
SSL connection (protocol: TLSv1.2, cipher: ECDHE-RSA-AES256-GCM-SHA384, bits: 256, compression: off)
Type "help" for help.

postgres=# SELECT CASE WHEN null::json IS NULL THEN 'SUCCESS' ELSE 'FAILURE' END;
  case
---------
 SUCCESS
(1 row)
```

If it does not print `SUCCESS`, try to find out if our connection details are correct, if that does not work,
try to contact your mentor to help in setting up your environment (A Dockerfile is present in this repository as well).

Some assumptions for the rest of the training:

- commands are to be executed inside `psql`, unless clearly labelled otherwise
- the working directory of `psql` is the `sql` directory of this course

Go to the directory containing the sql files of this course and fire up `psql`,
e.g.:

    ## Use your shell for these commands
    cd ~/git/postgres-training/101/sql
    psql

To help you get going, 2 help commands are very useful:

- `\?` Shows help information about the backslash commands.
- `\h` help on syntax of SQL commands

Try out the following:

    \h CREATE TABLE

You'll be presented with the syntax of the `CREATE TABLE` command.
For many operations tab-completion is available,
for example, to get help about the syntax of creating a `FUNCTION`,
the following would suffice:

    \h CREATE FU<TAB>

## Create and fill the training101 database
To be able to do some queries with a small amount of tables
an example database is ready to be installed.

- Download <a href="/download/training101.backup.sql" download="training101.backup.sql">training101.backup.sql</a>

```bash
## In your shell
psql --file=training101.backup.sql --set=ON_ERROR_STOP=true
```

Some output should have flashed over your screen,
if you disconnect from PostgreSQL and need to reconnect to the training
database (which has been created with the previous command), you can issue one of the following:

    ## Use your shell for these commands
    psql --dbname training101
    psql -d training101
    psql training101

## Exploring your database

to investigate what tables exists in the database schema, execute the following:


    \dt

You can see some tables exist which we will use in this training.

## Start querying

Once you have a prompt you can start querying, here is an example:

```text
training101=> SELECT * FROM car;
 c_id |  c_name
------+----------
    1 | BMW
    2 | Skoda
    3 | Mercedes
    4 | Lotus
    5 | Renault
(5 rows)
```
