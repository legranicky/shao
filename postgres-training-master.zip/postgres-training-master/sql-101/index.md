# Introduction
This course is meant to serve as an introduction into SQL,
geared towards PostgreSQL.

# Goal
The goals of this course are as follows:

* Get you a working PostgreSQL environment to be able to quickly develop, train or learn using PostgreSQL.
* Refresh or introduce you to the basics of `SQL`
* Prepare you for following other courses:
    * [overview](https://acid-training-app.acid.zalan.do/)

# Client tools
To connect to PostgreSQL database you will need a client. After installing PostgreSQL you will have `psql` and may have
pgAdmin3 installed. You can use these two, as well as other clients to execute your queries against PostgreSQL.

This course was written with a focus on the command-line client: `psql`.

# Repository
If you want to follow the course fully, you will have to have a copy of the repository on your hard drive.

Choose on of the following methods:

- [GitHub Enterprise](https://github.bus.zalan.do/acid/postgres-training)
- <a href="/repository.zip">repository.zip</a>
