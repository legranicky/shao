# GROUP BY and HAVING
Documentation: [GROUP BY Clause](http://www.postgresql.org/docs/current/static/sql-select.html#SQL-GROUPBY)

The `GROUP BY` Clause can be used to aggregate information into groups. Whenever you think something like:

> I want this *per* something

> I need a total/average/stddev *for some values of x*

> I need an overview *without the details*

You could probably answer the question using a `GROUP BY` clause.

A few examples to illustrate this point:

- You want the total `surfacearea` of the countries *per continent*

            SELECT continent, sum(surfacearea)
              FROM country
          GROUP BY continent;

- You want the number of orders *per weekday*

            SELECT extract('dow' FROM orderdate),
                   count(*)
              FROM orders
          GROUP BY extract('dow' FROM orderdate);

The `HAVING` clause is similar to the `WHERE` clause: It filters. The distinction is to what it filters:

- `WHERE` filters records
- `HAVING` filters groups.

Again, this is probably best answered with an example:

> I want the countries which have more than a 100 cities.

We could break this statement down into two statements, giving us the `GROUP BY` (1) and `HAVING` (2)

1. Count the number of cities per country
2. List those countries with more than 100 cities
    
          SELECT countrycode
            FROM city
        GROUP BY countrycode
          HAVING count(*) > 100; 

## Hands-on
1. Show us the population per continent
2. 

4. Show all the `countrycode` which have > 10 cities with populations > 1000000;            

# NULL values
Whenever working with databases the behaviour of `NULL` needs to be considered.
Many definitions can be found, 
but the one that conveys a lot of meaning is (from [Wikipedia](http://en.wikipedia.org/wiki/Null_(SQL))):

> SQL null is a state (unknown) and not a value. This usage is quite different from most programming languages,
> where null means not assigned to a particular instance.

However, the behaviour of `NULL` cannot easily be extrapolated from one defined behaviour.
Your brain will try to extrapolate certain behaviours of `NULL`, but it shouldn't. The above statement itself is
in contradiction to some behaviours.

Because of `NULL` not being a value but being a state, all the following will
not return `true` and will not return `false`: The are undefined and therefore will be `NULL`:

    SELECT null  = '';
    SELECT null != '';

To test for the existence of `NULL` use the `IS [NOT] NULL` operator, some operations using `NULL`:

    SELECT null IS NULL         AS is_null,
           null IS NOT NULL     AS is_not_null;

If you are troubleshooting `NULL` it may be helpful to display them differently than their default.
By default in `psql` it will be the empty string, if you want to change the printing options of `psql`
you can use `\pset`. For this exercise it will be helpful to do the following:

    \pset null '(null)'    

We will be doing something with a test table now, first look at the behaviour of `NULL` when combined with a boolean,
this behaviour is documented in the manual
in section [9.1. Logical Operators](http://www.postgresql.org/docs/current/static/functions-logical.html). 

With the following query you will see the truth table for `NULL` and booleans:

    SELECT a,
           b,
           a AND b  AS a_and_b,
           a OR  b  AS a_or_b
      FROM null_a;

This is how text behaves, note that an empty string is `NOT NULL`:

    SELECT id,
           name,
           name IS NULL     AS is_null,
           name = NULL      AS equals_null,
           name || '<--'    AS concatenated
      FROM null_b;

Another few behaviour examples when using arrays:

    SELECT id,
           vals,
           vals IS NULL     AS is_null,
           null  = ANY(vals) AS any_null,
           null != ANY(vals) AS any_not_null
      FROM null_c;

Notice that most operators on `NULL` will return `NULL` if their input contains a `NULL` value.

## Hands-on
--------
1. List `cr_number` from `car_registration` which do not have a `cr_c_id`
2. What is the value of x after: `SELECT 1 + null - 10 - null AS x`
3. List `vals` from `null_c` where at least one array value is `NULL`
4. List `vals` from `null_c` where not a single array member is `NULL`
<!---
SELECT vals
  FROM null_c
 WHERE NOT EXISTS (
            SELECT 1
              FROM unnest(vals)
             WHERE unnest IS NULL
       );
-->

## More reading
A very good writeup about nulls is [What is the deal with NULLs?](http://thoughts.davisjeff.com/2009/08/02/what-is-the-deal-with-nulls/)
> I believe the above shows, beyond a reasonable doubt, that NULL semantics are unintuitive, and if viewed according to most of the “standard explanations,” highly inconsistent.

# Subqueries
Subqueries come in all kinds of forms:

## Scalar subqueries
Documentation: [4.2.11 Scalar Subqueries](http://www.postgresql.org/docs/current/static/sql-expressions.html#SQL-SYNTAX-SCALAR-SUBQUERIES)
> A `SELECT` query in parentheses that returns exactly one row with one column.
For example:

```sql
SELECT name,
       (SELECT now()) 
  FROM country;
```

We can also have a correlated scalar subquery, it references tables specified in the `FROM` clause:

```sql
SELECT country.name,
       (SELECT max(population) FROM city WHERE city.countrycode = country.code)
  FROM country;
```

## Subquery expressions
Documentation: [9.22 Subquery expressions](http://www.postgresql.org/docs/current/static/functions-subquery.html)

We use subqueries also in `EXISTS ANY SOME ALL` kind of queries:

```sql
SELECT city.name
  FROM city
 WHERE EXISTS (SELECT 1
                 FROM country
                WHERE capital = city.id);
```

## Common Table Expressions (CTE)
Documentation:
[7.8 WITH Queries (Common Table Expressions)](http://www.postgresql.org/docs/current/static/queries-with.html)

CTE's are named subqueries that can be used in a larger query. Some of its advantages are:

- break down complicated queries into simpler parts
- enable recursion in `SQL`
- you can use data-modifying statements, enabling several operations in one query

Some examples:

```sql
-- Large countries (area or population)
WITH large_country (name, capital) AS (
    SELECT name,
           capital
      FROM country
     WHERE    surfacearea > 2000000
           OR population > 50000000
)
SELECT large_country.name,
       city.name
  FROM large_country
  JOIN city ON (large_country.capital = city.id);
```

```sql
-- Move cars without registration into the archive table
WITH c_ids_registered AS (
    SELECT cr_c_id
      FROM car_registration
     WHERE cr_c_id IS NOT NULL
),  deleted_cars AS (
    DELETE
      FROM car
     WHERE c_id NOT IN (SELECT cr_c_id FROM c_ids_registered)
    RETURNING *
)
INSERT
  INTO car_archive
SELECT *
  FROM deleted_cars;
```

```sql
-- Count to 10
WITH RECURSIVE counter(i) AS (
    SELECT 1
    UNION ALL
    SELECT i+1
      FROM counter
     WHERE i < 10
)
SELECT *
  FROM counter;
```

> Note: CTE's are optimization fences in PostgreSQL.
This can be both a good and a bad thing. Keep it in mind if you are troubleshooting performance issues.

## Hands-on
1. Using a subquery (pick any type), list the capitals of Europe.
2. What is the average life expectancy per continent for countries which have no cities with a population of > 1000000;
<!---
    SELECT continent,
           avg(lifeexpectancy)
      FROM country
     WHERE code IN (
                SELECT countrycode
                  FROM city
              GROUP BY countrycode
                HAVING max(population) <= 100000
           )
  GROUP BY continent;
    -->
3. A correlated subquery can be very expensive, as it needs to execute this subquery
for every single record of the driving table(s). Compare the timing of the following queries.
 
        -- psql only: returns feedback about the duration of the query
        \set timing on

    The first query uses a correlated subquery:

           SELECT country.name,
                  (SELECT max(population) FROM city WHERE city.countrycode = country.code)
             FROM country;

    The second one uses a join:

           SELECT country.name,
                  max(city.population)
             FROM country
        LEFT JOIN city ON (city.countrycode = country.code)
         GROUP BY country.name;

4. Bonus: `EXPLAIN ANALYZE` both queries listed above and compare their explain plans;
# Types
Documentation: [CREATE TYPE](http://www.postgresql.org/docs/9.4/static/sql-createtype.html)

You can create your own types in PostgreSQL:

- composite
- enum
- range

We'll be looking at *composite* and *enum* types.

This is what the manual says about `COMPOSITE` types:

> A composite type is essentially the same as the row type of a table

One of the main reasons to create a `TYPE`
is that you can use it as part of the signature or return type of a function.

An example would be:

    CREATE TYPE box AS (
        length int,
        width  int,
        height int
    );

In plain sql you can now cast into this type as follows:

    SELECT CAST( (10,20,35) AS box); -- Standard
    SELECT (10,20,35)::box;          -- PostgreSQL shorthand

    -- Install the function
    \i function_volume.sql
    -- Look at the function
    \sf volume

    WITH box(package) AS (
        SELECT (10,20,35)::box
        UNION ALL
        SELECT (25,45,60)::box
    )
    SELECT volume(package)
      FROM box;

About `ENUM` types:
> Enumerated (enum) types are data types that comprise a static, ordered set of values. 

Advantages of `ENUM`:

- Only stores 4 bytes per tuple when used
- conveys meaning
- can be shared among tables
- remains readable
- type safe: `print_status.ERROR != delivery.ERROR`

We use `ENUM`'s for this purpose quite a lot, our convention is to use UPPER CASE for the values, like:

    CREATE TYPE print_status AS ENUM (
        'PRINTED',
        'ERROR',
        'RETRY',
        'QUEUED'
    );

## Hands-on
1. Create a `TYPE` shoe with the field names `colour` and `size`
2. Create an `ENUM TYPE` mood with the values `SAD`, `ANNOYED`, `FRUSTRATED`
3. Add `HAPPY` to the `mood` type 
4. Delete the value `SAD` from the `mood` type
<!--- trick question,
Deleting values from an ENUM is (currently 9.4.3) not possible.
-->
