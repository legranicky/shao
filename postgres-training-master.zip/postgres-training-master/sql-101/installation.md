# Installing PostgreSQL
Installing PostgreSQL is a relatively simple procedure. But as there are many flavours of operating systems,
preferences and constraints we cannot provide a one-size-fits-all installation guide.

For the mainstream operating systems packages can easily be downloaded and installed. A docker image is also available.

## Docker
We provide a Dockerfile and readme in our
[repository](https://github.bus.zalan.do/acid/postgres-training/blob/master/Dockerfile), where you
can build your own. The docker image is also available on pierone.

```bash
# In your shell
docker run -d -p 5432:5432 pierone.stups.zalan.do/acid/postgres-training
```


## Ubuntu and Debian
If you run a recent version of these distributions, installing PostgreSQL 9.3+ is a one-liner:
```bash
# In your shell
sudo apt-get install postgresql
```

If you want to install the latest greatest, you should keep on reading

## Prebuilt packages
If you want to install on a different flavour of Linux, or want to have the latest and greatest PostgreSQL
you should visit the download page and follow those instructions

* [http://www.postgresql.org/download/](http://www.postgresql.org/download/)

## Windows
Download your installer from enterprisedb, it includes pgAdmin3:

* [www.enterprisedb.com installer page](http://www.enterprisedb.com/products-services-training/pgdownload#windows)

## Mac OS X
A list of options of installing on Mac OS X can be found on:

* [www.postgresql.org](http://www.postgresql.org/download/macosx/)
