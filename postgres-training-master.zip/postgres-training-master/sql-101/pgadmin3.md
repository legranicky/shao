# pgAdmin3
**NOTE:** If you are only going to use psql for this course, you can skip this step.

## Connecting to a database

Go to `File-->Server` to get the following screen. The values
may differ on your installation.

:![Connecting to a local PostgreSQL cluster](images/pgadmin3-connect.png)

## Creating a new database

Navigate to the Server you just created, expand it and right-click on `Databases` to create a new database.

:![Creating a new database](images/pgadmin3-createdb.png)

## Fill the training101 database

- Download <a href="/download/training101.backup" download="training101.backup">training101.backup</a>
- Right-Click on the `training101` database in the `Object browser` of pgAdmin3 and choose `restore`
- Browse for the downloaded `training101.backup` file and click restore

## Exploring your database

Use the `Object browser` to go through your list of schema's etc

## Start querying

You can get a query window by clicking on the following icon: :![sql](images/pgadmin3-sql-icon.png)
Alternatively, choose the menu `Tools-->Query tool` to get the query window.

You can now start querying your database, type or paste the query in the `SQL Editor` and execute
it by either hitting the green `run` icon (see red arrow), or by choosing the menu `Query-->execute`
or by hitting `F5` on your keyboard.

:![Query car table](images/pgadmin3-select-car.png)


