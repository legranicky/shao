# SELECT
Documentation: [SELECT](http://www.postgresql.org/docs/current/static/sql-select.html)


In the PostgreSQL documentation, the `SELECT` section shows what you can do with a "simple" `SELECT`.
Some of the following information was copied verbatim from this section.

To start we will do some `SELECT` queries against the `products` table.
The difference with the previous commands is that we execute `SQL`.
The previous backslash commands are all `psql` specific
and cannot be used in other programs.
The following statement could be used in other tools like `pgAdmin3`
or some database agnostic tool.
You will need to end every `SQL` command with a semi-colon
when running psql in interactive mode.

    SELECT * FROM country;

The `*` in the SELECT means that you want to see all columns.
When writing production-worthy code you will want to avoid this:

- columns can be added
- columns can be removed
- you may be pulling in more data than is necessary
- the query will executed a bit more efficiently because not all columns need
  to be processed
- the planner might be able to create a much more efficient plan
  as some joins might be eliminated

We will not dive to deep into explaining queries and performance,
but it is useful to know the following commands
when interactively querying PostgreSQL:

- `EXPLAIN` will show you what plan the executor will follow for a given query
- `EXPLAIN ANALYZE` will execute the query and show you the followed plan

For example:

    EXPLAIN ANALYZE
    SELECT datname FROM pg_database;

## For pgAdmin3 users only

pgAdmin3 has its own interface and (graphical) output for `EXPLAIN [ANALYZE]`.
Leave out the `EXPLAIN ANALYZE` of the provided examples, and use the menu to do the `EXPLAIN ANALYZE` for you:

- Query-->Explain (F7)
- Query-->Explain Analyze (⇧ F7)


## Hands-on
1. Get the columns `name` and `continent` from the `country` table
2. Execute the following queries,
   look at their explain plans and their execution time and compare:

        EXPLAIN ANALYZE
        SELECT name FROM country_city_count;

        EXPLAIN ANALYZE
        SELECT * from country_city_count;

# WHERE clause
From the `SELECT` section:
> The `WHERE` clause has a condition that evaluates to a result of type
> `boolean`. Any row that does not satisfy this condition
> will be eliminated from the output.

You need to ensure the result of the whole expression is a boolean.

A very simple example to find all demo cities in Finland would be:

    SELECT name
      FROM city
     WHERE countrycode='FIN';

As the result for the `WHERE` clause needs to be a boolean you can use all kinds of logic,
as long as the result is a boolean. If you want only cities with a relative large population from 
Germany, you could do:

    SELECT name, population
      FROM city
     WHERE countrycode='DEU'
           AND
           population > 500*1000;

As logical operators have a precedence, it is sometimes necessary to add parentheses
around parts of the where clause. Sometimes it is useful for readability to add parentheses.
Formatting also helps.

Compare:

    SELECT name
      FROM city
     WHERE population > 500*1000 OR countrycode='DEU' AND population > 1000*1000 OR countrycode = 'FIN';

With:

    SELECT name
      FROM city
     WHERE    population > 500*1000
           OR (countrycode='DEU' AND population > 1000*1000)
           OR countrycode = 'FIN';

Sometimes you need the result of an expression instead of a simple comparison, we will deal with `IN`, `LIKE` and `IS [NOT] NULL` here.

The `IN` parameter is useful if you have a list of records that need to be matched, for example:

    SELECT name
      FROM city
     WHERE countrycode IN ('DEU','FIN');

This can also be the result of a subquery:
   
```sql 
SELECT name
  FROM city
 WHERE countrycode IN (SELECT code FROM country WHERE region='Caribbean');
```
     
The `LIKE` operator can be used to do simple string matching, 
with the wildcards: `_` (one character) and `%` (any sequence of characters), examples:

```sql 
SELECT name
  FROM city
 WHERE name LIKE 'Ber%';
```

```sql 
SELECT name
  FROM city
 WHERE name LIKE '_erlin';
```

```sql 
SELECT name
  FROM city
 WHERE name LIKE '%aba%';
```

We will treat `NULL` more extensively further on, but for now it is useful to know the operator `IS [NOT] NULL`,
we can query the countries where no independence year is registered with this operator:

```sql 
SELECT name
  FROM country
 WHERE indepyear IS NULL;
```


## Hands-on
1. Get `customerid` from `customers` if the `lastname` contains the string "HI"
2. Get `customerid` from `customers` if the `lastname` starts with the string "HI"
3. List the names of the cities for the country with code 'WLF'
4. List the names of the countries where both these conditions are met:
    - there is no `capital`
    - `surfacearea` greater than 1 million
