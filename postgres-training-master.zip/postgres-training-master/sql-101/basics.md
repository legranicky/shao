# Joins
By joining tables together we are starting to really utilize a relational database.


Joins come in 3 variants (which can be subdivided):

- INNER JOIN
- OUTER JOIN: LEFT, RIGHT, FULL
- CROSS JOIN

The following picture taken from
[Visual Representation of SQL Joins](http://www.codeproject.com/Articles/33052/Visual-Representation-of-SQL-Joins)
shows the way we can think about joins:

![Visual SQL JOINS](images/Visual_SQL_JOINS_orig.jpg)

The `INNER` and `OUTER` join need a join condition, it can be `NATURAL`, `ON` or `USING`.
We will use the `ON` variant during this course, it is the most verbose option of the three.

A example `INNER JOIN` looks like this:

    SELECT country.name, city.name
      FROM country
      JOIN city ON (country.capital = city.id);

An `INNER JOIN` removes all records that do not satisfy the condition, in this case

- All cities that are not a capital
- All countries without a capital

But what if we want all countries and, if they have a capital, their capital.
We could use an `LEFT JOIN`, it will not filter out records on the left-hand side,
even if they do not satisfy the join condition:

        SELECT country.name, city.name
          FROM country
     LEFT JOIN city ON (country.capital = city.id);

A `RIGHT JOIN` is not seen in the wild too often, it basically swaps the order of the tables:

        SELECT country.name, city.name
          FROM city
    RIGHT JOIN country ON (country.capital = city.id);

A `FULL OUTER JOIN` will not filter out any records in the join. This can be useful
if you want something with the non-overlapping parts of the `JOIN`. 
For example, to list all cars without a registration
and all registrations without cars, you could execute 1 query:

        SELECT c_id, c_name, cr_id, cr_number
          FROM car
     FULL JOIN car_registration ON (c_id = cr_c_id)
         WHERE     c_id IS NULL
               OR cr_id IS NULL;

As the `JOIN` clause filters rows, it shares some functionality with the `WHERE` clause, but
as you can see, the `LEFT RIGHT OUTER` influences the filtering.
What if we now only want the capital of Germany? We have a few options.

    SELECT country.name, city.name
      FROM country
      JOIN city ON (country.capital = city.id AND country.code='DEU');

    SELECT country.name, city.name
      FROM country
      JOIN city ON (country.capital = city.id)
     WHERE country.code='DEU';

For the execution of these queries *it doesn't matter* **where** you specify that the country is Germany.
However, for readability and conveying meaning it is preferred to:

- use the `JOIN` clause for *how* the relations are connected
- use the `WHERE` clause for filtering on *what* you want

A `CROSS JOIN` doesn't require a join condition, as it will join all records from the left-hand side
relation with all the records from the right-hand side relation. (resulting in a Cartesian product).
You can write it explicitly, or implicitly:

    -- This may take a long time executing
        SELECT *
          FROM country
    CROSS JOIN city;

        
    -- This may take a long time executing
    SELECT *
      FROM country,
           city;

Old-style joins are basically an implicit `CROSS JOIN` with the join condition pushed into the `WHERE` clause.
As the ANSI-style join is more versatile, less error-prone and more powerful we only use this style in the course.

## Hands-on
1. Get the `c_name` of the `car` with the registration (`cr_number`) `'BER TA 283'`
2. Get the `lastname` of the customer belonging to `orderid` 7107.
3. Get all the `lastname`s of the customers who have no orders and have a `zip` of `'30382'`

# ORDER BY
Documentation: [7.5. Sorting Rows](http://www.postgresql.org/docs/current/static/queries-order.html)

When executing queries the order of the result set is *undetermined*. Only when you specifically supply
an `ORDER BY` clause will the result be ordered.

If you do supply an `ORDER BY` clause it may mean that PostgreSQL needs to do an extra sorting step, therefore some
sane defaults:

- only sort if you need to sort
- if you need to sort specifically add an `ORDER BY` clause
- do not add an `ORDER BY` in views, functions, or subqueries

An `ORDER BY` clause takes the same kind of list as the `SELECT` clause, with an optional direction and an optional
location of `NULL`s.

A small example:

        SELECT continent, name
          FROM country
      ORDER BY continent ASC, name DESC;

In non-production code, when interactively running queries you can use an integer to point to the columns
of the `SELECT` clause:

        SELECT continent, name
          FROM country
      ORDER BY 1, 2 DESC;

## LIMIT and OFFSET
Documentation: [7.6. Sorting Rows](http://www.postgresql.org/docs/current/static/queries-limit.html)

With `LIMIT` and `OFFSET` you can fetch only a portion of the records. You could create a dashboard that
will only display 25 items, you could add a `LIMIT` to the query to reduce the number of records.
`LIMIT` is usually accompanied with an `ORDER BY` clause to get the *first* or *last* records.

Examples:

```sql
  SELECT name
    FROM country
ORDER BY name
   LIMIT 10;
```

```sql
  SELECT name
    FROM country
ORDER BY name
   LIMIT 10
  OFFSET 10;
```

## Hands-on
1. List the `c_name` of `car` ordered by `c_name`
2. List the `name` of the 5 countries with the lowest `population`
3. List the `name` of the 5 countries on the `surfacearea` scale, excluding the top 3
