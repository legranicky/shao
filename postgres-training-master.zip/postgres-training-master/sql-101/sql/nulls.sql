CREATE TABLE null_a (
    a boolean,
    b boolean
);

INSERT INTO null_a (a,b) VALUES
(true, true),
(true, false),
(true, null),
(false, false),
(false, null),
(null, null);

CREATE TABLE null_b(
    id serial primary key,
    name text
);

INSERT INTO null_b(name) VALUES
(''),
(null),
('abc');

CREATE TABLE null_c(
    id serial primary key,
    vals text[]
);

INSERT INTO null_c(vals) VALUES 
(null),
(ARRAY[]::text[]),
(ARRAY[null]),
(ARRAY[null,null]),
(ARRAY['abc',null]),
(ARRAY[null,'abc']),
(ARRAY['abc','def']);

