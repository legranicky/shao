DO
LANGUAGE plpgsql
$$
BEGIN
    IF NOT EXISTS (SELECT 1
                 FROM pg_type      pt
                 JOIN pg_namespace pn ON (typnamespace = pn.oid)
                WHERE typname='box'
                  AND nspname='public')
    THEN
        RAISE NOTICE 'Creating type';
        CREATE TYPE box AS (
            length int,
            width  int,
            height int
        );
    ELSE
        RAISE NOTICE 'Type already exists';
    END IF;
END;
$$;


CREATE OR REPLACE FUNCTION volume(box)
RETURNS integer
STRICT
LANGUAGE SQL
AS 
$BODY$
SELECT $1.length * $1.width * $1.height;
$BODY$
IMMUTABLE;
