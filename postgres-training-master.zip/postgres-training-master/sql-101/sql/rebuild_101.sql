\c postgres;

DROP DATABASE training101;

\ir prepare_101.sql
