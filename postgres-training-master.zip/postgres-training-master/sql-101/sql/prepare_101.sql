\connect postgres
CREATE DATABASE training101;

\set ON_ERROR_STOP on
\connect training101;
\ir ../../demo-dataset/dellstore/dellstore2-normal-1.0.sql
\ir ../../demo-dataset/world/world.sql
\ir cars.sql
\ir create_views.sql
\ir nulls.sql
VACUUM ANALYZE;

\set ON_ERROR_STOP off
