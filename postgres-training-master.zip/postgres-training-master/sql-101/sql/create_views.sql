CREATE OR REPLACE VIEW country_city_count AS (
    SELECT name,
           (SELECT count(*)
              FROM city
             WHERE city.countrycode=code)
      FROM country
);

COMMENT ON VIEW country_city_count IS
'This view is meant only to demonstrate what an impact
  SELECT *
  vs
  SELECT name
Has on this view. The inneffecient use of the select in the projection is on
purpose and is so on purpose';
