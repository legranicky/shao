CREATE TABLE car(
    c_id      serial  primary key,
    c_name    text not null
);

CREATE TABLE car_archive (LIKE car INCLUDING ALL);

CREATE UNIQUE INDEX on car(c_name);

CREATE TABLE car_registration(
    cr_id       serial primary key,
    cr_number   text not null,
    cr_c_id     integer references car(c_id)
);

CREATE UNIQUE INDEX ON car_registration(cr_number);

INSERT INTO car(c_name) VALUES ('BMW'),('Skoda'),('Mercedes'),('Lotus'),('Renault');
INSERT INTO car_registration (cr_number, cr_c_id) VALUES ('B AD 1234',2),('M BC 2938',4),('BER TA 283',5),('LER AB 1',null),('D AD 1982',null);
    
