You need a working Docker environment for this Docker image to run.
We may at some stage publish the image, for now just build it yourself.

Building the image:

	docker build --tag=postgres-training .

Running a container (forwarding your machine's port 6432 to the container port 5432):

	docker run -d -p 6432:5432 postgres-training

Connect to the cluster:

	psql -h localhost -p 6432 -U postgres -d postgres

Or, for people using boot2docker (on a Mac for example:)

	psql -h $(boot2docker ip) -p 6542 -d postgres

Use pg\_view to inspect the cluster

	docker exec -ti [name or hash of container] pg_view
