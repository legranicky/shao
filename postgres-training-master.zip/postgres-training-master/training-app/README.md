# Introduction
This application is meant to easily publish the trainings written in a format compatible with read the docs.

Current trainings can be found here:
[https://acid-training-app.acid.zalan.do](https://acid-training-app.acid.zalan.do)

To enable your training to be automatically served, do the following:

* Include a `mkdocs.yml` in your training directory
* Include some directives like:
    
    * `site_name`
    * `site_url`
    * `docs_dir`
    * `pages`

```text
site_name: PostgreSQL training course 101
site_url: https://sql-101.acid.zalan.do
docs_dir: .
pages:
  - Intro: index.md
  - Clients: clients.md
  - Warmup: warmup.md
  - Basics: basics.md
  - Advanced: advanced.md
```

# Create the application
To have a t2 micro instance run a mkdocs server do the following:

    senza create training-app.yaml [VERSION] ImageVersion=[DOCKER VERSION] ScalyrAccountKey=[Scalyr write key]

For example, the followong command:
    
    senza create tokyo ImageVersion=0.5 ScalyrAccountKey=abc

Serves https://acid-training-app-tokyo.acid.zalan.do which runs `pierone.stups.zalan.do/acid/training-app:0.5`
