#!/bin/bash


KEYFILE="/root/.ssh/postgres-training.githubenterprise.key"

if [ ! -z "${GIT_SSH_KEY}" ]
then
    echo "${GIT_SSH_KEY}" > "${KEYFILE}"
fi

chmod 0600 "${KEYFILE}"

git clone postgres-training.githubenterprise:acid/postgres-training "${GITDIR}"

if [ ! -z $GITBRANCH ]
then
    cd "${GITDIR}"
    git checkout "${GITBRANCH}"
fi

function rebuild_sites()
{
    date
    echo "(re)writing nginx configuration"

    repozip="${GITDIR}/repository.zip"
    default_index="/usr/share/nginx/html/index.html"

    cat << EOF > "${default_index}"
    <html>
    <head>
        <title>ACID training index</title>
    </head>
    <body>
    <h1>The following trainings are currently available</h1>
EOF

    for file in $(find /git -name 'mkdocs.y*ml')
    do
        site_url=$(awk -F ': ' '/site_url/{ print $2 }' "${file}")
        site_name=$(awk -F ': ' '/site_name/{ print $2 }' "${file}")
        EXITCODE=$?
        if [ $EXITCODE -ne 0 ]
        then
            continue
        fi

        domain_name=$(echo "${site_url}" | awk -F '/' '{print $3}')
        cd "$(dirname "${file}")"
        rm -rf site/
        mkdocs build

        site_dir="/sites/${domain_name}"
        rm -rf "${site_dir}"
        mv site/ "${site_dir}"

        ln "${repozip}" "${site_dir}"

    cat << EOF > /etc/nginx/sites-enabled/${domain_name}
    server {
        listen 8080;

        server_name ${domain_name};
        root ${site_dir};
        index index.html index.htm readme.htm readme.html;

    location / {
        root ${site_dir};
        try_files \$uri \$uri/ index.html index.htm readme.htm readme.html;
    }

    error_page 404 404.html;
    }
EOF

    cat << EOF >> "${default_index}"
    <a href="${site_url}">${site_name}</a><br/>
EOF
    done

    printf "</body>\n</html>\n\n" >> "${default_index}"
}

PREVCOMMIT=""
TRIGGERFILE="/rebuild_sites"
function update_sites()
{
    ## Git pull from the remote repository
    ## Then compare the commits to see if we need to update anything

    cd "$GITDIR"
    git pull
    date
    CURRENTCOMMIT=$(git rev-parse HEAD)
    if [ "$PREVCOMMIT" != "$CURRENTCOMMIT" ] || [ -f "${TRIGGERFILE}" ]
    then
        git archive --format=zip HEAD > "${GITDIR}/repository.zip"
        rebuild_sites
        kill -HUP $(pgrep -f 'master process nginx')
        if [ -f "${TRIGGERFILE}" ]
        then
            rm -v "${TRIGGERFILE}"
        fi
    fi
    PREVCOMMIT=$CURRENTCOMMIT
    sleep 110
}

(
    while true
    do
        update_sites
    done
) &

echo "Handing off to nginx"
exec nginx
