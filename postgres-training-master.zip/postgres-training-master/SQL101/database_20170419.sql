--
-- PostgreSQL database dump
--

-- Dumped from database version 9.5.5
-- Dumped by pg_dump version 9.5.5

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: sql101; Type: SCHEMA; Schema: -; Owner: avaczi
--

CREATE SCHEMA sql101;



SET search_path = sql101, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: city; Type: TABLE; Schema: sql101; Owner: avaczi
--

CREATE TABLE city (
    c_id integer NOT NULL,
    c_name text NOT NULL,
    c_country_code3 character(3) NOT NULL,
    c_population integer,
    c_distinction text,
    c_is_capital boolean DEFAULT false NOT NULL
);



--
-- Name: city2_c_id_seq; Type: SEQUENCE; Schema: sql101; Owner: avaczi
--

CREATE SEQUENCE city2_c_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: city2_c_id_seq; Type: SEQUENCE OWNED BY; Schema: sql101; Owner: avaczi
--

ALTER SEQUENCE city2_c_id_seq OWNED BY city.c_id;


--
-- Name: country; Type: TABLE; Schema: sql101; Owner: avaczi
--

CREATE TABLE country (
    c_code3 character(3),
    c_name text,
    c_code2 character(2),
    c_surface_area numeric,
    c_local_name text
);



-- Name: dropme; Type: SEQUENCE; Schema: sql101; Owner: avaczi
--

CREATE SEQUENCE dropme
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;



--
--

ALTER TABLE ONLY city ALTER COLUMN c_id SET DEFAULT nextval('city2_c_id_seq'::regclass);


--
-- Data for Name: city; Type: TABLE DATA; Schema: sql101; Owner: avaczi
--

COPY city (c_id, c_name, c_country_code3, c_population, c_distinction, c_is_capital) FROM stdin;
2	Qandahar	AFG	237500	\N	f
3	Herat	AFG	186800	\N	f
4	Mazar-e-Sharif	AFG	127800	\N	f
6	Rotterdam	NLD	593321	\N	f
7	Haag	NLD	440900	\N	f
8	Utrecht	NLD	234323	\N	f
9	Eindhoven	NLD	201843	\N	f
10	Tilburg	NLD	193238	\N	f
11	Groningen	NLD	172701	\N	f
12	Breda	NLD	160398	\N	f
13	Apeldoorn	NLD	153491	\N	f
14	Nijmegen	NLD	152463	\N	f
15	Enschede	NLD	149544	\N	f
16	Haarlem	NLD	148772	\N	f
17	Almere	NLD	142465	\N	f
18	Arnhem	NLD	138020	\N	f
19	Zaanstad	NLD	135621	\N	f
20	´s-Hertogenbosch	NLD	129170	\N	f
21	Amersfoort	NLD	126270	\N	f
22	Maastricht	NLD	122087	\N	f
23	Dordrecht	NLD	119811	\N	f
24	Leiden	NLD	117196	\N	f
25	Haarlemmermeer	NLD	110722	\N	f
26	Zoetermeer	NLD	110214	\N	f
27	Emmen	NLD	105853	\N	f
28	Zwolle	NLD	105819	\N	f
29	Ede	NLD	101574	\N	f
30	Delft	NLD	95268	\N	f
31	Heerlen	NLD	95052	\N	f
32	Alkmaar	NLD	92713	\N	f
36	Oran	DZA	609823	\N	f
37	Constantine	DZA	443727	\N	f
38	Annaba	DZA	222518	\N	f
39	Batna	DZA	183377	\N	f
40	Sétif	DZA	179055	\N	f
41	Sidi Bel Abbès	DZA	153106	\N	f
42	Skikda	DZA	128747	\N	f
43	Biskra	DZA	128281	\N	f
44	Blida (el-Boulaida)	DZA	127284	\N	f
45	Béjaïa	DZA	117162	\N	f
46	Mostaganem	DZA	115212	\N	f
47	Tébessa	DZA	112007	\N	f
48	Tlemcen (Tilimsen)	DZA	110242	\N	f
49	Béchar	DZA	107311	\N	f
50	Tiaret	DZA	100118	\N	f
51	Ech-Chleff (el-Asnam)	DZA	96794	\N	f
52	Ghardaïa	DZA	89415	\N	f
53	Tafuna	ASM	5200	\N	f
54	Fagatogo	ASM	2323	\N	f
57	Huambo	AGO	163100	\N	f
58	Lobito	AGO	130000	\N	f
59	Benguela	AGO	128300	\N	f
60	Namibe	AGO	118200	\N	f
61	South Hill	AIA	961	\N	f
64	Dubai	ARE	669181	\N	f
66	Sharja	ARE	320095	\N	f
67	al-Ayn	ARE	225970	\N	f
68	Ajman	ARE	114395	\N	f
70	La Matanza	ARG	1266461	\N	f
71	Córdoba	ARG	1157507	\N	f
72	Rosario	ARG	907718	\N	f
73	Lomas de Zamora	ARG	622013	\N	f
74	Quilmes	ARG	559249	\N	f
75	Almirante Brown	ARG	538918	\N	f
76	La Plata	ARG	521936	\N	f
77	Mar del Plata	ARG	512880	\N	f
78	San Miguel de Tucumán	ARG	470809	\N	f
79	Lanús	ARG	469735	\N	f
80	Merlo	ARG	463846	\N	f
81	General San Martín	ARG	422542	\N	f
82	Salta	ARG	367550	\N	f
83	Moreno	ARG	356993	\N	f
84	Santa Fé	ARG	353063	\N	f
85	Avellaneda	ARG	353046	\N	f
86	Tres de Febrero	ARG	352311	\N	f
87	Morón	ARG	349246	\N	f
88	Florencio Varela	ARG	315432	\N	f
89	San Isidro	ARG	306341	\N	f
90	Tigre	ARG	296226	\N	f
91	Malvinas Argentinas	ARG	290335	\N	f
92	Vicente López	ARG	288341	\N	f
93	Berazategui	ARG	276916	\N	f
94	Corrientes	ARG	258103	\N	f
95	San Miguel	ARG	248700	\N	f
96	Bahía Blanca	ARG	239810	\N	f
97	Esteban Echeverría	ARG	235760	\N	f
98	Resistencia	ARG	229212	\N	f
99	José C. Paz	ARG	221754	\N	f
100	Paraná	ARG	207041	\N	f
101	Godoy Cruz	ARG	206998	\N	f
102	Posadas	ARG	201273	\N	f
103	Guaymallén	ARG	200595	\N	f
104	Santiago del Estero	ARG	189947	\N	f
105	San Salvador de Jujuy	ARG	178748	\N	f
106	Hurlingham	ARG	170028	\N	f
107	Neuquén	ARG	167296	\N	f
108	Ituzaingó	ARG	158197	\N	f
109	San Fernando	ARG	153036	\N	f
110	Formosa	ARG	147636	\N	f
111	Las Heras	ARG	145823	\N	f
112	La Rioja	ARG	138117	\N	f
113	San Fernando del Valle de Cata	ARG	134935	\N	f
114	Río Cuarto	ARG	134355	\N	f
115	Comodoro Rivadavia	ARG	124104	\N	f
116	Mendoza	ARG	123027	\N	f
117	San Nicolás de los Arroyos	ARG	119302	\N	f
118	San Juan	ARG	119152	\N	f
119	Escobar	ARG	116675	\N	f
120	Concordia	ARG	116485	\N	f
121	Pilar	ARG	113428	\N	f
122	San Luis	ARG	110136	\N	f
123	Ezeiza	ARG	99578	\N	f
124	San Rafael	ARG	94651	\N	f
125	Tandil	ARG	91101	\N	f
127	Gjumri	ARM	211700	\N	f
128	Vanadzor	ARM	172700	\N	f
130	Sydney	AUS	3276207	\N	f
131	Melbourne	AUS	2865329	\N	f
132	Brisbane	AUS	1291117	\N	f
133	Perth	AUS	1096829	\N	f
134	Adelaide	AUS	978100	\N	f
136	Gold Coast	AUS	311932	\N	f
137	Newcastle	AUS	270324	\N	f
138	Central Coast	AUS	227657	\N	f
139	Wollongong	AUS	219761	\N	f
140	Hobart	AUS	126118	\N	f
141	Geelong	AUS	125382	\N	f
142	Townsville	AUS	109914	\N	f
1	Kabul	AFG	1780000	\N	t
143	Cairns	AUS	92273	\N	f
145	Gäncä	AZE	299300	\N	f
146	Sumqayit	AZE	283000	\N	f
147	Mingäçevir	AZE	93900	\N	f
151	Chittagong	BGD	1392860	\N	f
152	Khulna	BGD	663340	\N	f
153	Rajshahi	BGD	294056	\N	f
154	Narayanganj	BGD	202134	\N	f
155	Rangpur	BGD	191398	\N	f
156	Mymensingh	BGD	188713	\N	f
157	Barisal	BGD	170232	\N	f
158	Tungi	BGD	168702	\N	f
159	Jessore	BGD	139710	\N	f
160	Comilla	BGD	135313	\N	f
161	Nawabganj	BGD	130577	\N	f
162	Dinajpur	BGD	127815	\N	f
163	Bogra	BGD	120170	\N	f
164	Sylhet	BGD	117396	\N	f
165	Brahmanbaria	BGD	109032	\N	f
166	Tangail	BGD	106004	\N	f
167	Jamalpur	BGD	103556	\N	f
168	Pabna	BGD	103277	\N	f
169	Naogaon	BGD	101266	\N	f
170	Sirajganj	BGD	99669	\N	f
171	Narsinghdi	BGD	98342	\N	f
172	Saidpur	BGD	96777	\N	f
173	Gazipur	BGD	96717	\N	f
175	Antwerpen	BEL	446525	\N	f
176	Gent	BEL	224180	\N	f
177	Charleroi	BEL	200827	\N	f
178	Liège	BEL	185639	\N	f
180	Brugge	BEL	116246	\N	f
181	Schaerbeek	BEL	105692	\N	f
182	Namur	BEL	105419	\N	f
183	Mons	BEL	90935	\N	f
184	Belize City	BLZ	55810	\N	f
186	Cotonou	BEN	536827	\N	f
188	Djougou	BEN	134099	\N	f
189	Parakou	BEN	103577	\N	f
190	Saint George	BMU	1800	\N	f
193	Santa Cruz de la Sierra	BOL	935361	\N	f
195	El Alto	BOL	534466	\N	f
196	Cochabamba	BOL	482800	\N	f
197	Oruro	BOL	223553	\N	f
199	Potosí	BOL	140642	\N	f
200	Tarija	BOL	125255	\N	f
202	Banja Luka	BIH	143079	\N	f
203	Zenica	BIH	96027	\N	f
205	Francistown	BWA	101805	\N	f
206	São Paulo	BRA	9968485	\N	f
207	Rio de Janeiro	BRA	5598953	\N	f
208	Salvador	BRA	2302832	\N	f
209	Belo Horizonte	BRA	2139125	\N	f
210	Fortaleza	BRA	2097757	\N	f
212	Curitiba	BRA	1584232	\N	f
213	Recife	BRA	1378087	\N	f
214	Porto Alegre	BRA	1314032	\N	f
215	Manaus	BRA	1255049	\N	f
216	Belém	BRA	1186926	\N	f
217	Guarulhos	BRA	1095874	\N	f
218	Goiânia	BRA	1056330	\N	f
219	Campinas	BRA	950043	\N	f
220	São Gonçalo	BRA	869254	\N	f
221	Nova Iguaçu	BRA	862225	\N	f
222	São Luís	BRA	837588	\N	f
223	Maceió	BRA	786288	\N	f
224	Duque de Caxias	BRA	746758	\N	f
225	São Bernardo do Campo	BRA	723132	\N	f
226	Teresina	BRA	691942	\N	f
227	Natal	BRA	688955	\N	f
228	Osasco	BRA	659604	\N	f
229	Campo Grande	BRA	649593	\N	f
230	Santo André	BRA	630073	\N	f
231	João Pessoa	BRA	584029	\N	f
232	Jaboatão dos Guararapes	BRA	558680	\N	f
233	Contagem	BRA	520801	\N	f
234	São José dos Campos	BRA	515553	\N	f
235	Uberlândia	BRA	487222	\N	f
236	Feira de Santana	BRA	479992	\N	f
237	Ribeirão Preto	BRA	473276	\N	f
238	Sorocaba	BRA	466823	\N	f
239	Niterói	BRA	459884	\N	f
240	Cuiabá	BRA	453813	\N	f
241	Juiz de Fora	BRA	450288	\N	f
242	Aracaju	BRA	445555	\N	f
243	São João de Meriti	BRA	440052	\N	f
244	Londrina	BRA	432257	\N	f
245	Joinville	BRA	428011	\N	f
246	Belford Roxo	BRA	425194	\N	f
247	Santos	BRA	408748	\N	f
248	Ananindeua	BRA	400940	\N	f
249	Campos dos Goytacazes	BRA	398418	\N	f
250	Mauá	BRA	375055	\N	f
251	Carapicuíba	BRA	357552	\N	f
252	Olinda	BRA	354732	\N	f
253	Campina Grande	BRA	352497	\N	f
254	São José do Rio Preto	BRA	351944	\N	f
255	Caxias do Sul	BRA	349581	\N	f
256	Moji das Cruzes	BRA	339194	\N	f
257	Diadema	BRA	335078	\N	f
258	Aparecida de Goiânia	BRA	324662	\N	f
259	Piracicaba	BRA	319104	\N	f
260	Cariacica	BRA	319033	\N	f
261	Vila Velha	BRA	318758	\N	f
262	Pelotas	BRA	315415	\N	f
263	Bauru	BRA	313670	\N	f
264	Porto Velho	BRA	309750	\N	f
265	Serra	BRA	302666	\N	f
266	Betim	BRA	302108	\N	f
267	Jundíaí	BRA	296127	\N	f
268	Canoas	BRA	294125	\N	f
269	Franca	BRA	290139	\N	f
270	São Vicente	BRA	286848	\N	f
271	Maringá	BRA	286461	\N	f
272	Montes Claros	BRA	286058	\N	f
273	Anápolis	BRA	282197	\N	f
274	Florianópolis	BRA	281928	\N	f
275	Petrópolis	BRA	279183	\N	f
276	Itaquaquecetuba	BRA	270874	\N	f
277	Vitória	BRA	270626	\N	f
278	Ponta Grossa	BRA	268013	\N	f
279	Rio Branco	BRA	259537	\N	f
280	Foz do Iguaçu	BRA	259425	\N	f
281	Macapá	BRA	256033	\N	f
282	Ilhéus	BRA	254970	\N	f
283	Vitória da Conquista	BRA	253587	\N	f
144	Baku	AZE	1787800	\N	t
148	Nassau	BHS	172000	\N	t
284	Uberaba	BRA	249225	\N	f
285	Paulista	BRA	248473	\N	f
286	Limeira	BRA	245497	\N	f
287	Blumenau	BRA	244379	\N	f
288	Caruaru	BRA	244247	\N	f
289	Santarém	BRA	241771	\N	f
290	Volta Redonda	BRA	240315	\N	f
291	Novo Hamburgo	BRA	239940	\N	f
292	Caucaia	BRA	238738	\N	f
293	Santa Maria	BRA	238473	\N	f
294	Cascavel	BRA	237510	\N	f
295	Guarujá	BRA	237206	\N	f
296	Ribeirão das Neves	BRA	232685	\N	f
297	Governador Valadares	BRA	231724	\N	f
298	Taubaté	BRA	229130	\N	f
299	Imperatriz	BRA	224564	\N	f
300	Gravataí	BRA	223011	\N	f
301	Embu	BRA	222223	\N	f
302	Mossoró	BRA	214901	\N	f
303	Várzea Grande	BRA	214435	\N	f
304	Petrolina	BRA	210540	\N	f
305	Barueri	BRA	208426	\N	f
306	Viamão	BRA	207557	\N	f
307	Ipatinga	BRA	206338	\N	f
308	Juazeiro	BRA	201073	\N	f
309	Juazeiro do Norte	BRA	199636	\N	f
310	Taboão da Serra	BRA	197550	\N	f
311	São José dos Pinhais	BRA	196884	\N	f
312	Magé	BRA	196147	\N	f
313	Suzano	BRA	195434	\N	f
314	São Leopoldo	BRA	189258	\N	f
315	Marília	BRA	188691	\N	f
316	São Carlos	BRA	187122	\N	f
317	Sumaré	BRA	186205	\N	f
318	Presidente Prudente	BRA	185340	\N	f
319	Divinópolis	BRA	185047	\N	f
320	Sete Lagoas	BRA	182984	\N	f
321	Rio Grande	BRA	182222	\N	f
322	Itabuna	BRA	182148	\N	f
323	Jequié	BRA	179128	\N	f
324	Arapiraca	BRA	178988	\N	f
325	Colombo	BRA	177764	\N	f
326	Americana	BRA	177409	\N	f
327	Alvorada	BRA	175574	\N	f
328	Araraquara	BRA	174381	\N	f
329	Itaboraí	BRA	173977	\N	f
330	Santa Bárbara d´Oeste	BRA	171657	\N	f
331	Nova Friburgo	BRA	170697	\N	f
332	Jacareí	BRA	170356	\N	f
333	Araçatuba	BRA	169303	\N	f
334	Barra Mansa	BRA	168953	\N	f
335	Praia Grande	BRA	168434	\N	f
336	Marabá	BRA	167795	\N	f
337	Criciúma	BRA	167661	\N	f
338	Boa Vista	BRA	167185	\N	f
339	Passo Fundo	BRA	166343	\N	f
340	Dourados	BRA	164716	\N	f
341	Santa Luzia	BRA	164704	\N	f
342	Rio Claro	BRA	163551	\N	f
343	Maracanaú	BRA	162022	\N	f
344	Guarapuava	BRA	160510	\N	f
345	Rondonópolis	BRA	155115	\N	f
346	São José	BRA	155105	\N	f
347	Cachoeiro de Itapemirim	BRA	155024	\N	f
348	Nilópolis	BRA	153383	\N	f
349	Itapevi	BRA	150664	\N	f
350	Cabo de Santo Agostinho	BRA	149964	\N	f
351	Camaçari	BRA	149146	\N	f
352	Sobral	BRA	146005	\N	f
353	Itajaí	BRA	145197	\N	f
354	Chapecó	BRA	144158	\N	f
355	Cotia	BRA	140042	\N	f
356	Lages	BRA	139570	\N	f
357	Ferraz de Vasconcelos	BRA	139283	\N	f
358	Indaiatuba	BRA	135968	\N	f
359	Hortolândia	BRA	135755	\N	f
360	Caxias	BRA	133980	\N	f
361	São Caetano do Sul	BRA	133321	\N	f
362	Itu	BRA	132736	\N	f
363	Nossa Senhora do Socorro	BRA	131351	\N	f
364	Parnaíba	BRA	129756	\N	f
365	Poços de Caldas	BRA	129683	\N	f
366	Teresópolis	BRA	128079	\N	f
367	Barreiras	BRA	127801	\N	f
368	Castanhal	BRA	127634	\N	f
369	Alagoinhas	BRA	126820	\N	f
370	Itapecerica da Serra	BRA	126672	\N	f
371	Uruguaiana	BRA	126305	\N	f
372	Paranaguá	BRA	126076	\N	f
373	Ibirité	BRA	125982	\N	f
374	Timon	BRA	125812	\N	f
375	Luziânia	BRA	125597	\N	f
376	Macaé	BRA	125597	\N	f
377	Teófilo Otoni	BRA	124489	\N	f
378	Moji-Guaçu	BRA	123782	\N	f
379	Palmas	BRA	121919	\N	f
380	Pindamonhangaba	BRA	121904	\N	f
381	Francisco Morato	BRA	121197	\N	f
382	Bagé	BRA	120793	\N	f
383	Sapucaia do Sul	BRA	120217	\N	f
384	Cabo Frio	BRA	119503	\N	f
385	Itapetininga	BRA	119391	\N	f
386	Patos de Minas	BRA	119262	\N	f
387	Camaragibe	BRA	118968	\N	f
388	Bragança Paulista	BRA	116929	\N	f
389	Queimados	BRA	115020	\N	f
390	Araguaína	BRA	114948	\N	f
391	Garanhuns	BRA	114603	\N	f
392	Vitória de Santo Antão	BRA	113595	\N	f
393	Santa Rita	BRA	113135	\N	f
394	Barbacena	BRA	113079	\N	f
395	Abaetetuba	BRA	111258	\N	f
396	Jaú	BRA	109965	\N	f
397	Lauro de Freitas	BRA	109236	\N	f
398	Franco da Rocha	BRA	108964	\N	f
399	Teixeira de Freitas	BRA	108441	\N	f
400	Varginha	BRA	108314	\N	f
401	Ribeirão Pires	BRA	108121	\N	f
402	Sabará	BRA	107781	\N	f
403	Catanduva	BRA	107761	\N	f
404	Rio Verde	BRA	107755	\N	f
405	Botucatu	BRA	107663	\N	f
406	Colatina	BRA	107354	\N	f
407	Santa Cruz do Sul	BRA	106734	\N	f
408	Linhares	BRA	106278	\N	f
409	Apucarana	BRA	105114	\N	f
410	Barretos	BRA	104156	\N	f
411	Guaratinguetá	BRA	103433	\N	f
412	Cachoeirinha	BRA	103240	\N	f
413	Codó	BRA	103153	\N	f
414	Jaraguá do Sul	BRA	102580	\N	f
415	Cubatão	BRA	102372	\N	f
416	Itabira	BRA	102217	\N	f
417	Itaituba	BRA	101320	\N	f
418	Araras	BRA	101046	\N	f
419	Resende	BRA	100627	\N	f
420	Atibaia	BRA	100356	\N	f
421	Pouso Alegre	BRA	100028	\N	f
422	Toledo	BRA	99387	\N	f
423	Crato	BRA	98965	\N	f
424	Passos	BRA	98570	\N	f
425	Araguari	BRA	98399	\N	f
426	São José de Ribamar	BRA	98318	\N	f
427	Pinhais	BRA	98198	\N	f
428	Sertãozinho	BRA	98140	\N	f
429	Conselheiro Lafaiete	BRA	97507	\N	f
430	Paulo Afonso	BRA	97291	\N	f
431	Angra dos Reis	BRA	96864	\N	f
432	Eunápolis	BRA	96610	\N	f
433	Salto	BRA	96348	\N	f
434	Ourinhos	BRA	96291	\N	f
435	Parnamirim	BRA	96210	\N	f
436	Jacobina	BRA	96131	\N	f
437	Coronel Fabriciano	BRA	95933	\N	f
438	Birigui	BRA	94685	\N	f
439	Tatuí	BRA	93897	\N	f
440	Ji-Paraná	BRA	93346	\N	f
441	Bacabal	BRA	93121	\N	f
442	Cametá	BRA	92779	\N	f
443	Guaíba	BRA	92224	\N	f
444	São Lourenço da Mata	BRA	91999	\N	f
445	Santana do Livramento	BRA	91779	\N	f
446	Votorantim	BRA	91777	\N	f
447	Campo Largo	BRA	91203	\N	f
448	Patos	BRA	90519	\N	f
449	Ituiutaba	BRA	90507	\N	f
450	Corumbá	BRA	90111	\N	f
451	Palhoça	BRA	89465	\N	f
452	Barra do Piraí	BRA	89388	\N	f
453	Bento Gonçalves	BRA	89254	\N	f
454	Poá	BRA	89236	\N	f
455	Águas Lindas de Goiás	BRA	89200	\N	f
457	Birmingham	GBR	1013000	\N	f
458	Glasgow	GBR	619680	\N	f
459	Liverpool	GBR	461000	\N	f
460	Edinburgh	GBR	450180	\N	f
461	Sheffield	GBR	431607	\N	f
462	Manchester	GBR	430000	\N	f
463	Leeds	GBR	424194	\N	f
464	Bristol	GBR	402000	\N	f
465	Cardiff	GBR	321000	\N	f
466	Coventry	GBR	304000	\N	f
467	Leicester	GBR	294000	\N	f
468	Bradford	GBR	289376	\N	f
469	Belfast	GBR	287500	\N	f
470	Nottingham	GBR	287000	\N	f
471	Kingston upon Hull	GBR	262000	\N	f
472	Plymouth	GBR	253000	\N	f
473	Stoke-on-Trent	GBR	252000	\N	f
474	Wolverhampton	GBR	242000	\N	f
475	Derby	GBR	236000	\N	f
476	Swansea	GBR	230000	\N	f
477	Southampton	GBR	216000	\N	f
478	Aberdeen	GBR	213070	\N	f
479	Northampton	GBR	196000	\N	f
480	Dudley	GBR	192171	\N	f
481	Portsmouth	GBR	190000	\N	f
482	Newcastle upon Tyne	GBR	189150	\N	f
483	Sunderland	GBR	183310	\N	f
484	Luton	GBR	183000	\N	f
485	Swindon	GBR	180000	\N	f
486	Southend-on-Sea	GBR	176000	\N	f
487	Walsall	GBR	174739	\N	f
488	Bournemouth	GBR	162000	\N	f
489	Peterborough	GBR	156000	\N	f
490	Brighton	GBR	156124	\N	f
491	Blackpool	GBR	151000	\N	f
492	Dundee	GBR	146690	\N	f
493	West Bromwich	GBR	146386	\N	f
494	Reading	GBR	148000	\N	f
495	Oldbury/Smethwick (Warley)	GBR	145542	\N	f
496	Middlesbrough	GBR	145000	\N	f
497	Huddersfield	GBR	143726	\N	f
498	Oxford	GBR	144000	\N	f
499	Poole	GBR	141000	\N	f
500	Bolton	GBR	139020	\N	f
501	Blackburn	GBR	140000	\N	f
502	Newport	GBR	139000	\N	f
503	Preston	GBR	135000	\N	f
504	Stockport	GBR	132813	\N	f
505	Norwich	GBR	124000	\N	f
506	Rotherham	GBR	121380	\N	f
507	Cambridge	GBR	121000	\N	f
508	Watford	GBR	113080	\N	f
509	Ipswich	GBR	114000	\N	f
510	Slough	GBR	112000	\N	f
511	Exeter	GBR	111000	\N	f
512	Cheltenham	GBR	106000	\N	f
513	Gloucester	GBR	107000	\N	f
514	Saint Helens	GBR	106293	\N	f
515	Sutton Coldfield	GBR	106001	\N	f
516	York	GBR	104425	\N	f
517	Oldham	GBR	103931	\N	f
518	Basildon	GBR	100924	\N	f
519	Worthing	GBR	100000	\N	f
520	Chelmsford	GBR	97451	\N	f
521	Colchester	GBR	96063	\N	f
522	Crawley	GBR	97000	\N	f
523	Gillingham	GBR	92000	\N	f
524	Solihull	GBR	94531	\N	f
525	Rochdale	GBR	94313	\N	f
526	Birkenhead	GBR	93087	\N	f
527	Worcester	GBR	95000	\N	f
528	Hartlepool	GBR	92000	\N	f
529	Halifax	GBR	91069	\N	f
530	Woking/Byfleet	GBR	92000	\N	f
531	Southport	GBR	90959	\N	f
532	Maidstone	GBR	90878	\N	f
533	Eastbourne	GBR	90000	\N	f
534	Grimsby	GBR	89000	\N	f
535	Saint Helier	GBR	27523	\N	f
536	Douglas	GBR	23487	\N	f
540	Plovdiv	BGR	342584	\N	f
541	Varna	BGR	299801	\N	f
542	Burgas	BGR	195255	\N	f
543	Ruse	BGR	166467	\N	f
544	Stara Zagora	BGR	147939	\N	f
545	Pleven	BGR	121952	\N	f
546	Sliven	BGR	105530	\N	f
547	Dobric	BGR	100399	\N	f
548	Šumen	BGR	94686	\N	f
550	Bobo-Dioulasso	BFA	300000	\N	f
551	Koudougou	BFA	105000	\N	f
555	Puente Alto	CHL	386236	\N	f
556	Viña del Mar	CHL	312493	\N	f
557	Valparaíso	CHL	293800	\N	f
558	Talcahuano	CHL	277752	\N	f
559	Antofagasta	CHL	251429	\N	f
560	San Bernardo	CHL	241910	\N	f
561	Temuco	CHL	233041	\N	f
554	Santiago de Chile	CHL	4703954	\N	t
562	Concepción	CHL	217664	\N	f
563	Rancagua	CHL	212977	\N	f
564	Arica	CHL	189036	\N	f
565	Talca	CHL	187557	\N	f
566	Chillán	CHL	178182	\N	f
567	Iquique	CHL	177892	\N	f
568	Los Angeles	CHL	158215	\N	f
569	Puerto Montt	CHL	152194	\N	f
570	Coquimbo	CHL	143353	\N	f
571	Osorno	CHL	141468	\N	f
572	La Serena	CHL	137409	\N	f
573	Calama	CHL	137265	\N	f
574	Valdivia	CHL	133106	\N	f
575	Punta Arenas	CHL	125631	\N	f
576	Copiapó	CHL	120128	\N	f
577	Quilpué	CHL	118857	\N	f
578	Curicó	CHL	115766	\N	f
579	Ovalle	CHL	94854	\N	f
580	Coronel	CHL	93061	\N	f
581	San Pedro de la Paz	CHL	91684	\N	f
582	Melipilla	CHL	91056	\N	f
588	Santiago de los Caballeros	DOM	365463	\N	f
589	La Romana	DOM	140204	\N	f
590	San Pedro de Macorís	DOM	124735	\N	f
591	San Francisco de Macorís	DOM	108485	\N	f
592	San Felipe de Puerto Plata	DOM	89423	\N	f
593	Guayaquil	ECU	2070040	\N	f
595	Cuenca	ECU	270353	\N	f
596	Machala	ECU	210368	\N	f
597	Santo Domingo de los Colorados	ECU	202111	\N	f
598	Portoviejo	ECU	176413	\N	f
599	Ambato	ECU	169612	\N	f
600	Manta	ECU	164739	\N	f
601	Duran [Eloy Alfaro]	ECU	152514	\N	f
602	Ibarra	ECU	130643	\N	f
603	Quevedo	ECU	129631	\N	f
604	Milagro	ECU	124177	\N	f
605	Loja	ECU	123875	\N	f
606	Ríobamba	ECU	123163	\N	f
607	Esmeraldas	ECU	123045	\N	f
609	Alexandria	EGY	3328196	\N	f
610	Giza	EGY	2221868	\N	f
611	Shubra al-Khayma	EGY	870716	\N	f
612	Port Said	EGY	469533	\N	f
613	Suez	EGY	417610	\N	f
614	al-Mahallat al-Kubra	EGY	395402	\N	f
615	Tanta	EGY	371010	\N	f
616	al-Mansura	EGY	369621	\N	f
617	Luxor	EGY	360503	\N	f
618	Asyut	EGY	343498	\N	f
619	Bahtim	EGY	275807	\N	f
620	Zagazig	EGY	267351	\N	f
621	al-Faiyum	EGY	260964	\N	f
622	Ismailia	EGY	254477	\N	f
623	Kafr al-Dawwar	EGY	231978	\N	f
624	Assuan	EGY	219017	\N	f
625	Damanhur	EGY	212203	\N	f
626	al-Minya	EGY	201360	\N	f
627	Bani Suwayf	EGY	172032	\N	f
628	Qina	EGY	171275	\N	f
629	Sawhaj	EGY	170125	\N	f
630	Shibin al-Kawm	EGY	159909	\N	f
631	Bulaq al-Dakrur	EGY	148787	\N	f
632	Banha	EGY	145792	\N	f
633	Warraq al-Arab	EGY	127108	\N	f
634	Kafr al-Shaykh	EGY	124819	\N	f
635	Mallawi	EGY	119283	\N	f
636	Bilbays	EGY	113608	\N	f
637	Mit Ghamr	EGY	101801	\N	f
638	al-Arish	EGY	100447	\N	f
639	Talkha	EGY	97700	\N	f
640	Qalyub	EGY	97200	\N	f
641	Jirja	EGY	95400	\N	f
642	Idfu	EGY	94200	\N	f
643	al-Hawamidiya	EGY	91700	\N	f
644	Disuq	EGY	91300	\N	f
646	Santa Ana	SLV	139389	\N	f
647	Mejicanos	SLV	138800	\N	f
648	Soyapango	SLV	129800	\N	f
649	San Miguel	SLV	127696	\N	f
650	Nueva San Salvador	SLV	98400	\N	f
651	Apopa	SLV	88800	\N	f
654	Barcelona	ESP	1503451	\N	f
655	Valencia	ESP	739412	\N	f
656	Sevilla	ESP	701927	\N	f
657	Zaragoza	ESP	603367	\N	f
658	Málaga	ESP	530553	\N	f
659	Bilbao	ESP	357589	\N	f
660	Las Palmas de Gran Canaria	ESP	354757	\N	f
661	Murcia	ESP	353504	\N	f
662	Palma de Mallorca	ESP	326993	\N	f
663	Valladolid	ESP	319998	\N	f
664	Córdoba	ESP	311708	\N	f
665	Vigo	ESP	283670	\N	f
666	Alicante [Alacant]	ESP	272432	\N	f
667	Gijón	ESP	267980	\N	f
668	L´Hospitalet de Llobregat	ESP	247986	\N	f
669	Granada	ESP	244767	\N	f
670	A Coruña (La Coruña)	ESP	243402	\N	f
671	Vitoria-Gasteiz	ESP	217154	\N	f
672	Santa Cruz de Tenerife	ESP	213050	\N	f
673	Badalona	ESP	209635	\N	f
674	Oviedo	ESP	200453	\N	f
675	Móstoles	ESP	195351	\N	f
676	Elche [Elx]	ESP	193174	\N	f
677	Sabadell	ESP	184859	\N	f
678	Santander	ESP	184165	\N	f
679	Jerez de la Frontera	ESP	182660	\N	f
680	Pamplona [Iruña]	ESP	180483	\N	f
681	Donostia-San Sebastián	ESP	179208	\N	f
682	Cartagena	ESP	177709	\N	f
683	Leganés	ESP	173163	\N	f
684	Fuenlabrada	ESP	171173	\N	f
685	Almería	ESP	169027	\N	f
686	Terrassa	ESP	168695	\N	f
687	Alcalá de Henares	ESP	164463	\N	f
688	Burgos	ESP	162802	\N	f
689	Salamanca	ESP	158720	\N	f
690	Albacete	ESP	147527	\N	f
691	Getafe	ESP	145371	\N	f
692	Cádiz	ESP	142449	\N	f
693	Alcorcón	ESP	142048	\N	f
694	Huelva	ESP	140583	\N	f
695	León	ESP	139809	\N	f
696	Castellón de la Plana [Castell	ESP	139712	\N	f
697	Badajoz	ESP	136613	\N	f
698	[San Cristóbal de] la Laguna	ESP	127945	\N	f
699	Logroño	ESP	127093	\N	f
583	Avarua	COK	11900	\N	t
700	Santa Coloma de Gramenet	ESP	120802	\N	f
701	Tarragona	ESP	113016	\N	f
702	Lleida (Lérida)	ESP	112207	\N	f
703	Jaén	ESP	109247	\N	f
704	Ourense (Orense)	ESP	109120	\N	f
705	Mataró	ESP	104095	\N	f
706	Algeciras	ESP	103106	\N	f
707	Marbella	ESP	101144	\N	f
708	Barakaldo	ESP	98212	\N	f
709	Dos Hermanas	ESP	94591	\N	f
710	Santiago de Compostela	ESP	93745	\N	f
711	Torrejón de Ardoz	ESP	92262	\N	f
713	Soweto	ZAF	904165	\N	f
714	Johannesburg	ZAF	756653	\N	f
715	Port Elizabeth	ZAF	752319	\N	f
717	Inanda	ZAF	634065	\N	f
718	Durban	ZAF	566120	\N	f
719	Vanderbijlpark	ZAF	468931	\N	f
720	Kempton Park	ZAF	442633	\N	f
721	Alberton	ZAF	410102	\N	f
722	Pinetown	ZAF	378810	\N	f
723	Pietermaritzburg	ZAF	370190	\N	f
724	Benoni	ZAF	365467	\N	f
725	Randburg	ZAF	341288	\N	f
726	Umlazi	ZAF	339233	\N	f
728	Vereeniging	ZAF	328535	\N	f
729	Wonderboom	ZAF	283289	\N	f
730	Roodepoort	ZAF	279340	\N	f
731	Boksburg	ZAF	262648	\N	f
732	Klerksdorp	ZAF	261911	\N	f
733	Soshanguve	ZAF	242727	\N	f
734	Newcastle	ZAF	222993	\N	f
735	East London	ZAF	221047	\N	f
736	Welkom	ZAF	203296	\N	f
737	Kimberley	ZAF	197254	\N	f
738	Uitenhage	ZAF	192120	\N	f
739	Chatsworth	ZAF	189885	\N	f
740	Mdantsane	ZAF	182639	\N	f
741	Krugersdorp	ZAF	181503	\N	f
742	Botshabelo	ZAF	177971	\N	f
743	Brakpan	ZAF	171363	\N	f
744	Witbank	ZAF	167183	\N	f
745	Oberholzer	ZAF	164367	\N	f
746	Germiston	ZAF	164252	\N	f
747	Springs	ZAF	162072	\N	f
748	Westonaria	ZAF	159632	\N	f
749	Randfontein	ZAF	120838	\N	f
750	Paarl	ZAF	105768	\N	f
751	Potchefstroom	ZAF	101817	\N	f
752	Rustenburg	ZAF	97008	\N	f
753	Nigel	ZAF	96734	\N	f
754	George	ZAF	93818	\N	f
755	Ladysmith	ZAF	89292	\N	f
757	Dire Dawa	ETH	164851	\N	f
758	Nazret	ETH	127842	\N	f
759	Gonder	ETH	112249	\N	f
760	Dese	ETH	97314	\N	f
761	Mekele	ETH	96938	\N	f
762	Bahir Dar	ETH	96140	\N	f
765	Quezon	PHL	2173831	\N	f
767	Kalookan	PHL	1177604	\N	f
768	Davao	PHL	1147116	\N	f
769	Cebu	PHL	718821	\N	f
770	Zamboanga	PHL	601794	\N	f
771	Pasig	PHL	505058	\N	f
772	Valenzuela	PHL	485433	\N	f
773	Las Piñas	PHL	472780	\N	f
774	Antipolo	PHL	470866	\N	f
775	Taguig	PHL	467375	\N	f
776	Cagayan de Oro	PHL	461877	\N	f
777	Parañaque	PHL	449811	\N	f
778	Makati	PHL	444867	\N	f
779	Bacolod	PHL	429076	\N	f
780	General Santos	PHL	411822	\N	f
781	Marikina	PHL	391170	\N	f
782	Dasmariñas	PHL	379520	\N	f
783	Muntinlupa	PHL	379310	\N	f
784	Iloilo	PHL	365820	\N	f
785	Pasay	PHL	354908	\N	f
786	Malabon	PHL	338855	\N	f
787	San José del Monte	PHL	315807	\N	f
788	Bacoor	PHL	305699	\N	f
789	Iligan	PHL	285061	\N	f
790	Calamba	PHL	281146	\N	f
791	Mandaluyong	PHL	278474	\N	f
792	Butuan	PHL	267279	\N	f
793	Angeles	PHL	263971	\N	f
794	Tarlac	PHL	262481	\N	f
795	Mandaue	PHL	259728	\N	f
796	Baguio	PHL	252386	\N	f
797	Batangas	PHL	247588	\N	f
798	Cainta	PHL	242511	\N	f
799	San Pedro	PHL	231403	\N	f
800	Navotas	PHL	230403	\N	f
801	Cabanatuan	PHL	222859	\N	f
802	San Fernando	PHL	221857	\N	f
803	Lipa	PHL	218447	\N	f
804	Lapu-Lapu	PHL	217019	\N	f
805	San Pablo	PHL	207927	\N	f
806	Biñan	PHL	201186	\N	f
807	Taytay	PHL	198183	\N	f
808	Lucena	PHL	196075	\N	f
809	Imus	PHL	195482	\N	f
810	Olongapo	PHL	194260	\N	f
811	Binangonan	PHL	187691	\N	f
812	Santa Rosa	PHL	185633	\N	f
813	Tagum	PHL	179531	\N	f
814	Tacloban	PHL	178639	\N	f
815	Malolos	PHL	175291	\N	f
816	Mabalacat	PHL	171045	\N	f
817	Cotabato	PHL	163849	\N	f
818	Meycauayan	PHL	163037	\N	f
819	Puerto Princesa	PHL	161912	\N	f
820	Legazpi	PHL	157010	\N	f
821	Silang	PHL	156137	\N	f
822	Ormoc	PHL	154297	\N	f
823	San Carlos	PHL	154264	\N	f
824	Kabankalan	PHL	149769	\N	f
825	Talisay	PHL	148110	\N	f
826	Valencia	PHL	147924	\N	f
827	Calbayog	PHL	147187	\N	f
828	Santa Maria	PHL	144282	\N	f
829	Pagadian	PHL	142515	\N	f
830	Cadiz	PHL	141954	\N	f
831	Bago	PHL	141721	\N	f
832	Toledo	PHL	141174	\N	f
833	Naga	PHL	137810	\N	f
834	San Mateo	PHL	135603	\N	f
835	Panabo	PHL	133950	\N	f
836	Koronadal	PHL	133786	\N	f
837	Marawi	PHL	131090	\N	f
838	Dagupan	PHL	130328	\N	f
839	Sagay	PHL	129765	\N	f
840	Roxas	PHL	126352	\N	f
841	Lubao	PHL	125699	\N	f
842	Digos	PHL	125171	\N	f
843	San Miguel	PHL	123824	\N	f
844	Malaybalay	PHL	123672	\N	f
845	Tuguegarao	PHL	120645	\N	f
846	Ilagan	PHL	119990	\N	f
847	Baliuag	PHL	119675	\N	f
848	Surigao	PHL	118534	\N	f
849	San Carlos	PHL	118259	\N	f
850	San Juan del Monte	PHL	117680	\N	f
851	Tanauan	PHL	117539	\N	f
852	Concepcion	PHL	115171	\N	f
853	Rodriguez (Montalban)	PHL	115167	\N	f
854	Sariaya	PHL	114568	\N	f
855	Malasiqui	PHL	113190	\N	f
856	General Mariano Alvarez	PHL	112446	\N	f
857	Urdaneta	PHL	111582	\N	f
858	Hagonoy	PHL	111425	\N	f
859	San Jose	PHL	111009	\N	f
860	Polomolok	PHL	110709	\N	f
861	Santiago	PHL	110531	\N	f
862	Tanza	PHL	110517	\N	f
863	Ozamis	PHL	110420	\N	f
864	Mexico	PHL	109481	\N	f
865	San Jose	PHL	108254	\N	f
866	Silay	PHL	107722	\N	f
867	General Trias	PHL	107691	\N	f
868	Tabaco	PHL	107166	\N	f
869	Cabuyao	PHL	106630	\N	f
870	Calapan	PHL	105910	\N	f
871	Mati	PHL	105908	\N	f
872	Midsayap	PHL	105760	\N	f
873	Cauayan	PHL	103952	\N	f
874	Gingoog	PHL	102379	\N	f
875	Dumaguete	PHL	102265	\N	f
876	San Fernando	PHL	102082	\N	f
877	Arayat	PHL	101792	\N	f
878	Bayawan (Tulong)	PHL	101391	\N	f
879	Kidapawan	PHL	101205	\N	f
880	Daraga (Locsin)	PHL	101031	\N	f
881	Marilao	PHL	101017	\N	f
882	Malita	PHL	100000	\N	f
883	Dipolog	PHL	99862	\N	f
884	Cavite	PHL	99367	\N	f
885	Danao	PHL	98781	\N	f
886	Bislig	PHL	97860	\N	f
887	Talavera	PHL	97329	\N	f
888	Guagua	PHL	96858	\N	f
889	Bayambang	PHL	96609	\N	f
890	Nasugbu	PHL	96113	\N	f
891	Baybay	PHL	95630	\N	f
892	Capas	PHL	95219	\N	f
893	Sultan Kudarat	PHL	94861	\N	f
894	Laoag	PHL	94466	\N	f
895	Bayugan	PHL	93623	\N	f
896	Malungon	PHL	93232	\N	f
897	Santa Cruz	PHL	92694	\N	f
898	Sorsogon	PHL	92512	\N	f
899	Candelaria	PHL	92429	\N	f
900	Ligao	PHL	90603	\N	f
903	Serekunda	GMB	102600	\N	f
907	Rustavi	GEO	155400	\N	f
908	Batumi	GEO	137700	\N	f
909	Sohumi	GEO	111700	\N	f
911	Kumasi	GHA	385192	\N	f
912	Tamale	GHA	151069	\N	f
913	Tema	GHA	109975	\N	f
914	Sekondi-Takoradi	GHA	103653	\N	f
918	Les Abymes	GLP	62947	\N	f
920	Tamuning	GUM	9500	\N	f
923	Mixco	GTM	209791	\N	f
924	Villa Nueva	GTM	101295	\N	f
925	Quetzaltenango	GTM	90801	\N	f
930	Carrefour	HTI	290204	\N	f
931	Delmas	HTI	240429	\N	f
932	Le-Cap-Haïtien	HTI	102233	\N	f
934	San Pedro Sula	HND	383900	\N	f
935	La Ceiba	HND	89200	\N	f
936	Kowloon and New Kowloon	HKG	1987996	\N	f
937	Victoria	HKG	1312637	\N	f
938	Longyearbyen	SJM	1438	\N	f
940	Surabaya	IDN	2663820	\N	f
941	Bandung	IDN	2429000	\N	f
942	Medan	IDN	1843919	\N	f
943	Palembang	IDN	1222764	\N	f
944	Tangerang	IDN	1198300	\N	f
945	Semarang	IDN	1104405	\N	f
946	Ujung Pandang	IDN	1060257	\N	f
947	Malang	IDN	716862	\N	f
948	Bandar Lampung	IDN	680332	\N	f
949	Bekasi	IDN	644300	\N	f
950	Padang	IDN	534474	\N	f
951	Surakarta	IDN	518600	\N	f
952	Banjarmasin	IDN	482931	\N	f
953	Pekan Baru	IDN	438638	\N	f
954	Denpasar	IDN	435000	\N	f
955	Yogyakarta	IDN	418944	\N	f
956	Pontianak	IDN	409632	\N	f
957	Samarinda	IDN	399175	\N	f
958	Jambi	IDN	385201	\N	f
959	Depok	IDN	365200	\N	f
960	Cimahi	IDN	344600	\N	f
961	Balikpapan	IDN	338752	\N	f
962	Manado	IDN	332288	\N	f
963	Mataram	IDN	306600	\N	f
964	Pekalongan	IDN	301504	\N	f
965	Tegal	IDN	289744	\N	f
966	Bogor	IDN	285114	\N	f
967	Ciputat	IDN	270800	\N	f
968	Pondokgede	IDN	263200	\N	f
969	Cirebon	IDN	254406	\N	f
970	Kediri	IDN	253760	\N	f
971	Ambon	IDN	249312	\N	f
972	Jember	IDN	218500	\N	f
973	Cilacap	IDN	206900	\N	f
974	Cimanggis	IDN	205100	\N	f
975	Pematang Siantar	IDN	203056	\N	f
976	Purwokerto	IDN	202500	\N	f
977	Ciomas	IDN	187400	\N	f
978	Tasikmalaya	IDN	179800	\N	f
979	Madiun	IDN	171532	\N	f
980	Bengkulu	IDN	146439	\N	f
981	Karawang	IDN	145000	\N	f
982	Banda Aceh	IDN	143409	\N	f
983	Palu	IDN	142800	\N	f
984	Pasuruan	IDN	134019	\N	f
985	Kupang	IDN	129300	\N	f
986	Tebing Tinggi	IDN	129300	\N	f
904	Banjul	GMB	42326	\N	t
987	Percut Sei Tuan	IDN	129000	\N	f
988	Binjai	IDN	127222	\N	f
989	Sukabumi	IDN	125766	\N	f
990	Waru	IDN	124300	\N	f
991	Pangkal Pinang	IDN	124000	\N	f
992	Magelang	IDN	123800	\N	f
993	Blitar	IDN	122600	\N	f
994	Serang	IDN	122400	\N	f
995	Probolinggo	IDN	120770	\N	f
996	Cilegon	IDN	117000	\N	f
997	Cianjur	IDN	114300	\N	f
998	Ciparay	IDN	111500	\N	f
999	Lhokseumawe	IDN	109600	\N	f
1000	Taman	IDN	107000	\N	f
1001	Depok	IDN	106800	\N	f
1002	Citeureup	IDN	105100	\N	f
1003	Pemalang	IDN	103500	\N	f
1004	Klaten	IDN	103300	\N	f
1005	Salatiga	IDN	103000	\N	f
1006	Cibinong	IDN	101300	\N	f
1007	Palangka Raya	IDN	99693	\N	f
1008	Mojokerto	IDN	96626	\N	f
1009	Purwakarta	IDN	95900	\N	f
1010	Garut	IDN	95800	\N	f
1011	Kudus	IDN	95300	\N	f
1012	Kendari	IDN	94800	\N	f
1013	Jaya Pura	IDN	94700	\N	f
1014	Gorontalo	IDN	94058	\N	f
1015	Majalaya	IDN	93200	\N	f
1016	Pondok Aren	IDN	92700	\N	f
1017	Jombang	IDN	92600	\N	f
1018	Sunggal	IDN	92300	\N	f
1019	Batam	IDN	91871	\N	f
1020	Padang Sidempuan	IDN	91200	\N	f
1021	Sawangan	IDN	91100	\N	f
1022	Banyuwangi	IDN	89900	\N	f
1023	Tanjung Pinang	IDN	89900	\N	f
1024	Mumbai (Bombay)	IND	10500000	\N	f
1025	Delhi	IND	7206704	\N	f
1026	Calcutta [Kolkata]	IND	4399819	\N	f
1027	Chennai (Madras)	IND	3841396	\N	f
1028	Hyderabad	IND	2964638	\N	f
1029	Ahmedabad	IND	2876710	\N	f
1030	Bangalore	IND	2660088	\N	f
1031	Kanpur	IND	1874409	\N	f
1032	Nagpur	IND	1624752	\N	f
1033	Lucknow	IND	1619115	\N	f
1034	Pune	IND	1566651	\N	f
1035	Surat	IND	1498817	\N	f
1036	Jaipur	IND	1458483	\N	f
1037	Indore	IND	1091674	\N	f
1038	Bhopal	IND	1062771	\N	f
1039	Ludhiana	IND	1042740	\N	f
1040	Vadodara (Baroda)	IND	1031346	\N	f
1041	Kalyan	IND	1014557	\N	f
1042	Madurai	IND	977856	\N	f
1043	Haora (Howrah)	IND	950435	\N	f
1044	Varanasi (Benares)	IND	929270	\N	f
1045	Patna	IND	917243	\N	f
1046	Srinagar	IND	892506	\N	f
1047	Agra	IND	891790	\N	f
1048	Coimbatore	IND	816321	\N	f
1049	Thane (Thana)	IND	803389	\N	f
1050	Allahabad	IND	792858	\N	f
1051	Meerut	IND	753778	\N	f
1052	Vishakhapatnam	IND	752037	\N	f
1053	Jabalpur	IND	741927	\N	f
1054	Amritsar	IND	708835	\N	f
1055	Faridabad	IND	703592	\N	f
1056	Vijayawada	IND	701827	\N	f
1057	Gwalior	IND	690765	\N	f
1058	Jodhpur	IND	666279	\N	f
1059	Nashik (Nasik)	IND	656925	\N	f
1060	Hubli-Dharwad	IND	648298	\N	f
1061	Solapur (Sholapur)	IND	604215	\N	f
1062	Ranchi	IND	599306	\N	f
1063	Bareilly	IND	587211	\N	f
1064	Guwahati (Gauhati)	IND	584342	\N	f
1065	Shambajinagar (Aurangabad)	IND	573272	\N	f
1066	Cochin (Kochi)	IND	564589	\N	f
1067	Rajkot	IND	559407	\N	f
1068	Kota	IND	537371	\N	f
1069	Thiruvananthapuram (Trivandrum	IND	524006	\N	f
1070	Pimpri-Chinchwad	IND	517083	\N	f
1071	Jalandhar (Jullundur)	IND	509510	\N	f
1072	Gorakhpur	IND	505566	\N	f
1073	Chandigarh	IND	504094	\N	f
1074	Mysore	IND	480692	\N	f
1075	Aligarh	IND	480520	\N	f
1076	Guntur	IND	471051	\N	f
1077	Jamshedpur	IND	460577	\N	f
1078	Ghaziabad	IND	454156	\N	f
1079	Warangal	IND	447657	\N	f
1080	Raipur	IND	438639	\N	f
1081	Moradabad	IND	429214	\N	f
1082	Durgapur	IND	425836	\N	f
1083	Amravati	IND	421576	\N	f
1084	Calicut (Kozhikode)	IND	419831	\N	f
1085	Bikaner	IND	416289	\N	f
1086	Bhubaneswar	IND	411542	\N	f
1087	Kolhapur	IND	406370	\N	f
1088	Kataka (Cuttack)	IND	403418	\N	f
1089	Ajmer	IND	402700	\N	f
1090	Bhavnagar	IND	402338	\N	f
1091	Tiruchirapalli	IND	387223	\N	f
1092	Bhilai	IND	386159	\N	f
1093	Bhiwandi	IND	379070	\N	f
1094	Saharanpur	IND	374945	\N	f
1095	Ulhasnagar	IND	369077	\N	f
1096	Salem	IND	366712	\N	f
1097	Ujjain	IND	362266	\N	f
1098	Malegaon	IND	342595	\N	f
1099	Jamnagar	IND	341637	\N	f
1100	Bokaro Steel City	IND	333683	\N	f
1101	Akola	IND	328034	\N	f
1102	Belgaum	IND	326399	\N	f
1103	Rajahmundry	IND	324851	\N	f
1104	Nellore	IND	316606	\N	f
1105	Udaipur	IND	308571	\N	f
1106	New Bombay	IND	307297	\N	f
1107	Bhatpara	IND	304952	\N	f
1108	Gulbarga	IND	304099	\N	f
1110	Jhansi	IND	300850	\N	f
1111	Gaya	IND	291675	\N	f
1112	Kakinada	IND	279980	\N	f
1113	Dhule (Dhulia)	IND	278317	\N	f
1114	Panihati	IND	275990	\N	f
1115	Nanded (Nander)	IND	275083	\N	f
1116	Mangalore	IND	273304	\N	f
1117	Dehra Dun	IND	270159	\N	f
1118	Kamarhati	IND	266889	\N	f
1119	Davangere	IND	266082	\N	f
1120	Asansol	IND	262188	\N	f
1121	Bhagalpur	IND	253225	\N	f
1122	Bellary	IND	245391	\N	f
1123	Barddhaman (Burdwan)	IND	245079	\N	f
1124	Rampur	IND	243742	\N	f
1125	Jalgaon	IND	242193	\N	f
1126	Muzaffarpur	IND	241107	\N	f
1127	Nizamabad	IND	241034	\N	f
1128	Muzaffarnagar	IND	240609	\N	f
1129	Patiala	IND	238368	\N	f
1130	Shahjahanpur	IND	237713	\N	f
1131	Kurnool	IND	236800	\N	f
1132	Tiruppur (Tirupper)	IND	235661	\N	f
1133	Rohtak	IND	233400	\N	f
1134	South Dum Dum	IND	232811	\N	f
1135	Mathura	IND	226691	\N	f
1136	Chandrapur	IND	226105	\N	f
1137	Barahanagar (Baranagar)	IND	224821	\N	f
1138	Darbhanga	IND	218391	\N	f
1139	Siliguri (Shiliguri)	IND	216950	\N	f
1140	Raurkela	IND	215489	\N	f
1141	Ambattur	IND	215424	\N	f
1142	Panipat	IND	215218	\N	f
1143	Firozabad	IND	215128	\N	f
1144	Ichalkaranji	IND	214950	\N	f
1145	Jammu	IND	214737	\N	f
1146	Ramagundam	IND	214384	\N	f
1147	Eluru	IND	212866	\N	f
1148	Brahmapur	IND	210418	\N	f
1149	Alwar	IND	205086	\N	f
1150	Pondicherry	IND	203065	\N	f
1151	Thanjavur	IND	202013	\N	f
1152	Bihar Sharif	IND	201323	\N	f
1153	Tuticorin	IND	199854	\N	f
1154	Imphal	IND	198535	\N	f
1155	Latur	IND	197408	\N	f
1156	Sagar	IND	195346	\N	f
1157	Farrukhabad-cum-Fatehgarh	IND	194567	\N	f
1158	Sangli	IND	193197	\N	f
1159	Parbhani	IND	190255	\N	f
1160	Nagar Coil	IND	190084	\N	f
1161	Bijapur	IND	186939	\N	f
1162	Kukatpalle	IND	185378	\N	f
1163	Bally	IND	184474	\N	f
1164	Bhilwara	IND	183965	\N	f
1165	Ratlam	IND	183375	\N	f
1166	Avadi	IND	183215	\N	f
1167	Dindigul	IND	182477	\N	f
1168	Ahmadnagar	IND	181339	\N	f
1169	Bilaspur	IND	179833	\N	f
1170	Shimoga	IND	179258	\N	f
1171	Kharagpur	IND	177989	\N	f
1172	Mira Bhayandar	IND	175372	\N	f
1173	Vellore	IND	175061	\N	f
1174	Jalna	IND	174985	\N	f
1175	Burnpur	IND	174933	\N	f
1176	Anantapur	IND	174924	\N	f
1177	Allappuzha (Alleppey)	IND	174666	\N	f
1178	Tirupati	IND	174369	\N	f
1179	Karnal	IND	173751	\N	f
1180	Burhanpur	IND	172710	\N	f
1181	Hisar (Hissar)	IND	172677	\N	f
1182	Tiruvottiyur	IND	172562	\N	f
1183	Mirzapur-cum-Vindhyachal	IND	169336	\N	f
1184	Secunderabad	IND	167461	\N	f
1185	Nadiad	IND	167051	\N	f
1186	Dewas	IND	164364	\N	f
1187	Murwara (Katni)	IND	163431	\N	f
1188	Ganganagar	IND	161482	\N	f
1189	Vizianagaram	IND	160359	\N	f
1190	Erode	IND	159232	\N	f
1191	Machilipatnam (Masulipatam)	IND	159110	\N	f
1192	Bhatinda (Bathinda)	IND	159042	\N	f
1193	Raichur	IND	157551	\N	f
1194	Agartala	IND	157358	\N	f
1195	Arrah (Ara)	IND	157082	\N	f
1196	Satna	IND	156630	\N	f
1197	Lalbahadur Nagar	IND	155500	\N	f
1198	Aizawl	IND	155240	\N	f
1199	Uluberia	IND	155172	\N	f
1200	Katihar	IND	154367	\N	f
1201	Cuddalore	IND	153086	\N	f
1202	Hugli-Chinsurah	IND	151806	\N	f
1203	Dhanbad	IND	151789	\N	f
1204	Raiganj	IND	151045	\N	f
1205	Sambhal	IND	150869	\N	f
1206	Durg	IND	150645	\N	f
1207	Munger (Monghyr)	IND	150112	\N	f
1208	Kanchipuram	IND	150100	\N	f
1209	North Dum Dum	IND	149965	\N	f
1210	Karimnagar	IND	148583	\N	f
1211	Bharatpur	IND	148519	\N	f
1212	Sikar	IND	148272	\N	f
1213	Hardwar (Haridwar)	IND	147305	\N	f
1214	Dabgram	IND	147217	\N	f
1215	Morena	IND	147124	\N	f
1216	Noida	IND	146514	\N	f
1217	Hapur	IND	146262	\N	f
1218	Bhusawal	IND	145143	\N	f
1219	Khandwa	IND	145133	\N	f
1220	Yamuna Nagar	IND	144346	\N	f
1221	Sonipat (Sonepat)	IND	143922	\N	f
1222	Tenali	IND	143726	\N	f
1223	Raurkela Civil Township	IND	140408	\N	f
1224	Kollam (Quilon)	IND	139852	\N	f
1225	Kumbakonam	IND	139483	\N	f
1226	Ingraj Bazar (English Bazar)	IND	139204	\N	f
1227	Timkur	IND	138903	\N	f
1228	Amroha	IND	137061	\N	f
1229	Serampore	IND	137028	\N	f
1230	Chapra	IND	136877	\N	f
1231	Pali	IND	136842	\N	f
1232	Maunath Bhanjan	IND	136697	\N	f
1233	Adoni	IND	136182	\N	f
1234	Jaunpur	IND	136062	\N	f
1235	Tirunelveli	IND	135825	\N	f
1236	Bahraich	IND	135400	\N	f
1237	Gadag Betigeri	IND	134051	\N	f
1238	Proddatur	IND	133914	\N	f
1239	Chittoor	IND	133462	\N	f
1240	Barrackpur	IND	133265	\N	f
1241	Bharuch (Broach)	IND	133102	\N	f
1242	Naihati	IND	132701	\N	f
1243	Shillong	IND	131719	\N	f
1244	Sambalpur	IND	131138	\N	f
1245	Junagadh	IND	130484	\N	f
1246	Rae Bareli	IND	129904	\N	f
1247	Rewa	IND	128981	\N	f
1248	Gurgaon	IND	128608	\N	f
1249	Khammam	IND	127992	\N	f
1250	Bulandshahr	IND	127201	\N	f
1251	Navsari	IND	126089	\N	f
1252	Malkajgiri	IND	126066	\N	f
1253	Midnapore (Medinipur)	IND	125498	\N	f
1254	Miraj	IND	125407	\N	f
1255	Raj Nandgaon	IND	125371	\N	f
1256	Alandur	IND	125244	\N	f
1257	Puri	IND	125199	\N	f
1258	Navadwip	IND	125037	\N	f
1259	Sirsa	IND	125000	\N	f
1260	Korba	IND	124501	\N	f
1261	Faizabad	IND	124437	\N	f
1262	Etawah	IND	124072	\N	f
1263	Pathankot	IND	123930	\N	f
1264	Gandhinagar	IND	123359	\N	f
1265	Palghat (Palakkad)	IND	123289	\N	f
1266	Veraval	IND	123000	\N	f
1267	Hoshiarpur	IND	122705	\N	f
1268	Ambala	IND	122596	\N	f
1269	Sitapur	IND	121842	\N	f
1270	Bhiwani	IND	121629	\N	f
1271	Cuddapah	IND	121463	\N	f
1272	Bhimavaram	IND	121314	\N	f
1273	Krishnanagar	IND	121110	\N	f
1274	Chandannagar	IND	120378	\N	f
1275	Mandya	IND	120265	\N	f
1276	Dibrugarh	IND	120127	\N	f
1277	Nandyal	IND	119813	\N	f
1278	Balurghat	IND	119796	\N	f
1279	Neyveli	IND	118080	\N	f
1280	Fatehpur	IND	117675	\N	f
1281	Mahbubnagar	IND	116833	\N	f
1282	Budaun	IND	116695	\N	f
1283	Porbandar	IND	116671	\N	f
1284	Silchar	IND	115483	\N	f
1285	Berhampore (Baharampur)	IND	115144	\N	f
1286	Purnea (Purnia)	IND	114912	\N	f
1287	Bankura	IND	114876	\N	f
1288	Rajapalaiyam	IND	114202	\N	f
1289	Titagarh	IND	114085	\N	f
1290	Halisahar	IND	114028	\N	f
1291	Hathras	IND	113285	\N	f
1292	Bhir (Bid)	IND	112434	\N	f
1293	Pallavaram	IND	111866	\N	f
1294	Anand	IND	110266	\N	f
1295	Mango	IND	110024	\N	f
1296	Santipur	IND	109956	\N	f
1297	Bhind	IND	109755	\N	f
1298	Gondiya	IND	109470	\N	f
1299	Tiruvannamalai	IND	109196	\N	f
1300	Yeotmal (Yavatmal)	IND	108578	\N	f
1301	Kulti-Barakar	IND	108518	\N	f
1302	Moga	IND	108304	\N	f
1303	Shivapuri	IND	108277	\N	f
1304	Bidar	IND	108016	\N	f
1305	Guntakal	IND	107592	\N	f
1306	Unnao	IND	107425	\N	f
1307	Barasat	IND	107365	\N	f
1308	Tambaram	IND	107187	\N	f
1309	Abohar	IND	107163	\N	f
1310	Pilibhit	IND	106605	\N	f
1311	Valparai	IND	106523	\N	f
1312	Gonda	IND	106078	\N	f
1313	Surendranagar	IND	105973	\N	f
1314	Qutubullapur	IND	105380	\N	f
1315	Beawar	IND	105363	\N	f
1316	Hindupur	IND	104651	\N	f
1317	Gandhidham	IND	104585	\N	f
1318	Haldwani-cum-Kathgodam	IND	104195	\N	f
1319	Tellicherry (Thalassery)	IND	103579	\N	f
1320	Wardha	IND	102985	\N	f
1321	Rishra	IND	102649	\N	f
1322	Bhuj	IND	102176	\N	f
1323	Modinagar	IND	101660	\N	f
1324	Gudivada	IND	101656	\N	f
1325	Basirhat	IND	101409	\N	f
1326	Uttarpara-Kotrung	IND	100867	\N	f
1327	Ongole	IND	100836	\N	f
1328	North Barrackpur	IND	100513	\N	f
1329	Guna	IND	100490	\N	f
1330	Haldia	IND	100347	\N	f
1331	Habra	IND	100223	\N	f
1332	Kanchrapara	IND	100194	\N	f
1333	Tonk	IND	100079	\N	f
1334	Champdani	IND	98818	\N	f
1335	Orai	IND	98640	\N	f
1336	Pudukkottai	IND	98619	\N	f
1337	Sasaram	IND	98220	\N	f
1338	Hazaribag	IND	97712	\N	f
1339	Palayankottai	IND	97662	\N	f
1340	Banda	IND	97227	\N	f
1341	Godhra	IND	96813	\N	f
1342	Hospet	IND	96322	\N	f
1343	Ashoknagar-Kalyangarh	IND	96315	\N	f
1344	Achalpur	IND	96216	\N	f
1345	Patan	IND	96109	\N	f
1346	Mandasor	IND	95758	\N	f
1347	Damoh	IND	95661	\N	f
1348	Satara	IND	95133	\N	f
1349	Meerut Cantonment	IND	94876	\N	f
1350	Dehri	IND	94526	\N	f
1351	Delhi Cantonment	IND	94326	\N	f
1352	Chhindwara	IND	93731	\N	f
1353	Bansberia	IND	93447	\N	f
1354	Nagaon	IND	93350	\N	f
1355	Kanpur Cantonment	IND	93109	\N	f
1356	Vidisha	IND	92917	\N	f
1357	Bettiah	IND	92583	\N	f
1358	Purulia	IND	92574	\N	f
1359	Hassan	IND	90803	\N	f
1360	Ambala Sadar	IND	90712	\N	f
1361	Baidyabati	IND	90601	\N	f
1362	Morvi	IND	90357	\N	f
1363	Raigarh	IND	89166	\N	f
1364	Vejalpur	IND	89053	\N	f
1366	Mosul	IRQ	879000	\N	f
1367	Irbil	IRQ	485968	\N	f
1368	Kirkuk	IRQ	418624	\N	f
1369	Basra	IRQ	406296	\N	f
1370	al-Sulaymaniya	IRQ	364096	\N	f
1371	al-Najaf	IRQ	309010	\N	f
1372	Karbala	IRQ	296705	\N	f
1373	al-Hilla	IRQ	268834	\N	f
1374	al-Nasiriya	IRQ	265937	\N	f
1375	al-Amara	IRQ	208797	\N	f
1376	al-Diwaniya	IRQ	196519	\N	f
1377	al-Ramadi	IRQ	192556	\N	f
1378	al-Kut	IRQ	183183	\N	f
1379	Baquba	IRQ	114516	\N	f
1381	Mashhad	IRN	1887405	\N	f
1382	Esfahan	IRN	1266072	\N	f
1383	Tabriz	IRN	1191043	\N	f
1384	Shiraz	IRN	1053025	\N	f
1385	Karaj	IRN	940968	\N	f
1386	Ahvaz	IRN	804980	\N	f
1387	Qom	IRN	777677	\N	f
1388	Kermanshah	IRN	692986	\N	f
1389	Urmia	IRN	435200	\N	f
1390	Zahedan	IRN	419518	\N	f
1391	Rasht	IRN	417748	\N	f
1392	Hamadan	IRN	401281	\N	f
1393	Kerman	IRN	384991	\N	f
1394	Arak	IRN	380755	\N	f
1395	Ardebil	IRN	340386	\N	f
1396	Yazd	IRN	326776	\N	f
1397	Qazvin	IRN	291117	\N	f
1398	Zanjan	IRN	286295	\N	f
1399	Sanandaj	IRN	277808	\N	f
1400	Bandar-e-Abbas	IRN	273578	\N	f
1401	Khorramabad	IRN	272815	\N	f
1402	Eslamshahr	IRN	265450	\N	f
1403	Borujerd	IRN	217804	\N	f
1404	Abadan	IRN	206073	\N	f
1405	Dezful	IRN	202639	\N	f
1406	Kashan	IRN	201372	\N	f
1407	Sari	IRN	195882	\N	f
1408	Gorgan	IRN	188710	\N	f
1409	Najafabad	IRN	178498	\N	f
1410	Sabzevar	IRN	170738	\N	f
1411	Khomeynishahr	IRN	165888	\N	f
1412	Amol	IRN	159092	\N	f
1413	Neyshabur	IRN	158847	\N	f
1414	Babol	IRN	158346	\N	f
1415	Khoy	IRN	148944	\N	f
1416	Malayer	IRN	144373	\N	f
1417	Bushehr	IRN	143641	\N	f
1418	Qaemshahr	IRN	143286	\N	f
1419	Qarchak	IRN	142690	\N	f
1420	Qods	IRN	138278	\N	f
1421	Sirjan	IRN	135024	\N	f
1422	Bojnurd	IRN	134835	\N	f
1423	Maragheh	IRN	132318	\N	f
1424	Birjand	IRN	127608	\N	f
1425	Ilam	IRN	126346	\N	f
1426	Bukan	IRN	120020	\N	f
1427	Masjed-e-Soleyman	IRN	116883	\N	f
1428	Saqqez	IRN	115394	\N	f
1429	Gonbad-e Qabus	IRN	111253	\N	f
1430	Saveh	IRN	111245	\N	f
1431	Mahabad	IRN	107799	\N	f
1432	Varamin	IRN	107233	\N	f
1433	Andimeshk	IRN	106923	\N	f
1434	Khorramshahr	IRN	105636	\N	f
1435	Shahrud	IRN	104765	\N	f
1436	Marv Dasht	IRN	103579	\N	f
1437	Zabol	IRN	100887	\N	f
1438	Shahr-e Kord	IRN	100477	\N	f
1439	Bandar-e Anzali	IRN	98500	\N	f
1440	Rafsanjan	IRN	98300	\N	f
1441	Marand	IRN	96400	\N	f
1442	Torbat-e Heydariyeh	IRN	94600	\N	f
1443	Jahrom	IRN	94200	\N	f
1444	Semnan	IRN	91045	\N	f
1445	Miandoab	IRN	90100	\N	f
1446	Qomsheh	IRN	89800	\N	f
1448	Cork	IRL	127187	\N	f
1451	Tel Aviv-Jaffa	ISR	348100	\N	f
1452	Haifa	ISR	265700	\N	f
1453	Rishon Le Ziyyon	ISR	188200	\N	f
1454	Beerseba	ISR	163700	\N	f
1455	Holon	ISR	163100	\N	f
1456	Petah Tiqwa	ISR	159400	\N	f
1457	Ashdod	ISR	155800	\N	f
1458	Netanya	ISR	154900	\N	f
1459	Bat Yam	ISR	137000	\N	f
1460	Bene Beraq	ISR	133900	\N	f
1461	Ramat Gan	ISR	126900	\N	f
1462	Ashqelon	ISR	92300	\N	f
1463	Rehovot	ISR	90300	\N	f
1465	Milano	ITA	1300977	\N	f
1466	Napoli	ITA	1002619	\N	f
1467	Torino	ITA	903705	\N	f
1468	Palermo	ITA	683794	\N	f
1469	Genova	ITA	636104	\N	f
1470	Bologna	ITA	381161	\N	f
1471	Firenze	ITA	376662	\N	f
1472	Catania	ITA	337862	\N	f
1473	Bari	ITA	331848	\N	f
1474	Venezia	ITA	277305	\N	f
1475	Messina	ITA	259156	\N	f
1476	Verona	ITA	255268	\N	f
1477	Trieste	ITA	216459	\N	f
1478	Padova	ITA	211391	\N	f
1479	Taranto	ITA	208214	\N	f
1480	Brescia	ITA	191317	\N	f
1481	Reggio di Calabria	ITA	179617	\N	f
1482	Modena	ITA	176022	\N	f
1483	Prato	ITA	172473	\N	f
1484	Parma	ITA	168717	\N	f
1485	Cagliari	ITA	165926	\N	f
1486	Livorno	ITA	161673	\N	f
1487	Perugia	ITA	156673	\N	f
1488	Foggia	ITA	154891	\N	f
1489	Reggio nell´ Emilia	ITA	143664	\N	f
1490	Salerno	ITA	142055	\N	f
1491	Ravenna	ITA	138418	\N	f
1492	Ferrara	ITA	132127	\N	f
1493	Rimini	ITA	131062	\N	f
1494	Syrakusa	ITA	126282	\N	f
1495	Sassari	ITA	120803	\N	f
1496	Monza	ITA	119516	\N	f
1497	Bergamo	ITA	117837	\N	f
1498	Pescara	ITA	115698	\N	f
1499	Latina	ITA	114099	\N	f
1500	Vicenza	ITA	109738	\N	f
1501	Terni	ITA	107770	\N	f
1502	Forlì	ITA	107475	\N	f
1503	Trento	ITA	104906	\N	f
1504	Novara	ITA	102037	\N	f
1505	Piacenza	ITA	98384	\N	f
1506	Ancona	ITA	98329	\N	f
1507	Lecce	ITA	98208	\N	f
1508	Bolzano	ITA	97232	\N	f
1509	Catanzaro	ITA	96700	\N	f
1510	La Spezia	ITA	95504	\N	f
1511	Udine	ITA	94932	\N	f
1512	Torre del Greco	ITA	94505	\N	f
1513	Andria	ITA	94443	\N	f
1514	Brindisi	ITA	93454	\N	f
1515	Giugliano in Campania	ITA	93286	\N	f
1516	Pisa	ITA	92379	\N	f
1517	Barletta	ITA	91904	\N	f
1518	Arezzo	ITA	91729	\N	f
1519	Alessandria	ITA	90289	\N	f
1520	Cesena	ITA	89852	\N	f
1521	Pesaro	ITA	88987	\N	f
1524	Graz	AUT	240967	\N	f
1525	Linz	AUT	188022	\N	f
1526	Salzburg	AUT	144247	\N	f
1527	Innsbruck	AUT	111752	\N	f
1528	Klagenfurt	AUT	91141	\N	f
1529	Spanish Town	JAM	110379	\N	f
1531	Portmore	JAM	99799	\N	f
1533	Jokohama [Yokohama]	JPN	3339594	\N	f
1534	Osaka	JPN	2595674	\N	f
1535	Nagoya	JPN	2154376	\N	f
1536	Sapporo	JPN	1790886	\N	f
1537	Kioto	JPN	1461974	\N	f
1538	Kobe	JPN	1425139	\N	f
1539	Fukuoka	JPN	1308379	\N	f
1540	Kawasaki	JPN	1217359	\N	f
1541	Hiroshima	JPN	1119117	\N	f
1542	Kitakyushu	JPN	1016264	\N	f
1543	Sendai	JPN	989975	\N	f
1544	Chiba	JPN	863930	\N	f
1545	Sakai	JPN	797735	\N	f
1546	Kumamoto	JPN	656734	\N	f
1547	Okayama	JPN	624269	\N	f
1548	Sagamihara	JPN	586300	\N	f
1549	Hamamatsu	JPN	568796	\N	f
1550	Kagoshima	JPN	549977	\N	f
1551	Funabashi	JPN	545299	\N	f
1552	Higashiosaka	JPN	517785	\N	f
1553	Hachioji	JPN	513451	\N	f
1554	Niigata	JPN	497464	\N	f
1555	Amagasaki	JPN	481434	\N	f
1556	Himeji	JPN	475167	\N	f
1557	Shizuoka	JPN	473854	\N	f
1558	Urawa	JPN	469675	\N	f
1559	Matsuyama	JPN	466133	\N	f
1560	Matsudo	JPN	461126	\N	f
1561	Kanazawa	JPN	455386	\N	f
1562	Kawaguchi	JPN	452155	\N	f
1563	Ichikawa	JPN	441893	\N	f
1564	Omiya	JPN	441649	\N	f
1565	Utsunomiya	JPN	440353	\N	f
1566	Oita	JPN	433401	\N	f
1567	Nagasaki	JPN	432759	\N	f
1568	Yokosuka	JPN	430200	\N	f
1569	Kurashiki	JPN	425103	\N	f
1570	Gifu	JPN	408007	\N	f
1571	Hirakata	JPN	403151	\N	f
1572	Nishinomiya	JPN	397618	\N	f
1573	Toyonaka	JPN	396689	\N	f
1574	Wakayama	JPN	391233	\N	f
1575	Fukuyama	JPN	376921	\N	f
1576	Fujisawa	JPN	372840	\N	f
1577	Asahikawa	JPN	364813	\N	f
1578	Machida	JPN	364197	\N	f
1579	Nara	JPN	362812	\N	f
1580	Takatsuki	JPN	361747	\N	f
1581	Iwaki	JPN	361737	\N	f
1582	Nagano	JPN	361391	\N	f
1583	Toyohashi	JPN	360066	\N	f
1584	Toyota	JPN	346090	\N	f
1585	Suita	JPN	345750	\N	f
1586	Takamatsu	JPN	332471	\N	f
1587	Koriyama	JPN	330335	\N	f
1588	Okazaki	JPN	328711	\N	f
1589	Kawagoe	JPN	327211	\N	f
1590	Tokorozawa	JPN	325809	\N	f
1591	Toyama	JPN	325790	\N	f
1592	Kochi	JPN	324710	\N	f
1593	Kashiwa	JPN	320296	\N	f
1594	Akita	JPN	314440	\N	f
1595	Miyazaki	JPN	303784	\N	f
1596	Koshigaya	JPN	301446	\N	f
1597	Naha	JPN	299851	\N	f
1598	Aomori	JPN	295969	\N	f
1599	Hakodate	JPN	294788	\N	f
1600	Akashi	JPN	292253	\N	f
1601	Yokkaichi	JPN	288173	\N	f
1602	Fukushima	JPN	287525	\N	f
1603	Morioka	JPN	287353	\N	f
1604	Maebashi	JPN	284473	\N	f
1605	Kasugai	JPN	282348	\N	f
1606	Otsu	JPN	282070	\N	f
1607	Ichihara	JPN	279280	\N	f
1608	Yao	JPN	276421	\N	f
1609	Ichinomiya	JPN	270828	\N	f
1610	Tokushima	JPN	269649	\N	f
1611	Kakogawa	JPN	266281	\N	f
1612	Ibaraki	JPN	261020	\N	f
1613	Neyagawa	JPN	257315	\N	f
1614	Shimonoseki	JPN	257263	\N	f
1615	Yamagata	JPN	255617	\N	f
1616	Fukui	JPN	254818	\N	f
1617	Hiratsuka	JPN	254207	\N	f
1618	Mito	JPN	246559	\N	f
1619	Sasebo	JPN	244240	\N	f
1620	Hachinohe	JPN	242979	\N	f
1621	Takasaki	JPN	239124	\N	f
1622	Shimizu	JPN	239123	\N	f
1623	Kurume	JPN	235611	\N	f
1624	Fuji	JPN	231527	\N	f
1625	Soka	JPN	222768	\N	f
1626	Fuchu	JPN	220576	\N	f
1627	Chigasaki	JPN	216015	\N	f
1628	Atsugi	JPN	212407	\N	f
1629	Numazu	JPN	211382	\N	f
1630	Ageo	JPN	209442	\N	f
1631	Yamato	JPN	208234	\N	f
1632	Matsumoto	JPN	206801	\N	f
1633	Kure	JPN	206504	\N	f
1634	Takarazuka	JPN	205993	\N	f
1635	Kasukabe	JPN	201838	\N	f
1636	Chofu	JPN	201585	\N	f
1637	Odawara	JPN	200171	\N	f
1638	Kofu	JPN	199753	\N	f
1639	Kushiro	JPN	197608	\N	f
1640	Kishiwada	JPN	197276	\N	f
1641	Hitachi	JPN	196622	\N	f
1642	Nagaoka	JPN	192407	\N	f
1643	Itami	JPN	190886	\N	f
1644	Uji	JPN	188735	\N	f
1645	Suzuka	JPN	184061	\N	f
1646	Hirosaki	JPN	177522	\N	f
1647	Ube	JPN	175206	\N	f
1648	Kodaira	JPN	174984	\N	f
1649	Takaoka	JPN	174380	\N	f
1650	Obihiro	JPN	173685	\N	f
1651	Tomakomai	JPN	171958	\N	f
1652	Saga	JPN	170034	\N	f
1653	Sakura	JPN	168072	\N	f
1654	Kamakura	JPN	167661	\N	f
1655	Mitaka	JPN	167268	\N	f
1656	Izumi	JPN	166979	\N	f
1657	Hino	JPN	166770	\N	f
1658	Hadano	JPN	166512	\N	f
1659	Ashikaga	JPN	165243	\N	f
1660	Tsu	JPN	164543	\N	f
1661	Sayama	JPN	162472	\N	f
1662	Yachiyo	JPN	161222	\N	f
1663	Tsukuba	JPN	160768	\N	f
1664	Tachikawa	JPN	159430	\N	f
1665	Kumagaya	JPN	157171	\N	f
1666	Moriguchi	JPN	155941	\N	f
1667	Otaru	JPN	155784	\N	f
1668	Anjo	JPN	153823	\N	f
1669	Narashino	JPN	152849	\N	f
1670	Oyama	JPN	152820	\N	f
1671	Ogaki	JPN	151758	\N	f
1672	Matsue	JPN	149821	\N	f
1673	Kawanishi	JPN	149794	\N	f
1674	Hitachinaka	JPN	148006	\N	f
1675	Niiza	JPN	147744	\N	f
1676	Nagareyama	JPN	147738	\N	f
1677	Tottori	JPN	147523	\N	f
1678	Tama	JPN	146712	\N	f
1679	Iruma	JPN	145922	\N	f
1680	Ota	JPN	145317	\N	f
1681	Omuta	JPN	142889	\N	f
1682	Komaki	JPN	139827	\N	f
1683	Ome	JPN	139216	\N	f
1684	Kadoma	JPN	138953	\N	f
1685	Yamaguchi	JPN	138210	\N	f
1686	Higashimurayama	JPN	136970	\N	f
1687	Yonago	JPN	136461	\N	f
1688	Matsubara	JPN	135010	\N	f
1689	Musashino	JPN	134426	\N	f
1690	Tsuchiura	JPN	134072	\N	f
1691	Joetsu	JPN	133505	\N	f
1692	Miyakonojo	JPN	133183	\N	f
1693	Misato	JPN	132957	\N	f
1694	Kakamigahara	JPN	131831	\N	f
1695	Daito	JPN	130594	\N	f
1696	Seto	JPN	130470	\N	f
1697	Kariya	JPN	127969	\N	f
1698	Urayasu	JPN	127550	\N	f
1699	Beppu	JPN	127486	\N	f
1700	Niihama	JPN	127207	\N	f
1701	Minoo	JPN	127026	\N	f
1702	Fujieda	JPN	126897	\N	f
1703	Abiko	JPN	126670	\N	f
1704	Nobeoka	JPN	125547	\N	f
1705	Tondabayashi	JPN	125094	\N	f
1706	Ueda	JPN	124217	\N	f
1707	Kashihara	JPN	124013	\N	f
1708	Matsusaka	JPN	123582	\N	f
1709	Isesaki	JPN	123285	\N	f
1710	Zama	JPN	122046	\N	f
1711	Kisarazu	JPN	121967	\N	f
1712	Noda	JPN	121030	\N	f
1713	Ishinomaki	JPN	120963	\N	f
1714	Fujinomiya	JPN	119714	\N	f
1715	Kawachinagano	JPN	119666	\N	f
1716	Imabari	JPN	119357	\N	f
1717	Aizuwakamatsu	JPN	119287	\N	f
1718	Higashihiroshima	JPN	119166	\N	f
1719	Habikino	JPN	118968	\N	f
1720	Ebetsu	JPN	118805	\N	f
1721	Hofu	JPN	118751	\N	f
1722	Kiryu	JPN	118326	\N	f
1723	Okinawa	JPN	117748	\N	f
1724	Yaizu	JPN	117258	\N	f
1725	Toyokawa	JPN	115781	\N	f
1726	Ebina	JPN	115571	\N	f
1727	Asaka	JPN	114815	\N	f
1728	Higashikurume	JPN	111666	\N	f
1729	Ikoma	JPN	111645	\N	f
1730	Kitami	JPN	111295	\N	f
1731	Koganei	JPN	110969	\N	f
1732	Iwatsuki	JPN	110034	\N	f
1733	Mishima	JPN	109699	\N	f
1734	Handa	JPN	108600	\N	f
1735	Muroran	JPN	108275	\N	f
1736	Komatsu	JPN	107937	\N	f
1737	Yatsushiro	JPN	107661	\N	f
1738	Iida	JPN	107583	\N	f
1739	Tokuyama	JPN	107078	\N	f
1740	Kokubunji	JPN	106996	\N	f
1741	Akishima	JPN	106914	\N	f
1742	Iwakuni	JPN	106647	\N	f
1743	Kusatsu	JPN	106232	\N	f
1744	Kuwana	JPN	106121	\N	f
1745	Sanda	JPN	105643	\N	f
1746	Hikone	JPN	105508	\N	f
1747	Toda	JPN	103969	\N	f
1748	Tajimi	JPN	103171	\N	f
1749	Ikeda	JPN	102710	\N	f
1750	Fukaya	JPN	102156	\N	f
1751	Ise	JPN	101732	\N	f
1752	Sakata	JPN	101651	\N	f
1753	Kasuga	JPN	101344	\N	f
1754	Kamagaya	JPN	100821	\N	f
1755	Tsuruoka	JPN	100713	\N	f
1756	Hoya	JPN	100313	\N	f
1757	Nishio	JPN	100032	\N	f
1758	Tokai	JPN	99738	\N	f
1759	Inazawa	JPN	98746	\N	f
1760	Sakado	JPN	98221	\N	f
1761	Isehara	JPN	98123	\N	f
1762	Takasago	JPN	97632	\N	f
1763	Fujimi	JPN	96972	\N	f
1764	Urasoe	JPN	96002	\N	f
1765	Yonezawa	JPN	95592	\N	f
1766	Konan	JPN	95521	\N	f
1767	Yamatokoriyama	JPN	95165	\N	f
1768	Maizuru	JPN	94784	\N	f
1769	Onomichi	JPN	93756	\N	f
1770	Higashimatsuyama	JPN	93342	\N	f
1771	Kimitsu	JPN	93216	\N	f
1772	Isahaya	JPN	93058	\N	f
1773	Kanuma	JPN	93053	\N	f
1774	Izumisano	JPN	92583	\N	f
1775	Kameoka	JPN	92398	\N	f
1776	Mobara	JPN	91664	\N	f
1777	Narita	JPN	91470	\N	f
1778	Kashiwazaki	JPN	91229	\N	f
1779	Tsuyama	JPN	91170	\N	f
1782	Taizz	YEM	317600	\N	f
1783	Hodeida	YEM	298500	\N	f
1784	al-Mukalla	YEM	122400	\N	f
1785	Ibb	YEM	103300	\N	f
1787	al-Zarqa	JOR	389815	\N	f
1788	Irbid	JOR	231511	\N	f
1789	al-Rusayfa	JOR	137247	\N	f
1790	Wadi al-Sir	JOR	89104	\N	f
1801	Battambang	KHM	129800	\N	f
1802	Siem Reap	KHM	105100	\N	f
1803	Douala	CMR	1448300	\N	f
1805	Garoua	CMR	177000	\N	f
1806	Maroua	CMR	143000	\N	f
1807	Bamenda	CMR	138000	\N	f
1808	Bafoussam	CMR	131000	\N	f
1809	Nkongsamba	CMR	112454	\N	f
1810	Montréal	CAN	1016376	\N	f
1811	Calgary	CAN	768082	\N	f
1812	Toronto	CAN	688275	\N	f
1813	North York	CAN	622632	\N	f
1814	Winnipeg	CAN	618477	\N	f
1815	Edmonton	CAN	616306	\N	f
1816	Mississauga	CAN	608072	\N	f
1817	Scarborough	CAN	594501	\N	f
1818	Vancouver	CAN	514008	\N	f
1819	Etobicoke	CAN	348845	\N	f
1820	London	CAN	339917	\N	f
1821	Hamilton	CAN	335614	\N	f
1823	Laval	CAN	330393	\N	f
1824	Surrey	CAN	304477	\N	f
1825	Brampton	CAN	296711	\N	f
1826	Windsor	CAN	207588	\N	f
1827	Saskatoon	CAN	193647	\N	f
1828	Kitchener	CAN	189959	\N	f
1829	Markham	CAN	189098	\N	f
1830	Regina	CAN	180400	\N	f
1831	Burnaby	CAN	179209	\N	f
1832	Québec	CAN	167264	\N	f
1833	York	CAN	154980	\N	f
1834	Richmond	CAN	148867	\N	f
1835	Vaughan	CAN	147889	\N	f
1836	Burlington	CAN	145150	\N	f
1837	Oshawa	CAN	140173	\N	f
1838	Oakville	CAN	139192	\N	f
1839	Saint Catharines	CAN	136216	\N	f
1840	Longueuil	CAN	127977	\N	f
1841	Richmond Hill	CAN	116428	\N	f
1842	Thunder Bay	CAN	115913	\N	f
1843	Nepean	CAN	115100	\N	f
1844	Cape Breton	CAN	114733	\N	f
1845	East York	CAN	114034	\N	f
1846	Halifax	CAN	113910	\N	f
1847	Cambridge	CAN	109186	\N	f
1848	Gloucester	CAN	107314	\N	f
1849	Abbotsford	CAN	105403	\N	f
1850	Guelph	CAN	103593	\N	f
1852	Coquitlam	CAN	101820	\N	f
1853	Saanich	CAN	101388	\N	f
1854	Gatineau	CAN	100702	\N	f
1855	Delta	CAN	95411	\N	f
1856	Sudbury	CAN	92686	\N	f
1857	Kelowna	CAN	89442	\N	f
1858	Barrie	CAN	89269	\N	f
1851	St. John's	CAN	101936	\N	f
1781	Aden	YEM	398300	\N	t
1860	Almaty	KAZ	1129400	\N	f
1861	Qaraghandy	KAZ	436900	\N	f
1862	Shymkent	KAZ	360100	\N	f
1863	Taraz	KAZ	330100	\N	f
1865	Öskemen	KAZ	311000	\N	f
1866	Pavlodar	KAZ	300500	\N	f
1867	Semey	KAZ	269600	\N	f
1868	Aqtöbe	KAZ	253100	\N	f
1869	Qostanay	KAZ	221400	\N	f
1870	Petropavl	KAZ	203500	\N	f
1871	Oral	KAZ	195500	\N	f
1872	Temirtau	KAZ	170500	\N	f
1873	Qyzylorda	KAZ	157400	\N	f
1874	Aqtau	KAZ	143400	\N	f
1875	Atyrau	KAZ	142500	\N	f
1876	Ekibastuz	KAZ	127200	\N	f
1877	Kökshetau	KAZ	123400	\N	f
1878	Rudnyy	KAZ	109500	\N	f
1879	Taldyqorghan	KAZ	98000	\N	f
1880	Zhezqazghan	KAZ	90000	\N	f
1882	Mombasa	KEN	461753	\N	f
1883	Kisumu	KEN	192733	\N	f
1884	Nakuru	KEN	163927	\N	f
1885	Machakos	KEN	116293	\N	f
1886	Eldoret	KEN	111882	\N	f
1887	Meru	KEN	94947	\N	f
1888	Nyeri	KEN	91258	\N	f
1890	Shanghai	CHN	9696300	\N	f
1892	Chongqing	CHN	6351600	\N	f
1893	Tianjin	CHN	5286800	\N	f
1894	Wuhan	CHN	4344600	\N	f
1895	Harbin	CHN	4289800	\N	f
1896	Shenyang	CHN	4265200	\N	f
1897	Kanton [Guangzhou]	CHN	4256300	\N	f
1898	Chengdu	CHN	3361500	\N	f
1899	Nanking [Nanjing]	CHN	2870300	\N	f
1900	Changchun	CHN	2812000	\N	f
1901	Xi´an	CHN	2761400	\N	f
1902	Dalian	CHN	2697000	\N	f
1903	Qingdao	CHN	2596000	\N	f
1904	Jinan	CHN	2278100	\N	f
1905	Hangzhou	CHN	2190500	\N	f
1906	Zhengzhou	CHN	2107200	\N	f
1907	Shijiazhuang	CHN	2041500	\N	f
1908	Taiyuan	CHN	1968400	\N	f
1909	Kunming	CHN	1829500	\N	f
1910	Changsha	CHN	1809800	\N	f
1911	Nanchang	CHN	1691600	\N	f
1912	Fuzhou	CHN	1593800	\N	f
1913	Lanzhou	CHN	1565800	\N	f
1914	Guiyang	CHN	1465200	\N	f
1915	Ningbo	CHN	1371200	\N	f
1916	Hefei	CHN	1369100	\N	f
1917	Urumtši [Ürümqi]	CHN	1310100	\N	f
1918	Anshan	CHN	1200000	\N	f
1919	Fushun	CHN	1200000	\N	f
1920	Nanning	CHN	1161800	\N	f
1921	Zibo	CHN	1140000	\N	f
1922	Qiqihar	CHN	1070000	\N	f
1923	Jilin	CHN	1040000	\N	f
1924	Tangshan	CHN	1040000	\N	f
1925	Baotou	CHN	980000	\N	f
1926	Shenzhen	CHN	950500	\N	f
1927	Hohhot	CHN	916700	\N	f
1928	Handan	CHN	840000	\N	f
1929	Wuxi	CHN	830000	\N	f
1930	Xuzhou	CHN	810000	\N	f
1931	Datong	CHN	800000	\N	f
1932	Yichun	CHN	800000	\N	f
1933	Benxi	CHN	770000	\N	f
1934	Luoyang	CHN	760000	\N	f
1935	Suzhou	CHN	710000	\N	f
1936	Xining	CHN	700200	\N	f
1937	Huainan	CHN	700000	\N	f
1938	Jixi	CHN	683885	\N	f
1939	Daqing	CHN	660000	\N	f
1940	Fuxin	CHN	640000	\N	f
1941	Amoy [Xiamen]	CHN	627500	\N	f
1942	Liuzhou	CHN	610000	\N	f
1943	Shantou	CHN	580000	\N	f
1944	Jinzhou	CHN	570000	\N	f
1945	Mudanjiang	CHN	570000	\N	f
1946	Yinchuan	CHN	544500	\N	f
1947	Changzhou	CHN	530000	\N	f
1948	Zhangjiakou	CHN	530000	\N	f
1949	Dandong	CHN	520000	\N	f
1950	Hegang	CHN	520000	\N	f
1951	Kaifeng	CHN	510000	\N	f
1952	Jiamusi	CHN	493409	\N	f
1953	Liaoyang	CHN	492559	\N	f
1954	Hengyang	CHN	487148	\N	f
1955	Baoding	CHN	483155	\N	f
1956	Hunjiang	CHN	482043	\N	f
1957	Xinxiang	CHN	473762	\N	f
1958	Huangshi	CHN	457601	\N	f
1959	Haikou	CHN	454300	\N	f
1960	Yantai	CHN	452127	\N	f
1961	Bengbu	CHN	449245	\N	f
1962	Xiangtan	CHN	441968	\N	f
1963	Weifang	CHN	428522	\N	f
1964	Wuhu	CHN	425740	\N	f
1965	Pingxiang	CHN	425579	\N	f
1966	Yingkou	CHN	421589	\N	f
1967	Anyang	CHN	420332	\N	f
1968	Panzhihua	CHN	415466	\N	f
1969	Pingdingshan	CHN	410775	\N	f
1970	Xiangfan	CHN	410407	\N	f
1971	Zhuzhou	CHN	409924	\N	f
1972	Jiaozuo	CHN	409100	\N	f
1973	Wenzhou	CHN	401871	\N	f
1974	Zhangjiang	CHN	400997	\N	f
1975	Zigong	CHN	393184	\N	f
1976	Shuangyashan	CHN	386081	\N	f
1977	Zaozhuang	CHN	380846	\N	f
1978	Yakeshi	CHN	377869	\N	f
1979	Yichang	CHN	371601	\N	f
1980	Zhenjiang	CHN	368316	\N	f
1981	Huaibei	CHN	366549	\N	f
1982	Qinhuangdao	CHN	364972	\N	f
1983	Guilin	CHN	364130	\N	f
1984	Liupanshui	CHN	363954	\N	f
1985	Panjin	CHN	362773	\N	f
1986	Yangquan	CHN	362268	\N	f
1987	Jinxi	CHN	357052	\N	f
1988	Liaoyuan	CHN	354141	\N	f
1989	Lianyungang	CHN	354139	\N	f
1990	Xianyang	CHN	352125	\N	f
1991	Tai´an	CHN	350696	\N	f
1992	Chifeng	CHN	350077	\N	f
1993	Shaoguan	CHN	350043	\N	f
1994	Nantong	CHN	343341	\N	f
1995	Leshan	CHN	341128	\N	f
1996	Baoji	CHN	337765	\N	f
1997	Linyi	CHN	324720	\N	f
1998	Tonghua	CHN	324600	\N	f
1999	Siping	CHN	317223	\N	f
2000	Changzhi	CHN	317144	\N	f
2001	Tengzhou	CHN	315083	\N	f
2002	Chaozhou	CHN	313469	\N	f
2003	Yangzhou	CHN	312892	\N	f
2004	Dongwan	CHN	308669	\N	f
2005	Ma´anshan	CHN	305421	\N	f
2006	Foshan	CHN	303160	\N	f
1864	Astana	KAZ	311200	\N	t
2007	Yueyang	CHN	302800	\N	f
2008	Xingtai	CHN	302789	\N	f
2009	Changde	CHN	301276	\N	f
2010	Shihezi	CHN	299676	\N	f
2011	Yancheng	CHN	296831	\N	f
2012	Jiujiang	CHN	291187	\N	f
2013	Dongying	CHN	281728	\N	f
2014	Shashi	CHN	281352	\N	f
2015	Xintai	CHN	281248	\N	f
2016	Jingdezhen	CHN	281183	\N	f
2017	Tongchuan	CHN	280657	\N	f
2018	Zhongshan	CHN	278829	\N	f
2019	Shiyan	CHN	273786	\N	f
2020	Tieli	CHN	265683	\N	f
2021	Jining	CHN	265248	\N	f
2022	Wuhai	CHN	264081	\N	f
2023	Mianyang	CHN	262947	\N	f
2024	Luzhou	CHN	262892	\N	f
2025	Zunyi	CHN	261862	\N	f
2026	Shizuishan	CHN	257862	\N	f
2027	Neijiang	CHN	256012	\N	f
2028	Tongliao	CHN	255129	\N	f
2029	Tieling	CHN	254842	\N	f
2030	Wafangdian	CHN	251733	\N	f
2031	Anqing	CHN	250718	\N	f
2032	Shaoyang	CHN	247227	\N	f
2033	Laiwu	CHN	246833	\N	f
2034	Chengde	CHN	246799	\N	f
2035	Tianshui	CHN	244974	\N	f
2036	Nanyang	CHN	243303	\N	f
2037	Cangzhou	CHN	242708	\N	f
2038	Yibin	CHN	241019	\N	f
2039	Huaiyin	CHN	239675	\N	f
2040	Dunhua	CHN	235100	\N	f
2041	Yanji	CHN	230892	\N	f
2042	Jiangmen	CHN	230587	\N	f
2043	Tongling	CHN	228017	\N	f
2044	Suihua	CHN	227881	\N	f
2045	Gongziling	CHN	226569	\N	f
2046	Xiantao	CHN	222884	\N	f
2047	Chaoyang	CHN	222394	\N	f
2048	Ganzhou	CHN	220129	\N	f
2049	Huzhou	CHN	218071	\N	f
2050	Baicheng	CHN	217987	\N	f
2051	Shangzi	CHN	215373	\N	f
2052	Yangjiang	CHN	215196	\N	f
2053	Qitaihe	CHN	214957	\N	f
2054	Gejiu	CHN	214294	\N	f
2055	Jiangyin	CHN	213659	\N	f
2056	Hebi	CHN	212976	\N	f
2057	Jiaxing	CHN	211526	\N	f
2058	Wuzhou	CHN	210452	\N	f
2059	Meihekou	CHN	209038	\N	f
2060	Xuchang	CHN	208815	\N	f
2061	Liaocheng	CHN	207844	\N	f
2062	Haicheng	CHN	205560	\N	f
2063	Qianjiang	CHN	205504	\N	f
2064	Baiyin	CHN	204970	\N	f
2065	Bei´an	CHN	204899	\N	f
2066	Yixing	CHN	200824	\N	f
2067	Laizhou	CHN	198664	\N	f
2068	Qaramay	CHN	197602	\N	f
2069	Acheng	CHN	197595	\N	f
2070	Dezhou	CHN	195485	\N	f
2071	Nanping	CHN	195064	\N	f
2072	Zhaoqing	CHN	194784	\N	f
2073	Beipiao	CHN	194301	\N	f
2074	Fengcheng	CHN	193784	\N	f
2075	Fuyu	CHN	192981	\N	f
2076	Xinyang	CHN	192509	\N	f
2077	Dongtai	CHN	192247	\N	f
2078	Yuci	CHN	191356	\N	f
2079	Honghu	CHN	190772	\N	f
2080	Ezhou	CHN	190123	\N	f
2081	Heze	CHN	189293	\N	f
2082	Daxian	CHN	188101	\N	f
2083	Linfen	CHN	187309	\N	f
2084	Tianmen	CHN	186332	\N	f
2085	Yiyang	CHN	185818	\N	f
2086	Quanzhou	CHN	185154	\N	f
2087	Rizhao	CHN	185048	\N	f
2088	Deyang	CHN	182488	\N	f
2089	Guangyuan	CHN	182241	\N	f
2090	Changshu	CHN	181805	\N	f
2091	Zhangzhou	CHN	181424	\N	f
2092	Hailar	CHN	180650	\N	f
2093	Nanchong	CHN	180273	\N	f
2094	Jiutai	CHN	180130	\N	f
2095	Zhaodong	CHN	179976	\N	f
2096	Shaoxing	CHN	179818	\N	f
2097	Fuyang	CHN	179572	\N	f
2098	Maoming	CHN	178683	\N	f
2099	Qujing	CHN	178669	\N	f
2100	Ghulja	CHN	177193	\N	f
2101	Jiaohe	CHN	176367	\N	f
2102	Puyang	CHN	175988	\N	f
2103	Huadian	CHN	175873	\N	f
2104	Jiangyou	CHN	175753	\N	f
2105	Qashqar	CHN	174570	\N	f
2106	Anshun	CHN	174142	\N	f
2107	Fuling	CHN	173878	\N	f
2108	Xinyu	CHN	173524	\N	f
2109	Hanzhong	CHN	169930	\N	f
2110	Danyang	CHN	169603	\N	f
2111	Chenzhou	CHN	169400	\N	f
2112	Xiaogan	CHN	166280	\N	f
2113	Shangqiu	CHN	164880	\N	f
2114	Zhuhai	CHN	164747	\N	f
2115	Qingyuan	CHN	164641	\N	f
2116	Aqsu	CHN	164092	\N	f
2117	Jining	CHN	163552	\N	f
2118	Xiaoshan	CHN	162930	\N	f
2119	Zaoyang	CHN	162198	\N	f
2120	Xinghua	CHN	161910	\N	f
2121	Hami	CHN	161315	\N	f
2122	Huizhou	CHN	161023	\N	f
2123	Jinmen	CHN	160794	\N	f
2124	Sanming	CHN	160691	\N	f
2125	Ulanhot	CHN	159538	\N	f
2126	Korla	CHN	159344	\N	f
2127	Wanxian	CHN	156823	\N	f
2128	Rui´an	CHN	156468	\N	f
2129	Zhoushan	CHN	156317	\N	f
2130	Liangcheng	CHN	156307	\N	f
2131	Jiaozhou	CHN	153364	\N	f
2132	Taizhou	CHN	152442	\N	f
2133	Suzhou	CHN	151862	\N	f
2134	Yichun	CHN	151585	\N	f
2135	Taonan	CHN	150168	\N	f
2136	Pingdu	CHN	150123	\N	f
2137	Ji´an	CHN	148583	\N	f
2138	Longkou	CHN	148362	\N	f
2139	Langfang	CHN	148105	\N	f
2140	Zhoukou	CHN	146288	\N	f
2141	Suining	CHN	146086	\N	f
2142	Yulin	CHN	144467	\N	f
2143	Jinhua	CHN	144280	\N	f
2144	Liu´an	CHN	144248	\N	f
2145	Shuangcheng	CHN	142659	\N	f
2146	Suizhou	CHN	142302	\N	f
2147	Ankang	CHN	142170	\N	f
2148	Weinan	CHN	140169	\N	f
2149	Longjing	CHN	139417	\N	f
2150	Da´an	CHN	138963	\N	f
2151	Lengshuijiang	CHN	137994	\N	f
2152	Laiyang	CHN	137080	\N	f
2153	Xianning	CHN	136811	\N	f
2154	Dali	CHN	136554	\N	f
2155	Anda	CHN	136446	\N	f
2156	Jincheng	CHN	136396	\N	f
2157	Longyan	CHN	134481	\N	f
2158	Xichang	CHN	134419	\N	f
2159	Wendeng	CHN	133910	\N	f
2160	Hailun	CHN	133565	\N	f
2161	Binzhou	CHN	133555	\N	f
2162	Linhe	CHN	133183	\N	f
2163	Wuwei	CHN	133101	\N	f
2164	Duyun	CHN	132971	\N	f
2165	Mishan	CHN	132744	\N	f
2166	Shangrao	CHN	132455	\N	f
2167	Changji	CHN	132260	\N	f
2168	Meixian	CHN	132156	\N	f
2169	Yushu	CHN	131861	\N	f
2170	Tiefa	CHN	131807	\N	f
2171	Huai´an	CHN	131149	\N	f
2172	Leiyang	CHN	130115	\N	f
2173	Zalantun	CHN	130031	\N	f
2174	Weihai	CHN	128888	\N	f
2175	Loudi	CHN	128418	\N	f
2176	Qingzhou	CHN	128258	\N	f
2177	Qidong	CHN	126872	\N	f
2178	Huaihua	CHN	126785	\N	f
2179	Luohe	CHN	126438	\N	f
2180	Chuzhou	CHN	125341	\N	f
2181	Kaiyuan	CHN	124219	\N	f
2182	Linqing	CHN	123958	\N	f
2183	Chaohu	CHN	123676	\N	f
2184	Laohekou	CHN	123366	\N	f
2185	Dujiangyan	CHN	123357	\N	f
2186	Zhumadian	CHN	123232	\N	f
2187	Linchuan	CHN	121949	\N	f
2188	Jiaonan	CHN	121397	\N	f
2189	Sanmenxia	CHN	120523	\N	f
2190	Heyuan	CHN	120101	\N	f
2191	Manzhouli	CHN	120023	\N	f
2192	Lhasa	CHN	120000	\N	f
2193	Lianyuan	CHN	118858	\N	f
2194	Kuytun	CHN	118553	\N	f
2195	Puqi	CHN	117264	\N	f
2196	Hongjiang	CHN	116188	\N	f
2197	Qinzhou	CHN	114586	\N	f
2198	Renqiu	CHN	114256	\N	f
2199	Yuyao	CHN	114065	\N	f
2200	Guigang	CHN	114025	\N	f
2201	Kaili	CHN	113958	\N	f
2202	Yan´an	CHN	113277	\N	f
2203	Beihai	CHN	112673	\N	f
2204	Xuangzhou	CHN	112673	\N	f
2205	Quzhou	CHN	112373	\N	f
2206	Yong´an	CHN	111762	\N	f
2207	Zixing	CHN	110048	\N	f
2208	Liyang	CHN	109520	\N	f
2209	Yizheng	CHN	109268	\N	f
2210	Yumen	CHN	109234	\N	f
2211	Liling	CHN	108504	\N	f
2212	Yuncheng	CHN	108359	\N	f
2213	Shanwei	CHN	107847	\N	f
2214	Cixi	CHN	107329	\N	f
2215	Yuanjiang	CHN	107004	\N	f
2216	Bozhou	CHN	106346	\N	f
2217	Jinchang	CHN	105287	\N	f
2218	Fu´an	CHN	105265	\N	f
2219	Suqian	CHN	105021	\N	f
2220	Shishou	CHN	104571	\N	f
2221	Hengshui	CHN	104269	\N	f
2222	Danjiangkou	CHN	103211	\N	f
2223	Fujin	CHN	103104	\N	f
2224	Sanya	CHN	102820	\N	f
2225	Guangshui	CHN	102770	\N	f
2226	Huangshan	CHN	102628	\N	f
2227	Xingcheng	CHN	102384	\N	f
2228	Zhucheng	CHN	102134	\N	f
2229	Kunshan	CHN	102052	\N	f
2230	Haining	CHN	100478	\N	f
2231	Pingliang	CHN	99265	\N	f
2232	Fuqing	CHN	99193	\N	f
2233	Xinzhou	CHN	98667	\N	f
2234	Jieyang	CHN	98531	\N	f
2235	Zhangjiagang	CHN	97994	\N	f
2236	Tong Xian	CHN	97168	\N	f
2237	Ya´an	CHN	95900	\N	f
2238	Jinzhou	CHN	95761	\N	f
2239	Emeishan	CHN	94000	\N	f
2240	Enshi	CHN	93056	\N	f
2241	Bose	CHN	93009	\N	f
2242	Yuzhou	CHN	92889	\N	f
2243	Kaiyuan	CHN	91999	\N	f
2244	Tumen	CHN	91471	\N	f
2245	Putian	CHN	91030	\N	f
2246	Linhai	CHN	90870	\N	f
2247	Xilin Hot	CHN	90646	\N	f
2248	Shaowu	CHN	90286	\N	f
2249	Junan	CHN	90222	\N	f
2250	Huaying	CHN	89400	\N	f
2251	Pingyi	CHN	89373	\N	f
2252	Huangyan	CHN	89288	\N	f
2254	Osh	KGZ	222700	\N	f
2255	Bikenibeu	KIR	5055	\N	f
2256	Bairiki	KIR	2226	\N	f
2258	Cali	COL	2077386	\N	f
2259	Medellín	COL	1861265	\N	f
2260	Barranquilla	COL	1223260	\N	f
2261	Cartagena	COL	805757	\N	f
2262	Cúcuta	COL	606932	\N	f
2263	Bucaramanga	COL	515555	\N	f
2264	Ibagué	COL	393664	\N	f
2265	Pereira	COL	381725	\N	f
2266	Santa Marta	COL	359147	\N	f
2267	Manizales	COL	337580	\N	f
2268	Bello	COL	333470	\N	f
2269	Pasto	COL	332396	\N	f
2270	Neiva	COL	300052	\N	f
2271	Soledad	COL	295058	\N	f
2272	Armenia	COL	288977	\N	f
2273	Villavicencio	COL	273140	\N	f
2274	Soacha	COL	272058	\N	f
2275	Valledupar	COL	263247	\N	f
2276	Montería	COL	248245	\N	f
2277	Itagüí	COL	228985	\N	f
2278	Palmira	COL	226509	\N	f
2279	Buenaventura	COL	224336	\N	f
2280	Floridablanca	COL	221913	\N	f
2281	Sincelejo	COL	220704	\N	f
2282	Popayán	COL	200719	\N	f
2283	Barrancabermeja	COL	178020	\N	f
2284	Dos Quebradas	COL	159363	\N	f
2285	Tuluá	COL	152488	\N	f
2286	Envigado	COL	135848	\N	f
2287	Cartago	COL	125884	\N	f
2288	Girardot	COL	110963	\N	f
2289	Buga	COL	110699	\N	f
2290	Tunja	COL	109740	\N	f
2291	Florencia	COL	108574	\N	f
2292	Maicao	COL	108053	\N	f
2293	Sogamoso	COL	107728	\N	f
2294	Giron	COL	90688	\N	f
2297	Pointe-Noire	COG	500000	\N	f
2299	Lubumbashi	COD	851381	\N	f
2300	Mbuji-Mayi	COD	806475	\N	f
2301	Kolwezi	COD	417810	\N	f
2302	Kisangani	COD	417517	\N	f
2303	Kananga	COD	393030	\N	f
2304	Likasi	COD	299118	\N	f
2305	Bukavu	COD	201569	\N	f
2306	Kikwit	COD	182142	\N	f
2307	Tshikapa	COD	180860	\N	f
2308	Matadi	COD	172730	\N	f
2309	Mbandaka	COD	169841	\N	f
2310	Mwene-Ditu	COD	137459	\N	f
2311	Boma	COD	135284	\N	f
2312	Uvira	COD	115590	\N	f
2313	Butembo	COD	109406	\N	f
2314	Goma	COD	109094	\N	f
2315	Kalemie	COD	101309	\N	f
2316	Bantam	CCK	503	\N	f
2319	Hamhung	PRK	709730	\N	f
2320	Chongjin	PRK	582480	\N	f
2321	Nampo	PRK	566200	\N	f
2322	Sinuiju	PRK	326011	\N	f
2323	Wonsan	PRK	300148	\N	f
2324	Phyongsong	PRK	272934	\N	f
2325	Sariwon	PRK	254146	\N	f
2326	Haeju	PRK	229172	\N	f
2327	Kanggye	PRK	223410	\N	f
2328	Kimchaek	PRK	179000	\N	f
2329	Hyesan	PRK	178020	\N	f
2330	Kaesong	PRK	171500	\N	f
2332	Pusan	KOR	3804522	\N	f
2333	Inchon	KOR	2559424	\N	f
2334	Taegu	KOR	2548568	\N	f
2335	Taejon	KOR	1425835	\N	f
2336	Kwangju	KOR	1368341	\N	f
2337	Ulsan	KOR	1084891	\N	f
2338	Songnam	KOR	869094	\N	f
2339	Puchon	KOR	779412	\N	f
2340	Suwon	KOR	755550	\N	f
2341	Anyang	KOR	591106	\N	f
2342	Chonju	KOR	563153	\N	f
2343	Chongju	KOR	531376	\N	f
2344	Koyang	KOR	518282	\N	f
2345	Ansan	KOR	510314	\N	f
2346	Pohang	KOR	508899	\N	f
2347	Chang-won	KOR	481694	\N	f
2348	Masan	KOR	441242	\N	f
2349	Kwangmyong	KOR	350914	\N	f
2350	Chonan	KOR	330259	\N	f
2351	Chinju	KOR	329886	\N	f
2352	Iksan	KOR	322685	\N	f
2353	Pyongtaek	KOR	312927	\N	f
2354	Kumi	KOR	311431	\N	f
2355	Uijongbu	KOR	276111	\N	f
2356	Kyongju	KOR	272968	\N	f
2357	Kunsan	KOR	266569	\N	f
2358	Cheju	KOR	258511	\N	f
2359	Kimhae	KOR	256370	\N	f
2360	Sunchon	KOR	249263	\N	f
2361	Mokpo	KOR	247452	\N	f
2362	Yong-in	KOR	242643	\N	f
2363	Wonju	KOR	237460	\N	f
2364	Kunpo	KOR	235233	\N	f
2365	Chunchon	KOR	234528	\N	f
2366	Namyangju	KOR	229060	\N	f
2367	Kangnung	KOR	220403	\N	f
2368	Chungju	KOR	205206	\N	f
2369	Andong	KOR	188443	\N	f
2370	Yosu	KOR	183596	\N	f
2371	Kyongsan	KOR	173746	\N	f
2372	Paju	KOR	163379	\N	f
2373	Yangsan	KOR	163351	\N	f
2374	Ichon	KOR	155332	\N	f
2375	Asan	KOR	154663	\N	f
2376	Koje	KOR	147562	\N	f
2377	Kimchon	KOR	147027	\N	f
2378	Nonsan	KOR	146619	\N	f
2379	Kuri	KOR	142173	\N	f
2380	Chong-up	KOR	139111	\N	f
2381	Chechon	KOR	137070	\N	f
2382	Sosan	KOR	134746	\N	f
2383	Shihung	KOR	133443	\N	f
2384	Tong-yong	KOR	131717	\N	f
2385	Kongju	KOR	131229	\N	f
2386	Yongju	KOR	131097	\N	f
2387	Chinhae	KOR	125997	\N	f
2388	Sangju	KOR	124116	\N	f
2389	Poryong	KOR	122604	\N	f
2390	Kwang-yang	KOR	122052	\N	f
2391	Miryang	KOR	121501	\N	f
2392	Hanam	KOR	115812	\N	f
2393	Kimje	KOR	115427	\N	f
2394	Yongchon	KOR	113511	\N	f
2395	Sachon	KOR	113494	\N	f
2396	Uiwang	KOR	108788	\N	f
2397	Naju	KOR	107831	\N	f
2398	Namwon	KOR	103544	\N	f
2399	Tonghae	KOR	95472	\N	f
2400	Mun-gyong	KOR	92239	\N	f
2402	Thessaloniki	GRC	383967	\N	f
2403	Pireus	GRC	182671	\N	f
2404	Patras	GRC	153344	\N	f
2405	Peristerion	GRC	137288	\N	f
2406	Herakleion	GRC	116178	\N	f
2407	Kallithea	GRC	114233	\N	f
2408	Larisa	GRC	113090	\N	f
2410	Split	HRV	189388	\N	f
2411	Rijeka	HRV	167964	\N	f
2412	Osijek	HRV	104761	\N	f
2414	Santiago de Cuba	CUB	433180	\N	f
2415	Camagüey	CUB	298726	\N	f
2416	Holguín	CUB	249492	\N	f
2417	Santa Clara	CUB	207350	\N	f
2418	Guantánamo	CUB	205078	\N	f
2419	Pinar del Río	CUB	142100	\N	f
2420	Bayamo	CUB	141000	\N	f
2421	Cienfuegos	CUB	132770	\N	f
2422	Victoria de las Tunas	CUB	132350	\N	f
2423	Matanzas	CUB	123273	\N	f
2424	Manzanillo	CUB	109350	\N	f
2425	Sancti-Spíritus	CUB	100751	\N	f
2426	Ciego de Ávila	CUB	98505	\N	f
2427	al-Salimiya	KWT	130215	\N	f
2428	Jalib al-Shuyukh	KWT	102178	\N	f
2431	Limassol	CYP	154400	\N	f
2433	Savannakhet	LAO	96652	\N	f
2435	Daugavpils	LVA	114829	\N	f
2436	Liepaja	LVA	89439	\N	f
2439	Tripoli	LBN	240000	\N	f
2442	Bengasi	LBY	804000	\N	f
2443	Misrata	LBY	121669	\N	f
2444	al-Zawiya	LBY	89338	\N	f
2445	Schaan	LIE	5346	\N	f
2448	Kaunas	LTU	412639	\N	f
2449	Klaipeda	LTU	202451	\N	f
2450	Šiauliai	LTU	146563	\N	f
2451	Panevezys	LTU	133695	\N	f
2454	Macao	MAC	437500	\N	f
2456	Toamasina	MDG	127441	\N	f
2457	Antsirabé	MDG	120239	\N	f
2458	Mahajanga	MDG	100807	\N	f
2459	Fianarantsoa	MDG	99005	\N	f
2460	Skopje	MKD	444299	\N	f
2461	Blantyre	MWI	478155	\N	f
2465	Ipoh	MYS	382853	\N	f
2466	Johor Baharu	MYS	328436	\N	f
2467	Petaling Jaya	MYS	254350	\N	f
2468	Kelang	MYS	243355	\N	f
2469	Kuala Terengganu	MYS	228119	\N	f
2470	Pinang	MYS	219603	\N	f
2471	Kota Bharu	MYS	219582	\N	f
2472	Kuantan	MYS	199484	\N	f
2473	Taiping	MYS	183261	\N	f
2474	Seremban	MYS	182869	\N	f
2475	Kuching	MYS	148059	\N	f
2476	Sibu	MYS	126381	\N	f
2477	Sandakan	MYS	125841	\N	f
2478	Alor Setar	MYS	124412	\N	f
2479	Selayang Baru	MYS	124228	\N	f
2480	Sungai Petani	MYS	114763	\N	f
2481	Shah Alam	MYS	102019	\N	f
2483	Birkirkara	MLT	21445	\N	f
2485	Casablanca	MAR	2940623	\N	f
2487	Marrakech	MAR	621914	\N	f
2488	Fès	MAR	541162	\N	f
2489	Tanger	MAR	521735	\N	f
2490	Salé	MAR	504420	\N	f
2491	Meknès	MAR	460000	\N	f
2492	Oujda	MAR	365382	\N	f
2493	Kénitra	MAR	292600	\N	f
2494	Tétouan	MAR	277516	\N	f
2495	Safi	MAR	262300	\N	f
2496	Agadir	MAR	155244	\N	f
2497	Mohammedia	MAR	154706	\N	f
2498	Khouribga	MAR	152090	\N	f
2499	Beni-Mellal	MAR	140212	\N	f
2500	Témara	MAR	126303	\N	f
2501	El Jadida	MAR	119083	\N	f
2502	Nador	MAR	112450	\N	f
2503	Ksar el Kebir	MAR	107065	\N	f
2504	Settat	MAR	96200	\N	f
2505	Taza	MAR	92700	\N	f
2506	El Araich	MAR	90400	\N	f
2510	Nouâdhibou	MRT	97600	\N	f
2512	Beau Bassin-Rose Hill	MUS	100616	\N	f
2513	Vacoas-Phoenix	MUS	98464	\N	f
2516	Guadalajara	MEX	1647720	\N	f
2517	Ecatepec de Morelos	MEX	1620303	\N	f
2518	Puebla	MEX	1346176	\N	f
2519	Nezahualcóyotl	MEX	1224924	\N	f
2520	Juárez	MEX	1217818	\N	f
2521	Tijuana	MEX	1212232	\N	f
2522	León	MEX	1133576	\N	f
2523	Monterrey	MEX	1108499	\N	f
2524	Zapopan	MEX	1002239	\N	f
2525	Naucalpan de Juárez	MEX	857511	\N	f
2526	Mexicali	MEX	764902	\N	f
2527	Culiacán	MEX	744859	\N	f
2528	Acapulco de Juárez	MEX	721011	\N	f
2529	Tlalnepantla de Baz	MEX	720755	\N	f
2530	Mérida	MEX	703324	\N	f
2531	Chihuahua	MEX	670208	\N	f
2532	San Luis Potosí	MEX	669353	\N	f
2533	Guadalupe	MEX	668780	\N	f
2534	Toluca	MEX	665617	\N	f
2535	Aguascalientes	MEX	643360	\N	f
2536	Querétaro	MEX	639839	\N	f
2537	Morelia	MEX	619958	\N	f
2538	Hermosillo	MEX	608697	\N	f
2539	Saltillo	MEX	577352	\N	f
2540	Torreón	MEX	529093	\N	f
2541	Centro (Villahermosa)	MEX	519873	\N	f
2542	San Nicolás de los Garza	MEX	495540	\N	f
2543	Durango	MEX	490524	\N	f
2544	Chimalhuacán	MEX	490245	\N	f
2545	Tlaquepaque	MEX	475472	\N	f
2546	Atizapán de Zaragoza	MEX	467262	\N	f
2547	Veracruz	MEX	457119	\N	f
2548	Cuautitlán Izcalli	MEX	452976	\N	f
2549	Irapuato	MEX	440039	\N	f
2550	Tuxtla Gutiérrez	MEX	433544	\N	f
2551	Tultitlán	MEX	432411	\N	f
2552	Reynosa	MEX	419776	\N	f
2553	Benito Juárez	MEX	419276	\N	f
2554	Matamoros	MEX	416428	\N	f
2555	Xalapa	MEX	390058	\N	f
2556	Celaya	MEX	382140	\N	f
2557	Mazatlán	MEX	380265	\N	f
2558	Ensenada	MEX	369573	\N	f
2559	Ahome	MEX	358663	\N	f
2560	Cajeme	MEX	355679	\N	f
2561	Cuernavaca	MEX	337966	\N	f
2562	Tonalá	MEX	336109	\N	f
2563	Valle de Chalco Solidaridad	MEX	323113	\N	f
2564	Nuevo Laredo	MEX	310277	\N	f
2565	Tepic	MEX	305025	\N	f
2566	Tampico	MEX	294789	\N	f
2567	Ixtapaluca	MEX	293160	\N	f
2568	Apodaca	MEX	282941	\N	f
2569	Guasave	MEX	277201	\N	f
2570	Gómez Palacio	MEX	272806	\N	f
2571	Tapachula	MEX	271141	\N	f
2572	Nicolás Romero	MEX	269393	\N	f
2573	Coatzacoalcos	MEX	267037	\N	f
2574	Uruapan	MEX	265211	\N	f
2575	Victoria	MEX	262686	\N	f
2576	Oaxaca de Juárez	MEX	256848	\N	f
2577	Coacalco de Berriozábal	MEX	252270	\N	f
2578	Pachuca de Soto	MEX	244688	\N	f
2579	General Escobedo	MEX	232961	\N	f
2580	Salamanca	MEX	226864	\N	f
2581	Santa Catarina	MEX	226573	\N	f
2582	Tehuacán	MEX	225943	\N	f
2583	Chalco	MEX	222201	\N	f
2584	Cárdenas	MEX	216903	\N	f
2585	Campeche	MEX	216735	\N	f
2586	La Paz	MEX	213045	\N	f
2587	Othón P. Blanco (Chetumal)	MEX	208014	\N	f
2588	Texcoco	MEX	203681	\N	f
2589	La Paz	MEX	196708	\N	f
2590	Metepec	MEX	194265	\N	f
2453	El-Aaiún	ESH	169000	\N	t
2455	Antananarivo	MDG	675669	\N	t
2591	Monclova	MEX	193657	\N	f
2592	Huixquilucan	MEX	193156	\N	f
2593	Chilpancingo de los Bravo	MEX	192509	\N	f
2594	Puerto Vallarta	MEX	183741	\N	f
2595	Fresnillo	MEX	182744	\N	f
2596	Ciudad Madero	MEX	182012	\N	f
2597	Soledad de Graciano Sánchez	MEX	179956	\N	f
2598	San Juan del Río	MEX	179300	\N	f
2599	San Felipe del Progreso	MEX	177330	\N	f
2600	Córdoba	MEX	176952	\N	f
2601	Tecámac	MEX	172410	\N	f
2602	Ocosingo	MEX	171495	\N	f
2603	Carmen	MEX	171367	\N	f
2604	Lázaro Cárdenas	MEX	170878	\N	f
2605	Jiutepec	MEX	170428	\N	f
2606	Papantla	MEX	170123	\N	f
2607	Comalcalco	MEX	164640	\N	f
2608	Zamora	MEX	161191	\N	f
2609	Nogales	MEX	159103	\N	f
2610	Huimanguillo	MEX	158335	\N	f
2611	Cuautla	MEX	153132	\N	f
2612	Minatitlán	MEX	152983	\N	f
2613	Poza Rica de Hidalgo	MEX	152678	\N	f
2614	Ciudad Valles	MEX	146411	\N	f
2615	Navolato	MEX	145396	\N	f
2616	San Luis Río Colorado	MEX	145276	\N	f
2617	Pénjamo	MEX	143927	\N	f
2618	San Andrés Tuxtla	MEX	142251	\N	f
2619	Guanajuato	MEX	141215	\N	f
2620	Navojoa	MEX	140495	\N	f
2621	Zitácuaro	MEX	137970	\N	f
2622	Boca del Río	MEX	135721	\N	f
2623	Allende	MEX	134645	\N	f
2624	Silao	MEX	134037	\N	f
2625	Macuspana	MEX	133795	\N	f
2626	San Juan Bautista Tuxtepec	MEX	133675	\N	f
2627	San Cristóbal de las Casas	MEX	132317	\N	f
2628	Valle de Santiago	MEX	130557	\N	f
2629	Guaymas	MEX	130108	\N	f
2630	Colima	MEX	129454	\N	f
2631	Dolores Hidalgo	MEX	128675	\N	f
2632	Lagos de Moreno	MEX	127949	\N	f
2633	Piedras Negras	MEX	127898	\N	f
2634	Altamira	MEX	127490	\N	f
2635	Túxpam	MEX	126475	\N	f
2636	San Pedro Garza García	MEX	126147	\N	f
2637	Cuauhtémoc	MEX	124279	\N	f
2638	Manzanillo	MEX	124014	\N	f
2639	Iguala de la Independencia	MEX	123883	\N	f
2640	Zacatecas	MEX	123700	\N	f
2641	Tlajomulco de Zúñiga	MEX	123220	\N	f
2642	Tulancingo de Bravo	MEX	121946	\N	f
2643	Zinacantepec	MEX	121715	\N	f
2644	San Martín Texmelucan	MEX	121093	\N	f
2645	Tepatitlán de Morelos	MEX	118948	\N	f
2646	Martínez de la Torre	MEX	118815	\N	f
2647	Orizaba	MEX	118488	\N	f
2648	Apatzingán	MEX	117849	\N	f
2649	Atlixco	MEX	117019	\N	f
2650	Delicias	MEX	116132	\N	f
2651	Ixtlahuaca	MEX	115548	\N	f
2652	El Mante	MEX	112453	\N	f
2653	Lerdo	MEX	112272	\N	f
2654	Almoloya de Juárez	MEX	110550	\N	f
2655	Acámbaro	MEX	110487	\N	f
2656	Acuña	MEX	110388	\N	f
2657	Guadalupe	MEX	108881	\N	f
2658	Huejutla de Reyes	MEX	108017	\N	f
2659	Hidalgo	MEX	106198	\N	f
2660	Los Cabos	MEX	105199	\N	f
2661	Comitán de Domínguez	MEX	104986	\N	f
2662	Cunduacán	MEX	104164	\N	f
2663	Río Bravo	MEX	103901	\N	f
2664	Temapache	MEX	102824	\N	f
2665	Chilapa de Alvarez	MEX	102716	\N	f
2666	Hidalgo del Parral	MEX	100881	\N	f
2667	San Francisco del Rincón	MEX	100149	\N	f
2668	Taxco de Alarcón	MEX	99907	\N	f
2669	Zumpango	MEX	99781	\N	f
2670	San Pedro Cholula	MEX	99734	\N	f
2671	Lerma	MEX	99714	\N	f
2672	Tecomán	MEX	99296	\N	f
2673	Las Margaritas	MEX	97389	\N	f
2674	Cosoleacaque	MEX	97199	\N	f
2675	San Luis de la Paz	MEX	96763	\N	f
2676	José Azueta	MEX	95448	\N	f
2677	Santiago Ixcuintla	MEX	95311	\N	f
2678	San Felipe	MEX	95305	\N	f
2679	Tejupilco	MEX	94934	\N	f
2680	Tantoyuca	MEX	94709	\N	f
2681	Salvatierra	MEX	94322	\N	f
2682	Tultepec	MEX	93364	\N	f
2683	Temixco	MEX	92686	\N	f
2684	Matamoros	MEX	91858	\N	f
2685	Pánuco	MEX	90551	\N	f
2686	El Fuerte	MEX	89556	\N	f
2687	Tierra Blanca	MEX	89143	\N	f
2688	Weno	FSM	22000	\N	f
2691	Tiraspol	MDA	194300	\N	f
2692	Balti	MDA	153400	\N	f
2693	Bender (Tîghina)	MDA	125700	\N	f
2694	Monte-Carlo	MCO	13154	\N	f
2699	Matola	MOZ	424662	\N	f
2700	Beira	MOZ	397368	\N	f
2701	Nampula	MOZ	303346	\N	f
2702	Chimoio	MOZ	171056	\N	f
2703	Naçala-Porto	MOZ	158248	\N	f
2704	Quelimane	MOZ	150116	\N	f
2705	Mocuba	MOZ	124700	\N	f
2706	Tete	MOZ	101984	\N	f
2707	Xai-Xai	MOZ	99442	\N	f
2708	Gurue	MOZ	99300	\N	f
2709	Maxixe	MOZ	93985	\N	f
2710	Rangoon (Yangon)	MMR	3361700	\N	f
2711	Mandalay	MMR	885300	\N	f
2712	Moulmein (Mawlamyine)	MMR	307900	\N	f
2713	Pegu (Bago)	MMR	190900	\N	f
2714	Bassein (Pathein)	MMR	183900	\N	f
2715	Monywa	MMR	138600	\N	f
2716	Sittwe (Akyab)	MMR	137600	\N	f
2717	Taunggyi (Taunggye)	MMR	131500	\N	f
2718	Meikhtila	MMR	129700	\N	f
2719	Mergui (Myeik)	MMR	122700	\N	f
2720	Lashio (Lasho)	MMR	107600	\N	f
2721	Prome (Pyay)	MMR	105700	\N	f
2722	Henzada (Hinthada)	MMR	104700	\N	f
2723	Myingyan	MMR	103600	\N	f
2724	Tavoy (Dawei)	MMR	96800	\N	f
2689	Palikir	FSM	8600	\N	t
2725	Pagakku (Pakokku)	MMR	94800	\N	f
2727	Yangor	NRU	4050	\N	f
2728	Yaren	NRU	559	\N	f
2730	Biratnagar	NPL	157764	\N	f
2731	Pokhara	NPL	146318	\N	f
2732	Lalitapur	NPL	145847	\N	f
2733	Birgunj	NPL	90639	\N	f
2735	León	NIC	123865	\N	f
2736	Chinandega	NIC	97387	\N	f
2737	Masaya	NIC	88971	\N	f
2739	Zinder	NER	120892	\N	f
2740	Maradi	NER	112965	\N	f
2741	Lagos	NGA	1518000	\N	f
2742	Ibadan	NGA	1432000	\N	f
2743	Ogbomosho	NGA	730000	\N	f
2744	Kano	NGA	674100	\N	f
2745	Oshogbo	NGA	476800	\N	f
2746	Ilorin	NGA	475800	\N	f
2747	Abeokuta	NGA	427400	\N	f
2748	Port Harcourt	NGA	410000	\N	f
2749	Zaria	NGA	379200	\N	f
2750	Ilesha	NGA	378400	\N	f
2751	Onitsha	NGA	371900	\N	f
2752	Iwo	NGA	362000	\N	f
2753	Ado-Ekiti	NGA	359400	\N	f
2755	Kaduna	NGA	342200	\N	f
2756	Mushin	NGA	333200	\N	f
2757	Maiduguri	NGA	320000	\N	f
2758	Enugu	NGA	316100	\N	f
2759	Ede	NGA	307100	\N	f
2760	Aba	NGA	298900	\N	f
2761	Ife	NGA	296800	\N	f
2762	Ila	NGA	264000	\N	f
2763	Oyo	NGA	256400	\N	f
2764	Ikerre	NGA	244600	\N	f
2765	Benin City	NGA	229400	\N	f
2766	Iseyin	NGA	217300	\N	f
2767	Katsina	NGA	206500	\N	f
2768	Jos	NGA	206300	\N	f
2769	Sokoto	NGA	204900	\N	f
2770	Ilobu	NGA	199000	\N	f
2771	Offa	NGA	197200	\N	f
2772	Ikorodu	NGA	184900	\N	f
2773	Ilawe-Ekiti	NGA	184500	\N	f
2774	Owo	NGA	183500	\N	f
2775	Ikirun	NGA	181400	\N	f
2776	Shaki	NGA	174500	\N	f
2777	Calabar	NGA	174400	\N	f
2778	Ondo	NGA	173600	\N	f
2779	Akure	NGA	162300	\N	f
2780	Gusau	NGA	158000	\N	f
2781	Ijebu-Ode	NGA	156400	\N	f
2782	Effon-Alaiye	NGA	153100	\N	f
2783	Kumo	NGA	148000	\N	f
2784	Shomolu	NGA	147700	\N	f
2785	Oka-Akoko	NGA	142900	\N	f
2786	Ikare	NGA	140800	\N	f
2787	Sapele	NGA	139200	\N	f
2788	Deba Habe	NGA	138600	\N	f
2789	Minna	NGA	136900	\N	f
2790	Warri	NGA	126100	\N	f
2791	Bida	NGA	125500	\N	f
2792	Ikire	NGA	123300	\N	f
2793	Makurdi	NGA	123100	\N	f
2794	Lafia	NGA	122500	\N	f
2795	Inisa	NGA	119800	\N	f
2796	Shagamu	NGA	117200	\N	f
2797	Awka	NGA	111200	\N	f
2798	Gombe	NGA	107800	\N	f
2799	Igboho	NGA	106800	\N	f
2800	Ejigbo	NGA	105900	\N	f
2801	Agege	NGA	105000	\N	f
2802	Ise-Ekiti	NGA	103400	\N	f
2803	Ugep	NGA	102600	\N	f
2804	Epe	NGA	101000	\N	f
2808	Bergen	NOR	230948	\N	f
2809	Trondheim	NOR	150166	\N	f
2810	Stavanger	NOR	108848	\N	f
2811	Bærum	NOR	101340	\N	f
2812	Abidjan	CIV	2500000	\N	f
2813	Bouaké	CIV	329850	\N	f
2815	Daloa	CIV	121842	\N	f
2816	Korhogo	CIV	109445	\N	f
2817	al-Sib	OMN	155000	\N	f
2818	Salala	OMN	131813	\N	f
2819	Bawshar	OMN	107500	\N	f
2820	Suhar	OMN	90814	\N	f
2822	Karachi	PAK	9269265	\N	f
2823	Lahore	PAK	5063499	\N	f
2824	Faisalabad	PAK	1977246	\N	f
2825	Rawalpindi	PAK	1406214	\N	f
2826	Multan	PAK	1182441	\N	f
2827	Hyderabad	PAK	1151274	\N	f
2828	Gujranwala	PAK	1124749	\N	f
2829	Peshawar	PAK	988005	\N	f
2830	Quetta	PAK	560307	\N	f
2832	Sargodha	PAK	455360	\N	f
2833	Sialkot	PAK	417597	\N	f
2834	Bahawalpur	PAK	403408	\N	f
2835	Sukkur	PAK	329176	\N	f
2836	Jhang	PAK	292214	\N	f
2837	Sheikhupura	PAK	271875	\N	f
2838	Larkana	PAK	270366	\N	f
2839	Gujrat	PAK	250121	\N	f
2840	Mardan	PAK	244511	\N	f
2841	Kasur	PAK	241649	\N	f
2842	Rahim Yar Khan	PAK	228479	\N	f
2843	Sahiwal	PAK	207388	\N	f
2844	Okara	PAK	200901	\N	f
2845	Wah	PAK	198400	\N	f
2846	Dera Ghazi Khan	PAK	188100	\N	f
2847	Mirpur Khas	PAK	184500	\N	f
2848	Nawabshah	PAK	183100	\N	f
2849	Mingora	PAK	174500	\N	f
2850	Chiniot	PAK	169300	\N	f
2851	Kamoke	PAK	151000	\N	f
2852	Mandi Burewala	PAK	149900	\N	f
2853	Jhelum	PAK	145800	\N	f
2854	Sadiqabad	PAK	141500	\N	f
2855	Jacobabad	PAK	137700	\N	f
2856	Shikarpur	PAK	133300	\N	f
2857	Khanewal	PAK	133000	\N	f
2858	Hafizabad	PAK	130200	\N	f
2859	Kohat	PAK	125300	\N	f
2860	Muzaffargarh	PAK	121600	\N	f
2861	Khanpur	PAK	117800	\N	f
2862	Gojra	PAK	115000	\N	f
2863	Bahawalnagar	PAK	109600	\N	f
2864	Muridke	PAK	108600	\N	f
2865	Pak Pattan	PAK	107800	\N	f
2866	Abottabad	PAK	106000	\N	f
2867	Tando Adam	PAK	103400	\N	f
2868	Jaranwala	PAK	103300	\N	f
2869	Khairpur	PAK	102200	\N	f
2870	Chishtian Mandi	PAK	101700	\N	f
2871	Daska	PAK	101500	\N	f
2872	Dadu	PAK	98600	\N	f
2873	Mandi Bahauddin	PAK	97300	\N	f
2874	Ahmadpur East	PAK	96000	\N	f
2875	Kamalia	PAK	95300	\N	f
2876	Khuzdar	PAK	93100	\N	f
2877	Vihari	PAK	92300	\N	f
2878	Dera Ismail Khan	PAK	90400	\N	f
2879	Wazirabad	PAK	89700	\N	f
2880	Nowshera	PAK	89400	\N	f
2881	Koror	PLW	12000	\N	f
2883	San Miguelito	PAN	315382	\N	f
2886	Ciudad del Este	PRY	133881	\N	f
2887	San Lorenzo	PRY	133395	\N	f
2888	Lambaré	PRY	99681	\N	f
2889	Fernando de la Mora	PRY	95287	\N	f
2891	Arequipa	PER	762000	\N	f
2892	Trujillo	PER	652000	\N	f
2893	Chiclayo	PER	517000	\N	f
2894	Callao	PER	424294	\N	f
2895	Iquitos	PER	367000	\N	f
2896	Chimbote	PER	336000	\N	f
2897	Huancayo	PER	327000	\N	f
2898	Piura	PER	325000	\N	f
2899	Cusco	PER	291000	\N	f
2900	Pucallpa	PER	220866	\N	f
2901	Tacna	PER	215683	\N	f
2902	Ica	PER	194820	\N	f
2903	Sullana	PER	147361	\N	f
2904	Juliaca	PER	142576	\N	f
2905	Huánuco	PER	129688	\N	f
2906	Ayacucho	PER	118960	\N	f
2907	Chincha Alta	PER	110016	\N	f
2908	Cajamarca	PER	108009	\N	f
2909	Puno	PER	101578	\N	f
2910	Ventanilla	PER	101056	\N	f
2911	Castilla	PER	90642	\N	f
2913	Garapan	MNP	9200	\N	f
2915	Porto	PRT	273060	\N	f
2916	Amadora	PRT	122106	\N	f
2917	Coímbra	PRT	96100	\N	f
2918	Braga	PRT	90535	\N	f
2920	Bayamón	PRI	224044	\N	f
2921	Ponce	PRI	186475	\N	f
2922	Carolina	PRI	186076	\N	f
2923	Caguas	PRI	140502	\N	f
2924	Arecibo	PRI	100131	\N	f
2925	Guaynabo	PRI	100053	\N	f
2926	Mayagüez	PRI	98434	\N	f
2927	Toa Baja	PRI	94085	\N	f
2929	Lódz	POL	800110	\N	f
2930	Kraków	POL	738150	\N	f
2931	Wroclaw	POL	636765	\N	f
2932	Poznan	POL	576899	\N	f
2933	Gdansk	POL	458988	\N	f
2934	Szczecin	POL	416988	\N	f
2935	Bydgoszcz	POL	386855	\N	f
2936	Lublin	POL	356251	\N	f
2937	Katowice	POL	345934	\N	f
2938	Bialystok	POL	283937	\N	f
2939	Czestochowa	POL	257812	\N	f
2940	Gdynia	POL	253521	\N	f
2941	Sosnowiec	POL	244102	\N	f
2942	Radom	POL	232262	\N	f
2943	Kielce	POL	212383	\N	f
2944	Gliwice	POL	212164	\N	f
2945	Torun	POL	206158	\N	f
2946	Bytom	POL	205560	\N	f
2947	Zabrze	POL	200177	\N	f
2948	Bielsko-Biala	POL	180307	\N	f
2949	Olsztyn	POL	170904	\N	f
2950	Rzeszów	POL	162049	\N	f
2951	Ruda Slaska	POL	159665	\N	f
2952	Rybnik	POL	144582	\N	f
2953	Walbrzych	POL	136923	\N	f
2954	Tychy	POL	133178	\N	f
2955	Dabrowa Górnicza	POL	131037	\N	f
2956	Plock	POL	131011	\N	f
2957	Elblag	POL	129782	\N	f
2958	Opole	POL	129553	\N	f
2959	Gorzów Wielkopolski	POL	126019	\N	f
2960	Wloclawek	POL	123373	\N	f
2961	Chorzów	POL	121708	\N	f
2962	Tarnów	POL	121494	\N	f
2963	Zielona Góra	POL	118182	\N	f
2964	Koszalin	POL	112375	\N	f
2965	Legnica	POL	109335	\N	f
2966	Kalisz	POL	106641	\N	f
2967	Grudziadz	POL	102434	\N	f
2968	Slupsk	POL	102370	\N	f
2969	Jastrzebie-Zdrój	POL	102294	\N	f
2970	Jaworzno	POL	97929	\N	f
2971	Jelenia Góra	POL	93901	\N	f
2975	Marseille	FRA	798430	\N	f
2976	Lyon	FRA	445452	\N	f
2977	Toulouse	FRA	390350	\N	f
2978	Nice	FRA	342738	\N	f
2979	Nantes	FRA	270251	\N	f
2980	Strasbourg	FRA	264115	\N	f
2981	Montpellier	FRA	225392	\N	f
2982	Bordeaux	FRA	215363	\N	f
2983	Rennes	FRA	206229	\N	f
2984	Le Havre	FRA	190905	\N	f
2985	Reims	FRA	187206	\N	f
2986	Lille	FRA	184657	\N	f
2987	St-Étienne	FRA	180210	\N	f
2988	Toulon	FRA	160639	\N	f
2989	Grenoble	FRA	153317	\N	f
2990	Angers	FRA	151279	\N	f
2991	Dijon	FRA	149867	\N	f
2992	Brest	FRA	149634	\N	f
2993	Le Mans	FRA	146105	\N	f
2994	Clermont-Ferrand	FRA	137140	\N	f
2995	Amiens	FRA	135501	\N	f
2996	Aix-en-Provence	FRA	134222	\N	f
2997	Limoges	FRA	133968	\N	f
2998	Nîmes	FRA	133424	\N	f
2999	Tours	FRA	132820	\N	f
3000	Villeurbanne	FRA	124215	\N	f
3001	Metz	FRA	123776	\N	f
3002	Besançon	FRA	117733	\N	f
3003	Caen	FRA	113987	\N	f
3004	Orléans	FRA	113126	\N	f
3005	Mulhouse	FRA	110359	\N	f
3006	Rouen	FRA	106592	\N	f
3007	Boulogne-Billancourt	FRA	106367	\N	f
3008	Perpignan	FRA	105115	\N	f
3009	Nancy	FRA	103605	\N	f
3010	Roubaix	FRA	96984	\N	f
3011	Argenteuil	FRA	93961	\N	f
3012	Tourcoing	FRA	93540	\N	f
3013	Montreuil	FRA	90674	\N	f
3015	Faaa	PYF	25888	\N	f
3049	Gothenburg [Göteborg]	SWE	466990	\N	f
3050	Malmö	SWE	259579	\N	f
3051	Uppsala	SWE	189569	\N	f
3052	Linköping	SWE	133168	\N	f
3053	Västerås	SWE	126328	\N	f
3054	Örebro	SWE	124207	\N	f
3055	Norrköping	SWE	122199	\N	f
3056	Helsingborg	SWE	117737	\N	f
3057	Jönköping	SWE	117095	\N	f
3058	Umeå	SWE	104512	\N	f
3059	Lund	SWE	98948	\N	f
3060	Borås	SWE	96883	\N	f
3061	Sundsvall	SWE	93126	\N	f
3062	Gävle	SWE	90742	\N	f
3069	Hamburg	DEU	1704735	\N	f
3070	Munich [München]	DEU	1194560	\N	f
3071	Köln	DEU	962507	\N	f
3072	Frankfurt am Main	DEU	643821	\N	f
3073	Essen	DEU	599515	\N	f
3074	Dortmund	DEU	590213	\N	f
3075	Stuttgart	DEU	582443	\N	f
3076	Düsseldorf	DEU	568855	\N	f
3077	Bremen	DEU	540330	\N	f
3078	Duisburg	DEU	519793	\N	f
3079	Hannover	DEU	514718	\N	f
3080	Leipzig	DEU	489532	\N	f
3081	Nürnberg	DEU	486628	\N	f
3082	Dresden	DEU	476668	\N	f
3083	Bochum	DEU	392830	\N	f
3084	Wuppertal	DEU	368993	\N	f
3085	Bielefeld	DEU	321125	\N	f
3086	Mannheim	DEU	307730	\N	f
3087	Bonn	DEU	301048	\N	f
3088	Gelsenkirchen	DEU	281979	\N	f
3089	Karlsruhe	DEU	277204	\N	f
3090	Wiesbaden	DEU	268716	\N	f
3091	Münster	DEU	264670	\N	f
3092	Mönchengladbach	DEU	263697	\N	f
3093	Chemnitz	DEU	263222	\N	f
3094	Augsburg	DEU	254867	\N	f
3095	Halle/Saale	DEU	254360	\N	f
3096	Braunschweig	DEU	246322	\N	f
3097	Aachen	DEU	243825	\N	f
3098	Krefeld	DEU	241769	\N	f
3099	Magdeburg	DEU	235073	\N	f
3100	Kiel	DEU	233795	\N	f
3101	Oberhausen	DEU	222349	\N	f
3102	Lübeck	DEU	213326	\N	f
3103	Hagen	DEU	205201	\N	f
3104	Rostock	DEU	203279	\N	f
3105	Freiburg im Breisgau	DEU	202455	\N	f
3106	Erfurt	DEU	201267	\N	f
3107	Kassel	DEU	196211	\N	f
3108	Saarbrücken	DEU	183836	\N	f
3109	Mainz	DEU	183134	\N	f
3110	Hamm	DEU	181804	\N	f
3111	Herne	DEU	175661	\N	f
3112	Mülheim an der Ruhr	DEU	173895	\N	f
3113	Solingen	DEU	165583	\N	f
3114	Osnabrück	DEU	164539	\N	f
3115	Ludwigshafen am Rhein	DEU	163771	\N	f
3116	Leverkusen	DEU	160841	\N	f
3117	Oldenburg	DEU	154125	\N	f
3118	Neuss	DEU	149702	\N	f
3119	Heidelberg	DEU	139672	\N	f
3120	Darmstadt	DEU	137776	\N	f
3121	Paderborn	DEU	137647	\N	f
3122	Potsdam	DEU	128983	\N	f
3123	Würzburg	DEU	127350	\N	f
3124	Regensburg	DEU	125236	\N	f
3125	Recklinghausen	DEU	125022	\N	f
3126	Göttingen	DEU	124775	\N	f
3127	Bremerhaven	DEU	122735	\N	f
3128	Wolfsburg	DEU	121954	\N	f
3129	Bottrop	DEU	121097	\N	f
3130	Remscheid	DEU	120125	\N	f
3131	Heilbronn	DEU	119526	\N	f
3132	Pforzheim	DEU	117227	\N	f
3133	Offenbach am Main	DEU	116627	\N	f
3134	Ulm	DEU	116103	\N	f
3135	Ingolstadt	DEU	114826	\N	f
3136	Gera	DEU	114718	\N	f
3137	Salzgitter	DEU	112934	\N	f
3138	Cottbus	DEU	110894	\N	f
3139	Reutlingen	DEU	110343	\N	f
3140	Fürth	DEU	109771	\N	f
3141	Siegen	DEU	109225	\N	f
3142	Koblenz	DEU	108003	\N	f
3143	Moers	DEU	106837	\N	f
3144	Bergisch Gladbach	DEU	106150	\N	f
3145	Zwickau	DEU	104146	\N	f
3146	Hildesheim	DEU	104013	\N	f
3147	Witten	DEU	103384	\N	f
3148	Schwerin	DEU	102878	\N	f
3149	Erlangen	DEU	100750	\N	f
3150	Kaiserslautern	DEU	100025	\N	f
3151	Trier	DEU	99891	\N	f
3152	Jena	DEU	99779	\N	f
3153	Iserlohn	DEU	99474	\N	f
3154	Gütersloh	DEU	95028	\N	f
3155	Marl	DEU	93735	\N	f
3156	Lünen	DEU	92044	\N	f
3157	Düren	DEU	91092	\N	f
3158	Ratingen	DEU	90951	\N	f
3159	Velbert	DEU	89881	\N	f
3160	Esslingen am Neckar	DEU	89667	\N	f
3163	Ndola	ZMB	329200	\N	f
3164	Kitwe	ZMB	288600	\N	f
3165	Kabwe	ZMB	154300	\N	f
3166	Chingola	ZMB	142400	\N	f
3167	Mufulira	ZMB	123900	\N	f
3168	Luanshya	ZMB	118100	\N	f
3170	Serravalle	SMR	4802	\N	f
3174	Jedda	SAU	2046300	\N	f
3175	Mekka	SAU	965700	\N	f
3176	Medina	SAU	608300	\N	f
3177	al-Dammam	SAU	482300	\N	f
3178	al-Taif	SAU	416100	\N	f
3179	Tabuk	SAU	292600	\N	f
3180	Burayda	SAU	248600	\N	f
3181	al-Hufuf	SAU	225800	\N	f
3182	al-Mubarraz	SAU	219100	\N	f
3183	Khamis Mushayt	SAU	217900	\N	f
3184	Hail	SAU	176800	\N	f
3185	al-Kharj	SAU	152100	\N	f
3186	al-Khubar	SAU	141700	\N	f
3187	Jubayl	SAU	140800	\N	f
3188	Hafar al-Batin	SAU	137800	\N	f
3189	al-Tuqba	SAU	125700	\N	f
3190	Yanbu	SAU	119800	\N	f
3191	Abha	SAU	112300	\N	f
3192	Ara´ar	SAU	108100	\N	f
3193	al-Qatif	SAU	98900	\N	f
3194	al-Hawiya	SAU	93900	\N	f
3195	Unayza	SAU	91100	\N	f
3196	Najran	SAU	91000	\N	f
3197	Pikine	SEN	855287	\N	f
3199	Thiès	SEN	248000	\N	f
3200	Kaolack	SEN	199000	\N	f
3201	Ziguinchor	SEN	192000	\N	f
3202	Rufisque	SEN	150000	\N	f
3203	Saint-Louis	SEN	132400	\N	f
3204	Mbour	SEN	109300	\N	f
3205	Diourbel	SEN	99400	\N	f
3210	Košice	SVK	241874	\N	f
3211	Prešov	SVK	93977	\N	f
3213	Maribor	SVN	115532	\N	f
3215	Hargeysa	SOM	90000	\N	f
3216	Kismaayo	SOM	90000	\N	f
3217	Colombo	LKA	645000	\N	f
3218	Dehiwala	LKA	203000	\N	f
3219	Moratuwa	LKA	190000	\N	f
3220	Jaffna	LKA	149000	\N	f
3221	Kandy	LKA	140000	\N	f
3223	Negombo	LKA	100000	\N	f
3224	Omdurman	SDN	1271403	\N	f
3226	Sharq al-Nil	SDN	700887	\N	f
3227	Port Sudan	SDN	308195	\N	f
3228	Kassala	SDN	234622	\N	f
3229	Obeid	SDN	229425	\N	f
3230	Nyala	SDN	227183	\N	f
3231	Wad Madani	SDN	211362	\N	f
3232	al-Qadarif	SDN	191164	\N	f
3233	Kusti	SDN	173599	\N	f
3234	al-Fashir	SDN	141884	\N	f
3237	Espoo	FIN	213271	\N	f
3238	Tampere	FIN	195468	\N	f
3239	Vantaa	FIN	178471	\N	f
3240	Turku [Åbo]	FIN	172561	\N	f
3241	Oulu	FIN	120753	\N	f
3242	Lahti	FIN	96921	\N	f
3245	Zürich	CHE	336800	\N	f
3246	Geneve	CHE	173500	\N	f
3247	Basel	CHE	166700	\N	f
3249	Lausanne	CHE	114500	\N	f
3251	Aleppo	SYR	1261983	\N	f
3252	Hims	SYR	507404	\N	f
3253	Hama	SYR	343361	\N	f
3254	Latakia	SYR	264563	\N	f
3255	al-Qamishliya	SYR	144286	\N	f
3256	Dayr al-Zawr	SYR	140459	\N	f
3257	Jaramana	SYR	138469	\N	f
3258	Duma	SYR	131158	\N	f
3259	al-Raqqa	SYR	108020	\N	f
3260	Idlib	SYR	91081	\N	f
3262	Khujand	TJK	161500	\N	f
3264	Kaohsiung	TWN	1475505	\N	f
3265	Taichung	TWN	940589	\N	f
3266	Tainan	TWN	728060	\N	f
3267	Panchiao	TWN	523850	\N	f
3268	Chungho	TWN	392176	\N	f
3269	Keelung (Chilung)	TWN	385201	\N	f
3270	Sanchung	TWN	380084	\N	f
3271	Hsinchuang	TWN	365048	\N	f
3272	Hsinchu	TWN	361958	\N	f
3273	Chungli	TWN	318649	\N	f
3274	Fengshan	TWN	318562	\N	f
3275	Taoyuan	TWN	316438	\N	f
3276	Chiayi	TWN	265109	\N	f
3277	Hsintien	TWN	263603	\N	f
3278	Changhwa	TWN	227715	\N	f
3279	Yungho	TWN	227700	\N	f
3280	Tucheng	TWN	224897	\N	f
3281	Pingtung	TWN	214727	\N	f
3282	Yungkang	TWN	193005	\N	f
3283	Pingchen	TWN	188344	\N	f
3284	Tali	TWN	171940	\N	f
3285	Taiping	TWN	165524	\N	f
3286	Pate	TWN	161700	\N	f
3287	Fengyuan	TWN	161032	\N	f
3288	Luchou	TWN	160516	\N	f
3289	Hsichuh	TWN	154976	\N	f
3290	Shulin	TWN	151260	\N	f
3291	Yuanlin	TWN	126402	\N	f
3292	Yangmei	TWN	126323	\N	f
3293	Taliao	TWN	115897	\N	f
3294	Kueishan	TWN	112195	\N	f
3295	Tanshui	TWN	111882	\N	f
3296	Taitung	TWN	111039	\N	f
3297	Hualien	TWN	108407	\N	f
3298	Nantou	TWN	104723	\N	f
3299	Lungtan	TWN	103088	\N	f
3300	Touliu	TWN	98900	\N	f
3301	Tsaotun	TWN	96800	\N	f
3302	Kangshan	TWN	92200	\N	f
3303	Ilan	TWN	92000	\N	f
3304	Miaoli	TWN	90000	\N	f
3305	Dar es Salaam	TZA	1747000	\N	f
3307	Mwanza	TZA	172300	\N	f
3308	Zanzibar	TZA	157634	\N	f
3309	Tanga	TZA	137400	\N	f
3310	Mbeya	TZA	130800	\N	f
3311	Morogoro	TZA	117800	\N	f
3312	Arusha	TZA	102500	\N	f
3313	Moshi	TZA	96800	\N	f
3314	Tabora	TZA	92800	\N	f
3316	Århus	DNK	284846	\N	f
3317	Odense	DNK	183912	\N	f
3318	Aalborg	DNK	161161	\N	f
3319	Frederiksberg	DNK	90327	\N	f
3321	Nonthaburi	THA	292100	\N	f
3322	Nakhon Ratchasima	THA	181400	\N	f
3323	Chiang Mai	THA	171100	\N	f
3324	Udon Thani	THA	158100	\N	f
3325	Hat Yai	THA	148632	\N	f
3326	Khon Kaen	THA	126500	\N	f
3327	Pak Kret	THA	126055	\N	f
3328	Nakhon Sawan	THA	123800	\N	f
3329	Ubon Ratchathani	THA	116300	\N	f
3330	Songkhla	THA	94900	\N	f
3331	Nakhon Pathom	THA	94100	\N	f
3333	Fakaofo	TKL	300	\N	f
3335	Chaguanas	TTO	56601	\N	f
3198	Dakar	SEN	785071	\N	t
3206	Victoria	SYC	41000	\N	t
3235	Juba	SSD	114980	\N	t
3338	Moundou	TCD	99500	\N	f
3340	Brno	CZE	381862	\N	f
3341	Ostrava	CZE	320041	\N	f
3342	Plzen	CZE	166759	\N	f
3343	Olomouc	CZE	102702	\N	f
3344	Liberec	CZE	99155	\N	f
3345	Ceské Budejovice	CZE	98186	\N	f
3346	Hradec Králové	CZE	98080	\N	f
3347	Ústí nad Labem	CZE	95491	\N	f
3348	Pardubice	CZE	91309	\N	f
3350	Sfax	TUN	257800	\N	f
3351	Ariana	TUN	197000	\N	f
3352	Ettadhamen	TUN	178600	\N	f
3353	Sousse	TUN	145900	\N	f
3354	Kairouan	TUN	113100	\N	f
3355	Biserta	TUN	108900	\N	f
3356	Gabès	TUN	106600	\N	f
3357	Istanbul	TUR	8787958	\N	f
3359	Izmir	TUR	2130359	\N	f
3360	Adana	TUR	1131198	\N	f
3361	Bursa	TUR	1095842	\N	f
3362	Gaziantep	TUR	789056	\N	f
3363	Konya	TUR	628364	\N	f
3364	Mersin (Içel)	TUR	587212	\N	f
3365	Antalya	TUR	564914	\N	f
3366	Diyarbakir	TUR	479884	\N	f
3367	Kayseri	TUR	475657	\N	f
3368	Eskisehir	TUR	470781	\N	f
3369	Sanliurfa	TUR	405905	\N	f
3370	Samsun	TUR	339871	\N	f
3371	Malatya	TUR	330312	\N	f
3372	Gebze	TUR	264170	\N	f
3373	Denizli	TUR	253848	\N	f
3374	Sivas	TUR	246642	\N	f
3375	Erzurum	TUR	246535	\N	f
3376	Tarsus	TUR	246206	\N	f
3377	Kahramanmaras	TUR	245772	\N	f
3378	Elâzig	TUR	228815	\N	f
3379	Van	TUR	219319	\N	f
3380	Sultanbeyli	TUR	211068	\N	f
3381	Izmit (Kocaeli)	TUR	210068	\N	f
3382	Manisa	TUR	207148	\N	f
3383	Batman	TUR	203793	\N	f
3384	Balikesir	TUR	196382	\N	f
3385	Sakarya (Adapazari)	TUR	190641	\N	f
3386	Iskenderun	TUR	153022	\N	f
3387	Osmaniye	TUR	146003	\N	f
3388	Çorum	TUR	145495	\N	f
3389	Kütahya	TUR	144761	\N	f
3390	Hatay (Antakya)	TUR	143982	\N	f
3391	Kirikkale	TUR	142044	\N	f
3392	Adiyaman	TUR	141529	\N	f
3393	Trabzon	TUR	138234	\N	f
3394	Ordu	TUR	133642	\N	f
3395	Aydin	TUR	128651	\N	f
3396	Usak	TUR	128162	\N	f
3397	Edirne	TUR	123383	\N	f
3398	Çorlu	TUR	123300	\N	f
3399	Isparta	TUR	121911	\N	f
3400	Karabük	TUR	118285	\N	f
3401	Kilis	TUR	118245	\N	f
3402	Alanya	TUR	117300	\N	f
3403	Kiziltepe	TUR	112000	\N	f
3404	Zonguldak	TUR	111542	\N	f
3405	Siirt	TUR	107100	\N	f
3406	Viransehir	TUR	106400	\N	f
3407	Tekirdag	TUR	106077	\N	f
3408	Karaman	TUR	104200	\N	f
3409	Afyon	TUR	103984	\N	f
3410	Aksaray	TUR	102681	\N	f
3411	Ceyhan	TUR	102412	\N	f
3412	Erzincan	TUR	102304	\N	f
3413	Bismil	TUR	101400	\N	f
3414	Nazilli	TUR	99900	\N	f
3415	Tokat	TUR	99500	\N	f
3416	Kars	TUR	93000	\N	f
3417	Inegöl	TUR	90500	\N	f
3418	Bandirma	TUR	90200	\N	f
3420	Chärjew	TKM	189200	\N	f
3421	Dashhowuz	TKM	141800	\N	f
3422	Mary	TKM	101000	\N	f
3427	Harkova [Harkiv]	UKR	1500000	\N	f
3428	Dnipropetrovsk	UKR	1103000	\N	f
3429	Donetsk	UKR	1050000	\N	f
3430	Odesa	UKR	1011000	\N	f
3431	Zaporizzja	UKR	848000	\N	f
3432	Lviv	UKR	788000	\N	f
3433	Kryvyi Rig	UKR	703000	\N	f
3434	Mykolajiv	UKR	508000	\N	f
3435	Mariupol	UKR	490000	\N	f
3436	Lugansk	UKR	469000	\N	f
3437	Vinnytsja	UKR	391000	\N	f
3438	Makijivka	UKR	384000	\N	f
3439	Herson	UKR	353000	\N	f
3440	Sevastopol	UKR	348000	\N	f
3441	Simferopol	UKR	339000	\N	f
3442	Pultava [Poltava]	UKR	313000	\N	f
3443	Tšernigiv	UKR	313000	\N	f
3444	Tšerkasy	UKR	309000	\N	f
3445	Gorlivka	UKR	299000	\N	f
3446	Zytomyr	UKR	297000	\N	f
3447	Sumy	UKR	294000	\N	f
3448	Dniprodzerzynsk	UKR	270000	\N	f
3449	Kirovograd	UKR	265000	\N	f
3450	Hmelnytskyi	UKR	262000	\N	f
3451	Tšernivtsi	UKR	259000	\N	f
3452	Rivne	UKR	245000	\N	f
3453	Krementšuk	UKR	239000	\N	f
3454	Ivano-Frankivsk	UKR	237000	\N	f
3455	Ternopil	UKR	236000	\N	f
3456	Lutsk	UKR	217000	\N	f
3457	Bila Tserkva	UKR	215000	\N	f
3458	Kramatorsk	UKR	186000	\N	f
3459	Melitopol	UKR	169000	\N	f
3460	Kertš	UKR	162000	\N	f
3461	Nikopol	UKR	149000	\N	f
3462	Berdjansk	UKR	130000	\N	f
3463	Pavlograd	UKR	127000	\N	f
3464	Sjeverodonetsk	UKR	127000	\N	f
3465	Slovjansk	UKR	127000	\N	f
3466	Uzgorod	UKR	127000	\N	f
3467	Altševsk	UKR	119000	\N	f
3468	Lysytšansk	UKR	116000	\N	f
3469	Jevpatorija	UKR	112000	\N	f
3470	Kamjanets-Podilskyi	UKR	109000	\N	f
3471	Jenakijeve	UKR	105000	\N	f
3472	Krasnyi Lutš	UKR	101000	\N	f
3473	Stahanov	UKR	101000	\N	f
3474	Oleksandrija	UKR	99000	\N	f
3475	Konotop	UKR	96000	\N	f
3476	Kostjantynivka	UKR	95000	\N	f
3477	Berdytšiv	UKR	90000	\N	f
3478	Izmajil	UKR	90000	\N	f
3479	Šostka	UKR	90000	\N	f
3336	Port-of-Spain	TTO	43396	\N	t
3480	Uman	UKR	90000	\N	f
3481	Brovary	UKR	89000	\N	f
3482	Mukatševe	UKR	89000	\N	f
3484	Debrecen	HUN	203648	\N	f
3485	Miskolc	HUN	172357	\N	f
3486	Szeged	HUN	158158	\N	f
3487	Pécs	HUN	157332	\N	f
3488	Györ	HUN	127119	\N	f
3489	Nyiregyháza	HUN	112419	\N	f
3490	Kecskemét	HUN	105606	\N	f
3491	Székesfehérvár	HUN	105119	\N	f
3494	Auckland	NZL	381800	\N	f
3495	Christchurch	NZL	324200	\N	f
3496	Manukau	NZL	281800	\N	f
3497	North Shore	NZL	187700	\N	f
3498	Waitakere	NZL	170600	\N	f
3500	Dunedin	NZL	119600	\N	f
3501	Hamilton	NZL	117100	\N	f
3502	Lower Hutt	NZL	98100	\N	f
3504	Namangan	UZB	370500	\N	f
3505	Samarkand	UZB	361800	\N	f
3506	Andijon	UZB	318600	\N	f
3507	Buhoro	UZB	237100	\N	f
3508	Karsi	UZB	194100	\N	f
3509	Nukus	UZB	194100	\N	f
3510	Kükon	UZB	190100	\N	f
3511	Fargona	UZB	180500	\N	f
3512	Circik	UZB	146400	\N	f
3513	Margilon	UZB	140800	\N	f
3514	Ürgenc	UZB	138900	\N	f
3515	Angren	UZB	128000	\N	f
3516	Cizah	UZB	124800	\N	f
3517	Navoi	UZB	116300	\N	f
3518	Olmalik	UZB	114900	\N	f
3519	Termiz	UZB	109500	\N	f
3521	Gomel	BLR	475000	\N	f
3522	Mogiljov	BLR	356000	\N	f
3523	Vitebsk	BLR	340000	\N	f
3524	Grodno	BLR	302000	\N	f
3525	Brest	BLR	286000	\N	f
3526	Bobruisk	BLR	221000	\N	f
3527	Baranovitši	BLR	167000	\N	f
3528	Borisov	BLR	151000	\N	f
3529	Pinsk	BLR	130000	\N	f
3530	Orša	BLR	124000	\N	f
3531	Mozyr	BLR	110000	\N	f
3532	Novopolotsk	BLR	106000	\N	f
3533	Lida	BLR	101000	\N	f
3534	Soligorsk	BLR	101000	\N	f
3535	Molodetšno	BLR	97000	\N	f
3540	Maracaíbo	VEN	1304776	\N	f
3541	Barquisimeto	VEN	877239	\N	f
3542	Valencia	VEN	794246	\N	f
3543	Ciudad Guayana	VEN	663713	\N	f
3544	Petare	VEN	488868	\N	f
3545	Maracay	VEN	444443	\N	f
3546	Barcelona	VEN	322267	\N	f
3547	Maturín	VEN	319726	\N	f
3548	San Cristóbal	VEN	319373	\N	f
3549	Ciudad Bolívar	VEN	301107	\N	f
3550	Cumaná	VEN	293105	\N	f
3551	Mérida	VEN	224887	\N	f
3552	Cabimas	VEN	221329	\N	f
3553	Barinas	VEN	217831	\N	f
3554	Turmero	VEN	217499	\N	f
3555	Baruta	VEN	207290	\N	f
3556	Puerto Cabello	VEN	187722	\N	f
3557	Santa Ana de Coro	VEN	185766	\N	f
3558	Los Teques	VEN	178784	\N	f
3559	Punto Fijo	VEN	167215	\N	f
3560	Guarenas	VEN	165889	\N	f
3561	Acarigua	VEN	158954	\N	f
3562	Puerto La Cruz	VEN	155700	\N	f
3563	Ciudad Losada	VEN	134501	\N	f
3564	Guacara	VEN	131334	\N	f
3565	Valera	VEN	130281	\N	f
3566	Guanare	VEN	125621	\N	f
3567	Carúpano	VEN	119639	\N	f
3568	Catia La Mar	VEN	117012	\N	f
3569	El Tigre	VEN	116256	\N	f
3570	Guatire	VEN	109121	\N	f
3571	Calabozo	VEN	107146	\N	f
3572	Pozuelos	VEN	105690	\N	f
3573	Ciudad Ojeda	VEN	99354	\N	f
3574	Ocumare del Tuy	VEN	97168	\N	f
3575	Valle de la Pascua	VEN	95927	\N	f
3576	Araure	VEN	94269	\N	f
3577	San Fernando de Apure	VEN	93809	\N	f
3578	San Felipe	VEN	90940	\N	f
3579	El Limón	VEN	90000	\N	f
3581	St Petersburg	RUS	4694000	\N	f
3582	Novosibirsk	RUS	1398800	\N	f
3583	Nizni Novgorod	RUS	1357000	\N	f
3584	Jekaterinburg	RUS	1266300	\N	f
3585	Samara	RUS	1156100	\N	f
3586	Omsk	RUS	1148900	\N	f
3587	Kazan	RUS	1101000	\N	f
3588	Ufa	RUS	1091200	\N	f
3589	Tšeljabinsk	RUS	1083200	\N	f
3590	Rostov-na-Donu	RUS	1012700	\N	f
3591	Perm	RUS	1009700	\N	f
3592	Volgograd	RUS	993400	\N	f
3593	Voronez	RUS	907700	\N	f
3594	Krasnojarsk	RUS	875500	\N	f
3595	Saratov	RUS	874000	\N	f
3596	Toljatti	RUS	722900	\N	f
3597	Uljanovsk	RUS	667400	\N	f
3598	Izevsk	RUS	652800	\N	f
3599	Krasnodar	RUS	639000	\N	f
3600	Jaroslavl	RUS	616700	\N	f
3601	Habarovsk	RUS	609400	\N	f
3602	Vladivostok	RUS	606200	\N	f
3603	Irkutsk	RUS	593700	\N	f
3604	Barnaul	RUS	580100	\N	f
3605	Novokuznetsk	RUS	561600	\N	f
3606	Penza	RUS	532200	\N	f
3607	Rjazan	RUS	529900	\N	f
3608	Orenburg	RUS	523600	\N	f
3609	Lipetsk	RUS	521000	\N	f
3610	Nabereznyje Tšelny	RUS	514700	\N	f
3611	Tula	RUS	506100	\N	f
3612	Tjumen	RUS	503400	\N	f
3613	Kemerovo	RUS	492700	\N	f
3614	Astrahan	RUS	486100	\N	f
3615	Tomsk	RUS	482100	\N	f
3616	Kirov	RUS	466200	\N	f
3617	Ivanovo	RUS	459200	\N	f
3618	Tšeboksary	RUS	459200	\N	f
3619	Brjansk	RUS	457400	\N	f
3620	Tver	RUS	454900	\N	f
3621	Kursk	RUS	443500	\N	f
3622	Magnitogorsk	RUS	427900	\N	f
3623	Kaliningrad	RUS	424400	\N	f
3538	Città del Vaticano	VAT	455	\N	t
3624	Nizni Tagil	RUS	390900	\N	f
3625	Murmansk	RUS	376300	\N	f
3626	Ulan-Ude	RUS	370400	\N	f
3627	Kurgan	RUS	364700	\N	f
3628	Arkangeli	RUS	361800	\N	f
3629	Sotši	RUS	358600	\N	f
3630	Smolensk	RUS	353400	\N	f
3631	Orjol	RUS	344500	\N	f
3632	Stavropol	RUS	343300	\N	f
3633	Belgorod	RUS	342000	\N	f
3634	Kaluga	RUS	339300	\N	f
3635	Vladimir	RUS	337100	\N	f
3636	Mahatškala	RUS	332800	\N	f
3637	Tšerepovets	RUS	324400	\N	f
3638	Saransk	RUS	314800	\N	f
3639	Tambov	RUS	312000	\N	f
3640	Vladikavkaz	RUS	310100	\N	f
3641	Tšita	RUS	309900	\N	f
3642	Vologda	RUS	302500	\N	f
3643	Veliki Novgorod	RUS	299500	\N	f
3644	Komsomolsk-na-Amure	RUS	291600	\N	f
3645	Kostroma	RUS	288100	\N	f
3646	Volzski	RUS	286900	\N	f
3647	Taganrog	RUS	284400	\N	f
3648	Petroskoi	RUS	282100	\N	f
3649	Bratsk	RUS	277600	\N	f
3650	Dzerzinsk	RUS	277100	\N	f
3651	Surgut	RUS	274900	\N	f
3652	Orsk	RUS	273900	\N	f
3653	Sterlitamak	RUS	265200	\N	f
3654	Angarsk	RUS	264700	\N	f
3655	Joškar-Ola	RUS	249200	\N	f
3656	Rybinsk	RUS	239600	\N	f
3657	Prokopjevsk	RUS	237300	\N	f
3658	Niznevartovsk	RUS	233900	\N	f
3659	Naltšik	RUS	233400	\N	f
3660	Syktyvkar	RUS	229700	\N	f
3661	Severodvinsk	RUS	229300	\N	f
3662	Bijsk	RUS	225000	\N	f
3663	Niznekamsk	RUS	223400	\N	f
3664	Blagoveštšensk	RUS	222000	\N	f
3665	Šahty	RUS	221800	\N	f
3666	Staryi Oskol	RUS	213800	\N	f
3667	Zelenograd	RUS	207100	\N	f
3668	Balakovo	RUS	206000	\N	f
3669	Novorossijsk	RUS	203300	\N	f
3670	Pihkova	RUS	201500	\N	f
3671	Zlatoust	RUS	196900	\N	f
3672	Jakutsk	RUS	195400	\N	f
3673	Podolsk	RUS	194300	\N	f
3674	Petropavlovsk-Kamtšatski	RUS	194100	\N	f
3675	Kamensk-Uralski	RUS	190600	\N	f
3676	Engels	RUS	189000	\N	f
3677	Syzran	RUS	186900	\N	f
3678	Grozny	RUS	186000	\N	f
3679	Novotšerkassk	RUS	184400	\N	f
3680	Berezniki	RUS	181900	\N	f
3681	Juzno-Sahalinsk	RUS	179200	\N	f
3682	Volgodonsk	RUS	178200	\N	f
3683	Abakan	RUS	169200	\N	f
3684	Maikop	RUS	167300	\N	f
3685	Miass	RUS	166200	\N	f
3686	Armavir	RUS	164900	\N	f
3687	Ljubertsy	RUS	163900	\N	f
3688	Rubtsovsk	RUS	162600	\N	f
3689	Kovrov	RUS	159900	\N	f
3690	Nahodka	RUS	157700	\N	f
3691	Ussurijsk	RUS	157300	\N	f
3692	Salavat	RUS	156800	\N	f
3693	Mytištši	RUS	155700	\N	f
3694	Kolomna	RUS	150700	\N	f
3695	Elektrostal	RUS	147000	\N	f
3696	Murom	RUS	142400	\N	f
3697	Kolpino	RUS	141200	\N	f
3698	Norilsk	RUS	140800	\N	f
3699	Almetjevsk	RUS	140700	\N	f
3700	Novomoskovsk	RUS	138100	\N	f
3701	Dimitrovgrad	RUS	137000	\N	f
3702	Pervouralsk	RUS	136100	\N	f
3703	Himki	RUS	133700	\N	f
3704	Balašiha	RUS	132900	\N	f
3705	Nevinnomyssk	RUS	132600	\N	f
3706	Pjatigorsk	RUS	132500	\N	f
3707	Korolev	RUS	132400	\N	f
3708	Serpuhov	RUS	132000	\N	f
3709	Odintsovo	RUS	127400	\N	f
3710	Orehovo-Zujevo	RUS	124900	\N	f
3711	Kamyšin	RUS	124600	\N	f
3712	Novotšeboksarsk	RUS	123400	\N	f
3713	Tšerkessk	RUS	121700	\N	f
3714	Atšinsk	RUS	121600	\N	f
3715	Magadan	RUS	121000	\N	f
3716	Mitšurinsk	RUS	120700	\N	f
3717	Kislovodsk	RUS	120400	\N	f
3718	Jelets	RUS	119400	\N	f
3719	Seversk	RUS	118600	\N	f
3720	Noginsk	RUS	117200	\N	f
3721	Velikije Luki	RUS	116300	\N	f
3722	Novokuibyševsk	RUS	116200	\N	f
3723	Neftekamsk	RUS	115700	\N	f
3724	Leninsk-Kuznetski	RUS	113800	\N	f
3725	Oktjabrski	RUS	111500	\N	f
3726	Sergijev Posad	RUS	111100	\N	f
3727	Arzamas	RUS	110700	\N	f
3728	Kiseljovsk	RUS	110000	\N	f
3729	Novotroitsk	RUS	109600	\N	f
3730	Obninsk	RUS	108300	\N	f
3731	Kansk	RUS	107400	\N	f
3732	Glazov	RUS	106300	\N	f
3733	Solikamsk	RUS	106000	\N	f
3734	Sarapul	RUS	105700	\N	f
3735	Ust-Ilimsk	RUS	105200	\N	f
3736	Štšolkovo	RUS	104900	\N	f
3737	Mezduretšensk	RUS	104400	\N	f
3738	Usolje-Sibirskoje	RUS	103500	\N	f
3739	Elista	RUS	103300	\N	f
3740	Novošahtinsk	RUS	101900	\N	f
3741	Votkinsk	RUS	101700	\N	f
3742	Kyzyl	RUS	101100	\N	f
3743	Serov	RUS	100400	\N	f
3744	Zelenodolsk	RUS	100200	\N	f
3745	Zeleznodoroznyi	RUS	100100	\N	f
3746	Kinešma	RUS	100000	\N	f
3747	Kuznetsk	RUS	98200	\N	f
3748	Uhta	RUS	98000	\N	f
3749	Jessentuki	RUS	97900	\N	f
3750	Tobolsk	RUS	97600	\N	f
3751	Neftejugansk	RUS	97400	\N	f
3752	Bataisk	RUS	97300	\N	f
3753	Nojabrsk	RUS	97300	\N	f
3754	Balašov	RUS	97100	\N	f
3755	Zeleznogorsk	RUS	96900	\N	f
3756	Zukovski	RUS	96500	\N	f
3757	Anzero-Sudzensk	RUS	96100	\N	f
3758	Bugulma	RUS	94100	\N	f
3759	Zeleznogorsk	RUS	94000	\N	f
3760	Novouralsk	RUS	93300	\N	f
3761	Puškin	RUS	92900	\N	f
3762	Vorkuta	RUS	92600	\N	f
3763	Derbent	RUS	92300	\N	f
3764	Kirovo-Tšepetsk	RUS	91600	\N	f
3765	Krasnogorsk	RUS	91000	\N	f
3766	Klin	RUS	90000	\N	f
3767	Tšaikovski	RUS	90000	\N	f
3768	Novyi Urengoi	RUS	89800	\N	f
3769	Ho Chi Minh City	VNM	3980000	\N	f
3771	Haiphong	VNM	783133	\N	f
3772	Da Nang	VNM	382674	\N	f
3773	Biên Hoa	VNM	282095	\N	f
3774	Nha Trang	VNM	221331	\N	f
3775	Hue	VNM	219149	\N	f
3776	Can Tho	VNM	215587	\N	f
3777	Cam Pha	VNM	209086	\N	f
3778	Nam Dinh	VNM	171699	\N	f
3779	Quy Nhon	VNM	163385	\N	f
3780	Vung Tau	VNM	145145	\N	f
3781	Rach Gia	VNM	141132	\N	f
3782	Long Xuyen	VNM	132681	\N	f
3783	Thai Nguyen	VNM	127643	\N	f
3784	Hong Gai	VNM	127484	\N	f
3785	Phan Thiêt	VNM	114236	\N	f
3786	Cam Ranh	VNM	114041	\N	f
3787	Vinh	VNM	112455	\N	f
3788	My Tho	VNM	108404	\N	f
3789	Da Lat	VNM	106409	\N	f
3790	Buon Ma Thuot	VNM	97044	\N	f
3792	Tartu	EST	101246	\N	f
3793	New York	USA	8008278	\N	f
3794	Los Angeles	USA	3694820	\N	f
3795	Chicago	USA	2896016	\N	f
3796	Houston	USA	1953631	\N	f
3797	Philadelphia	USA	1517550	\N	f
3798	Phoenix	USA	1321045	\N	f
3799	San Diego	USA	1223400	\N	f
3800	Dallas	USA	1188580	\N	f
3801	San Antonio	USA	1144646	\N	f
3802	Detroit	USA	951270	\N	f
3803	San Jose	USA	894943	\N	f
3804	Indianapolis	USA	791926	\N	f
3805	San Francisco	USA	776733	\N	f
3806	Jacksonville	USA	735167	\N	f
3807	Columbus	USA	711470	\N	f
3808	Austin	USA	656562	\N	f
3809	Baltimore	USA	651154	\N	f
3810	Memphis	USA	650100	\N	f
3811	Milwaukee	USA	596974	\N	f
3812	Boston	USA	589141	\N	f
3814	Nashville-Davidson	USA	569891	\N	f
3815	El Paso	USA	563662	\N	f
3816	Seattle	USA	563374	\N	f
3817	Denver	USA	554636	\N	f
3818	Charlotte	USA	540828	\N	f
3819	Fort Worth	USA	534694	\N	f
3820	Portland	USA	529121	\N	f
3821	Oklahoma City	USA	506132	\N	f
3822	Tucson	USA	486699	\N	f
3823	New Orleans	USA	484674	\N	f
3824	Las Vegas	USA	478434	\N	f
3825	Cleveland	USA	478403	\N	f
3826	Long Beach	USA	461522	\N	f
3827	Albuquerque	USA	448607	\N	f
3828	Kansas City	USA	441545	\N	f
3829	Fresno	USA	427652	\N	f
3830	Virginia Beach	USA	425257	\N	f
3831	Atlanta	USA	416474	\N	f
3832	Sacramento	USA	407018	\N	f
3833	Oakland	USA	399484	\N	f
3834	Mesa	USA	396375	\N	f
3835	Tulsa	USA	393049	\N	f
3836	Omaha	USA	390007	\N	f
3837	Minneapolis	USA	382618	\N	f
3838	Honolulu	USA	371657	\N	f
3839	Miami	USA	362470	\N	f
3840	Colorado Springs	USA	360890	\N	f
3841	Saint Louis	USA	348189	\N	f
3842	Wichita	USA	344284	\N	f
3843	Santa Ana	USA	337977	\N	f
3844	Pittsburgh	USA	334563	\N	f
3845	Arlington	USA	332969	\N	f
3846	Cincinnati	USA	331285	\N	f
3847	Anaheim	USA	328014	\N	f
3848	Toledo	USA	313619	\N	f
3849	Tampa	USA	303447	\N	f
3850	Buffalo	USA	292648	\N	f
3851	Saint Paul	USA	287151	\N	f
3852	Corpus Christi	USA	277454	\N	f
3853	Aurora	USA	276393	\N	f
3854	Raleigh	USA	276093	\N	f
3855	Newark	USA	273546	\N	f
3856	Lexington-Fayette	USA	260512	\N	f
3857	Anchorage	USA	260283	\N	f
3858	Louisville	USA	256231	\N	f
3859	Riverside	USA	255166	\N	f
3860	Saint Petersburg	USA	248232	\N	f
3861	Bakersfield	USA	247057	\N	f
3862	Stockton	USA	243771	\N	f
3863	Birmingham	USA	242820	\N	f
3864	Jersey City	USA	240055	\N	f
3865	Norfolk	USA	234403	\N	f
3866	Baton Rouge	USA	227818	\N	f
3867	Hialeah	USA	226419	\N	f
3868	Lincoln	USA	225581	\N	f
3869	Greensboro	USA	223891	\N	f
3870	Plano	USA	222030	\N	f
3871	Rochester	USA	219773	\N	f
3872	Glendale	USA	218812	\N	f
3873	Akron	USA	217074	\N	f
3874	Garland	USA	215768	\N	f
3875	Madison	USA	208054	\N	f
3876	Fort Wayne	USA	205727	\N	f
3877	Fremont	USA	203413	\N	f
3878	Scottsdale	USA	202705	\N	f
3879	Montgomery	USA	201568	\N	f
3880	Shreveport	USA	200145	\N	f
3881	Augusta-Richmond County	USA	199775	\N	f
3882	Lubbock	USA	199564	\N	f
3883	Chesapeake	USA	199184	\N	f
3884	Mobile	USA	198915	\N	f
3885	Des Moines	USA	198682	\N	f
3886	Grand Rapids	USA	197800	\N	f
3887	Richmond	USA	197790	\N	f
3888	Yonkers	USA	196086	\N	f
3889	Spokane	USA	195629	\N	f
3890	Glendale	USA	194973	\N	f
3891	Tacoma	USA	193556	\N	f
3892	Irving	USA	191615	\N	f
3893	Huntington Beach	USA	189594	\N	f
3894	Modesto	USA	188856	\N	f
3895	Durham	USA	187035	\N	f
3896	Columbus	USA	186291	\N	f
3897	Orlando	USA	185951	\N	f
3898	Boise City	USA	185787	\N	f
3899	Winston-Salem	USA	185776	\N	f
3900	San Bernardino	USA	185401	\N	f
3901	Jackson	USA	184256	\N	f
3902	Little Rock	USA	183133	\N	f
3903	Salt Lake City	USA	181743	\N	f
3904	Reno	USA	180480	\N	f
3905	Newport News	USA	180150	\N	f
3906	Chandler	USA	176581	\N	f
3907	Laredo	USA	176576	\N	f
3770	Hanoi	VNM	1410000	\N	t
3908	Henderson	USA	175381	\N	f
3909	Arlington	USA	174838	\N	f
3910	Knoxville	USA	173890	\N	f
3911	Amarillo	USA	173627	\N	f
3912	Providence	USA	173618	\N	f
3913	Chula Vista	USA	173556	\N	f
3914	Worcester	USA	172648	\N	f
3915	Oxnard	USA	170358	\N	f
3916	Dayton	USA	166179	\N	f
3917	Garden Grove	USA	165196	\N	f
3918	Oceanside	USA	161029	\N	f
3919	Tempe	USA	158625	\N	f
3920	Huntsville	USA	158216	\N	f
3921	Ontario	USA	158007	\N	f
3922	Chattanooga	USA	155554	\N	f
3923	Fort Lauderdale	USA	152397	\N	f
3924	Springfield	USA	152082	\N	f
3925	Springfield	USA	151580	\N	f
3926	Santa Clarita	USA	151088	\N	f
3927	Salinas	USA	151060	\N	f
3928	Tallahassee	USA	150624	\N	f
3929	Rockford	USA	150115	\N	f
3930	Pomona	USA	149473	\N	f
3931	Metairie	USA	149428	\N	f
3932	Paterson	USA	149222	\N	f
3933	Overland Park	USA	149080	\N	f
3934	Santa Rosa	USA	147595	\N	f
3935	Syracuse	USA	147306	\N	f
3936	Kansas City	USA	146866	\N	f
3937	Hampton	USA	146437	\N	f
3938	Lakewood	USA	144126	\N	f
3939	Vancouver	USA	143560	\N	f
3940	Irvine	USA	143072	\N	f
3941	Aurora	USA	142990	\N	f
3942	Moreno Valley	USA	142381	\N	f
3943	Pasadena	USA	141674	\N	f
3944	Hayward	USA	140030	\N	f
3945	Brownsville	USA	139722	\N	f
3946	Bridgeport	USA	139529	\N	f
3947	Hollywood	USA	139357	\N	f
3948	Warren	USA	138247	\N	f
3949	Torrance	USA	137946	\N	f
3950	Eugene	USA	137893	\N	f
3951	Pembroke Pines	USA	137427	\N	f
3952	Salem	USA	136924	\N	f
3953	Pasadena	USA	133936	\N	f
3954	Escondido	USA	133559	\N	f
3955	Sunnyvale	USA	131760	\N	f
3956	Savannah	USA	131510	\N	f
3957	Fontana	USA	128929	\N	f
3958	Orange	USA	128821	\N	f
3959	Naperville	USA	128358	\N	f
3960	Alexandria	USA	128283	\N	f
3961	Rancho Cucamonga	USA	127743	\N	f
3962	Grand Prairie	USA	127427	\N	f
3963	East Los Angeles	USA	126379	\N	f
3964	Fullerton	USA	126003	\N	f
3965	Corona	USA	124966	\N	f
3966	Flint	USA	124943	\N	f
3967	Paradise	USA	124682	\N	f
3968	Mesquite	USA	124523	\N	f
3969	Sterling Heights	USA	124471	\N	f
3970	Sioux Falls	USA	123975	\N	f
3971	New Haven	USA	123626	\N	f
3972	Topeka	USA	122377	\N	f
3973	Concord	USA	121780	\N	f
3974	Evansville	USA	121582	\N	f
3975	Hartford	USA	121578	\N	f
3976	Fayetteville	USA	121015	\N	f
3977	Cedar Rapids	USA	120758	\N	f
3978	Elizabeth	USA	120568	\N	f
3979	Lansing	USA	119128	\N	f
3980	Lancaster	USA	118718	\N	f
3981	Fort Collins	USA	118652	\N	f
3982	Coral Springs	USA	117549	\N	f
3983	Stamford	USA	117083	\N	f
3984	Thousand Oaks	USA	117005	\N	f
3985	Vallejo	USA	116760	\N	f
3986	Palmdale	USA	116670	\N	f
3987	Columbia	USA	116278	\N	f
3988	El Monte	USA	115965	\N	f
3989	Abilene	USA	115930	\N	f
3990	North Las Vegas	USA	115488	\N	f
3991	Ann Arbor	USA	114024	\N	f
3992	Beaumont	USA	113866	\N	f
3993	Waco	USA	113726	\N	f
3994	Macon	USA	113336	\N	f
3995	Independence	USA	113288	\N	f
3996	Peoria	USA	112936	\N	f
3997	Inglewood	USA	112580	\N	f
3998	Springfield	USA	111454	\N	f
3999	Simi Valley	USA	111351	\N	f
4000	Lafayette	USA	110257	\N	f
4001	Gilbert	USA	109697	\N	f
4002	Carrollton	USA	109576	\N	f
4003	Bellevue	USA	109569	\N	f
4004	West Valley City	USA	108896	\N	f
4005	Clarksville	USA	108787	\N	f
4006	Costa Mesa	USA	108724	\N	f
4007	Peoria	USA	108364	\N	f
4008	South Bend	USA	107789	\N	f
4009	Downey	USA	107323	\N	f
4010	Waterbury	USA	107271	\N	f
4011	Manchester	USA	107006	\N	f
4012	Allentown	USA	106632	\N	f
4013	McAllen	USA	106414	\N	f
4014	Joliet	USA	106221	\N	f
4015	Lowell	USA	105167	\N	f
4016	Provo	USA	105166	\N	f
4017	West Covina	USA	105080	\N	f
4018	Wichita Falls	USA	104197	\N	f
4019	Erie	USA	103717	\N	f
4020	Daly City	USA	103621	\N	f
4021	Citrus Heights	USA	103455	\N	f
4022	Norwalk	USA	103298	\N	f
4023	Gary	USA	102746	\N	f
4024	Berkeley	USA	102743	\N	f
4025	Santa Clara	USA	102361	\N	f
4026	Green Bay	USA	102313	\N	f
4027	Cape Coral	USA	102286	\N	f
4028	Arvada	USA	102153	\N	f
4029	Pueblo	USA	102121	\N	f
4030	Sandy	USA	101853	\N	f
4031	Athens-Clarke County	USA	101489	\N	f
4032	Cambridge	USA	101355	\N	f
4033	Westminster	USA	100940	\N	f
4034	San Buenaventura	USA	100916	\N	f
4035	Portsmouth	USA	100565	\N	f
4036	Livonia	USA	100545	\N	f
4037	Burbank	USA	100316	\N	f
4038	Clearwater	USA	99936	\N	f
4039	Midland	USA	98293	\N	f
4040	Davenport	USA	98256	\N	f
4041	Mission Viejo	USA	98049	\N	f
4042	Miami Beach	USA	97855	\N	f
4043	Sunrise Manor	USA	95362	\N	f
4044	New Bedford	USA	94780	\N	f
4045	El Cajon	USA	94578	\N	f
4046	Norman	USA	94193	\N	f
4047	Richmond	USA	94100	\N	f
4048	Albany	USA	93994	\N	f
4049	Brockton	USA	93653	\N	f
4050	Roanoke	USA	93357	\N	f
4051	Billings	USA	92988	\N	f
4052	Compton	USA	92864	\N	f
4053	Gainesville	USA	92291	\N	f
4054	Fairfield	USA	92256	\N	f
4055	Arden-Arcade	USA	92040	\N	f
4056	San Mateo	USA	91799	\N	f
4057	Visalia	USA	91762	\N	f
4058	Boulder	USA	91238	\N	f
4059	Cary	USA	91213	\N	f
4060	Santa Monica	USA	91084	\N	f
4061	Fall River	USA	90555	\N	f
4062	Kenosha	USA	89447	\N	f
4063	Elgin	USA	89408	\N	f
4064	Odessa	USA	89293	\N	f
4065	Carson	USA	89089	\N	f
4066	Charleston	USA	89063	\N	f
4069	Bulawayo	ZWE	621742	\N	f
4070	Chitungwiza	ZWE	274912	\N	f
4071	Mount Darwin	ZWE	164362	\N	f
4072	Mutare	ZWE	131367	\N	f
4073	Gweru	ZWE	128037	\N	f
4074	Gaza	PSE	353632	\N	f
4075	Khan Yunis	PSE	123175	\N	f
4076	Hebron	PSE	119401	\N	f
4077	Jabaliya	PSE	113901	\N	f
4078	Nablus	PSE	100231	\N	f
4079	Rafah	PSE	92020	\N	f
4080	Berlin	USA	\N	Connecticut	f
4081	Berlin	USA	\N	Georgia	f
4082	Berlin	USA	\N	Illinois	f
4083	Berlin	USA	\N	Indiana, extinct town	f
4084	Berlin	USA	\N	Kansas	f
4085	Berlin	USA	\N	Kentucky	f
4086	Berlin	USA	\N	Maryland	f
4087	Berlin	USA	\N	Massachusetts	f
4088	Berlin	USA	\N	Michigan (disambiguation)	f
4089	Berlin	USA	\N	Nevada, a ghost town	f
4090	Berlin	USA	\N	New Hampshire	f
4091	Berlin	USA	\N	New Jersey	f
4092	Berlin	USA	\N	New York	f
4093	Berlin	USA	\N	North Dakota	f
4094	Berlin	USA	\N	Holmes County, Ohio	f
4095	Berlin	USA	\N	Williams County, Ohio	f
4096	Berlin	USA	\N	Pennsylvania	f
4097	Berlin	USA	\N	Tennessee, unincorporated town	f
4098	Berlin	USA	\N	Texas, an unincorporated community	f
4099	Berlin	USA	\N	Vermont	f
4100	Berlin	USA	\N	West Virginia	f
4101	Berlin	USA	\N	Wisconsin, a city	f
4102	Berlin	USA	\N	Green Lake County, Wisconsin, a town	f
4103	Berlin	USA	\N	Marathon County, Wisconsin, a town	f
4104	Berlin	ZAF	\N	Eastern Cape	f
4105	Berlin	RUS	\N	\N	f
4106	Berlín	SLV	\N	\N	f
4107	Munster	DEU	15091	\N	f
4108	Hanover	USA	59	Connecticut	f
1793	Novi Sad	SRB	179626	\N	f
1794	Niš	SRB	175391	\N	f
1796	Kragujevac	SRB	147305	\N	f
1798	Subotica	SRB	100386	\N	f
3019	Iasi	ROU	348070	\N	f
3020	Constanta	ROU	342264	\N	f
3021	Cluj-Napoca	ROU	332498	\N	f
3022	Galati	ROU	330276	\N	f
3023	Timisoara	ROU	324304	\N	f
3024	Brasov	ROU	314225	\N	f
3025	Craiova	ROU	313530	\N	f
3026	Ploiesti	ROU	251348	\N	f
3027	Braila	ROU	233756	\N	f
3028	Oradea	ROU	222239	\N	f
3029	Bacau	ROU	209235	\N	f
3030	Pitesti	ROU	187170	\N	f
3031	Arad	ROU	184408	\N	f
3032	Sibiu	ROU	169611	\N	f
3033	Târgu Mures	ROU	165153	\N	f
3034	Baia Mare	ROU	149665	\N	f
3035	Buzau	ROU	148372	\N	f
3036	Satu Mare	ROU	130059	\N	f
3037	Botosani	ROU	128730	\N	f
3038	Piatra Neamt	ROU	125070	\N	f
3039	Râmnicu Vâlcea	ROU	119741	\N	f
3040	Suceava	ROU	118549	\N	f
3041	Drobeta-Turnu Severin	ROU	117865	\N	f
3042	Târgoviste	ROU	98980	\N	f
3043	Focsani	ROU	98979	\N	f
3044	Târgu Jiu	ROU	98524	\N	f
3045	Tulcea	ROU	96278	\N	f
3046	Resita	ROU	93976	\N	f
4067	Charlotte Amalie	VIR	13000	\N	t
4068	Harare	ZWE	1410000	\N	t
3068	Berlin	DEU	3386667	\N	t
1522	Dili	TLS	47900	\N	t
33	Willemstad	CUW	2345	\N	t
4109	Putrajaya	MYS	88300	\N	t
4110	Pago Pago	ASM	3656	\N	t
4111	Hong Kong	HKG	7234800	\N	t
4112	Tarawa	KIR	56284	\N	t
4113	Naypyidaw	MMR	924608	\N	t
4114	Ngerulmud	PLW	391	\N	t
4115	Saipan	MNP	48220	\N	t
4116	Lobamba	SWZ	11000	\N	t
2452	Luxembourg	LUX	80700	\N	t
3018	București	ROU	2016131	\N	t
1780	Sana'a	YEM	503600	\N	t
1891	Beijing	CHN	7472000	\N	t
916	St. George's	GRD	4621	\N	t
63	St. John's	ATG	24000	\N	t
5	Amsterdam	NLD	731200	\N	t
34	Tirana	ALB	270000	\N	t
35	Alger	DZA	2168000	\N	t
55	Andorra la Vella	AND	21189	\N	t
56	Luanda	AGO	2022000	\N	t
62	The Valley	AIA	595	\N	t
65	Abu Dhabi	ARE	398695	\N	t
69	Buenos Aires	ARG	2982146	\N	t
126	Yerevan	ARM	1248700	\N	t
129	Oranjestad	ABW	29034	\N	t
135	Canberra	AUS	322723	\N	t
149	al-Manama	BHR	148000	\N	t
150	Dhaka	BGD	3612850	\N	t
174	Bridgetown	BRB	6070	\N	t
185	Belmopan	BLZ	7105	\N	t
187	Porto-Novo	BEN	194000	\N	t
191	Hamilton	BMU	1200	\N	t
192	Thimphu	BTN	22000	\N	t
194	La Paz	BOL	758141	\N	t
198	Sucre	BOL	178426	\N	t
201	Sarajevo	BIH	360000	\N	t
204	Gaborone	BWA	213017	\N	t
211	Brasília	BRA	1969868	\N	t
456	London	GBR	7285000	\N	t
537	Road Town	VGB	8000	\N	t
538	Bandar Seri Begawan	BRN	21484	\N	t
539	Sofija	BGR	1122302	\N	t
549	Ouagadougou	BFA	824000	\N	t
552	Bujumbura	BDI	300000	\N	t
553	George Town	CYM	19600	\N	t
584	San José	CRI	339131	\N	t
585	Djibouti	DJI	383000	\N	t
586	Roseau	DMA	16243	\N	t
587	Santo Domingo de Guzmán	DOM	1609966	\N	t
594	Quito	ECU	1573458	\N	t
608	Cairo	EGY	6789479	\N	t
645	San Salvador	SLV	415346	\N	t
652	Asmara	ERI	431000	\N	t
653	Madrid	ESP	2879052	\N	t
712	Cape Town	ZAF	2352121	\N	t
716	Pretoria	ZAF	658630	\N	t
727	Bloemfontein	ZAF	334341	\N	t
756	Addis Abeba	ETH	2495000	\N	t
763	Stanley	FLK	1636	\N	t
764	Suva	FJI	77366	\N	t
766	Manila	PHL	1581082	\N	t
901	Tórshavn	FRO	14542	\N	t
902	Libreville	GAB	419000	\N	t
905	Tbilisi	GEO	1235200	\N	t
906	Kutaisi	GEO	240900	\N	t
910	Accra	GHA	1070000	\N	t
915	Gibraltar	GIB	27025	\N	t
917	Nuuk	GRL	13445	\N	t
919	Basse-Terre	GLP	12433	\N	t
922	Ciudad de Guatemala	GTM	823301	\N	t
926	Conakry	GIN	1090610	\N	t
927	Bissau	GNB	241000	\N	t
928	Georgetown	GUY	254000	\N	t
929	Port-au-Prince	HTI	884472	\N	t
933	Tegucigalpa	HND	813900	\N	t
939	Jakarta	IDN	9604900	\N	t
921	Hagåtña	GUM	1139	\N	t
1109	New Delhi	IND	301297	\N	t
1365	Baghdad	IRQ	4336000	\N	t
1380	Teheran	IRN	6758845	\N	t
1447	Dublin	IRL	481854	\N	t
1449	Reykjavík	ISL	109184	\N	t
1450	Jerusalem	ISR	633700	\N	t
1464	Roma	ITA	2643581	\N	t
1523	Wien	AUT	1608144	\N	t
1530	Kingston	JAM	103962	\N	t
1532	Tokyo	JPN	7980230	\N	t
1786	Amman	JOR	1000000	\N	t
1791	Flying Fish Cove	CXR	700	\N	t
1800	Phnom Penh	KHM	570155	\N	t
1804	Yaoundé	CMR	1372800	\N	t
1797	Podgorica	MNE	135000	\N	t
1792	Beograd	SRB	1204000	\N	t
1822	Ottawa	CAN	335277	\N	t
1859	Praia	CPV	94800	\N	t
1881	Nairobi	KEN	2290000	\N	t
1889	Bangui	CAF	524000	\N	t
2253	Bishkek	KGZ	589400	\N	t
2257	Santafé de Bogotá	COL	6260862	\N	t
2295	Moroni	COM	36000	\N	t
2296	Brazzaville	COG	950000	\N	t
2298	Kinshasa	COD	5064000	\N	t
2317	West Island	CCK	167	\N	t
2318	Pyongyang	PRK	2484000	\N	t
2331	Seoul	KOR	9981619	\N	t
2401	Athenai	GRC	772072	\N	t
2409	Zagreb	HRV	706770	\N	t
2413	La Habana	CUB	2256000	\N	t
2429	Kuwait	KWT	28859	\N	t
2430	Nicosia	CYP	195000	\N	t
2432	Vientiane	LAO	531800	\N	t
2434	Riga	LVA	764328	\N	t
2437	Maseru	LSO	297000	\N	t
2438	Beirut	LBN	1100000	\N	t
2440	Monrovia	LBR	850000	\N	t
2441	Tripoli	LBY	1682000	\N	t
2446	Vaduz	LIE	5043	\N	t
2447	Vilnius	LTU	577969	\N	t
2462	Lilongwe	MWI	435964	\N	t
2464	Kuala Lumpur	MYS	1297526	\N	t
2482	Bamako	MLI	809552	\N	t
2484	Valletta	MLT	7073	\N	t
2486	Rabat	MAR	623457	\N	t
2508	Fort-de-France	MTQ	94050	\N	t
2509	Nouakchott	MRT	667300	\N	t
2511	Port-Louis	MUS	138200	\N	t
2515	Ciudad de México	MEX	8591309	\N	t
2463	Malé	MDV	71000	\N	t
2507	Majuro	MHL	28000	\N	t
2514	Mamoudzou	MYT	12000	\N	t
2697	Plymouth	MSR	2000	\N	t
2698	Maputo	MOZ	1018938	\N	t
2690	Chișinău	MDA	719900	\N	t
2695	Monaco	MCO	1234	\N	t
2696	Ulaanbaatar	MNG	773700	\N	t
2726	Windhoek	NAM	169000	\N	t
2729	Kathmandu	NPL	591835	\N	t
2734	Managua	NIC	959000	\N	t
2738	Niamey	NER	420000	\N	t
2754	Abuja	NGA	350100	\N	t
2805	Alofi	NIU	682	\N	t
2806	Kingston	NFK	800	\N	t
2807	Oslo	NOR	508726	\N	t
2814	Yamoussoukro	CIV	130000	\N	t
2821	Masqat	OMN	51969	\N	t
2831	Islamabad	PAK	524500	\N	t
2882	Ciudad de Panamá	PAN	471373	\N	t
2884	Port Moresby	PNG	247000	\N	t
2885	Asunción	PRY	557776	\N	t
2890	Lima	PER	6464693	\N	t
2912	Adamstown	PCN	42	\N	t
2914	Lisboa	PRT	563210	\N	t
2919	San Juan	PRI	434374	\N	t
2928	Warszawa	POL	1615369	\N	t
2972	Malabo	GNQ	40000	\N	t
2973	Doha	QAT	355000	\N	t
2974	Paris	FRA	2125246	\N	t
3014	Cayenne	GUF	50699	\N	t
3016	Papeete	PYF	25553	\N	t
3017	Saint-Denis	REU	131480	\N	t
3047	Kigali	RWA	286000	\N	t
3048	Stockholm	SWE	750348	\N	t
3063	Jamestown	SHN	1500	\N	t
3064	Basseterre	KNA	11600	\N	t
3065	Castries	LCA	2301	\N	t
3066	Kingstown	VCT	17100	\N	t
3067	Saint-Pierre	SPM	5808	\N	t
3161	Honiara	SLB	50100	\N	t
3162	Lusaka	ZMB	1317000	\N	t
3169	Apia	WSM	35900	\N	t
3171	San Marino	SMR	2294	\N	t
3172	São Tomé	STP	49541	\N	t
3173	Riyadh	SAU	3324000	\N	t
3207	Freetown	SLE	850000	\N	t
3208	Singapore	SGP	4017733	\N	t
3209	Bratislava	SVK	448292	\N	t
3212	Ljubljana	SVN	270986	\N	t
3214	Mogadishu	SOM	997000	\N	t
3222	Sri Jayawardenepura Kotte	LKA	118000	\N	t
3225	Khartum	SDN	947483	\N	t
3243	Paramaribo	SUR	112000	\N	t
3244	Mbabane	SWZ	61000	\N	t
3248	Bern	CHE	122700	\N	t
3250	Damascus	SYR	1347000	\N	t
3261	Dushanbe	TJK	524000	\N	t
3263	Taipei	TWN	2641312	\N	t
3306	Dodoma	TZA	189000	\N	t
3315	København	DNK	495699	\N	t
3320	Bangkok	THA	6320174	\N	t
3332	Lomé	TGO	375000	\N	t
3339	Praha	CZE	1181126	\N	t
3349	Tunis	TUN	690600	\N	t
3358	Ankara	TUR	3038159	\N	t
3419	Ashgabat	TKM	540600	\N	t
3423	Cockburn Town	TCA	4800	\N	t
3424	Funafuti	TUV	4600	\N	t
3425	Kampala	UGA	890800	\N	t
3426	Kyiv	UKR	2624000	\N	t
3483	Budapest	HUN	1811552	\N	t
3492	Montevideo	URY	1236000	\N	t
3493	Nouméa	NCL	76293	\N	t
3499	Wellington	NZL	166700	\N	t
3503	Toskent	UZB	2117500	\N	t
3520	Minsk	BLR	1674000	\N	t
3536	Mata-Utu	WLF	1137	\N	t
3537	Port-Vila	VUT	33700	\N	t
3539	Caracas	VEN	1975294	\N	t
3580	Moscow	RUS	8389200	\N	t
3791	Tallinn	EST	403981	\N	t
3813	Washington	USA	572059	\N	t
4117	Brades Estate	MSR	1000	\N	t
3236	Helsinki	FIN	555474	\N	t
3334	Nuku'alofa	TON	22400	\N	t
3337	N'Djamena	TCD	530965	\N	t
179	Bruxelles	BEL	133859	\N	t
4118	Marigot	MAF	5700	\N	t
4119	Philipsburg	SXM	1327	\N	t
4120	Gustavia	BLM	2300	\N	t
4121	St. Helier	JEY	33500	\N	t
4122	St. Peter Port	GGY	18207	\N	t
4127	Jerusalem	PSE	\N	\N	t
4128	Douglas	IMN	27938	\N	t
4129	Mariehamn	ALA	11521	\N	t
4130	King Edward Point	SGS	9	\N	t
4131	Camp Justice	IOT	3200	\N	t
\.


--
-- Name: city2_c_id_seq; Type: SEQUENCE SET; Schema: sql101; Owner: avaczi
--

SELECT pg_catalog.setval('city2_c_id_seq', 4131, true);


--
-- Data for Name: country; Type: TABLE DATA; Schema: sql101; Owner: avaczi
--

COPY country (c_code3, c_name, c_code2, c_surface_area, c_local_name) FROM stdin;
AGO	Angola	AO	1246700	Angola
AIA	Anguilla	AI	96	Anguilla
ALB	Albania	AL	28748	Shqipëria
AND	Andorra	AD	468	Andorra
ARE	United Arab Emirates	AE	83600	Al-Imarat al-´Arabiya al-Muttahida
ARG	Argentina	AR	2780400	Argentina
ARM	Armenia	AM	29800	Hajastan
ASM	American Samoa	AS	199	Amerika Samoa
ATF	French Southern territories	TF	7780	Terres australes françaises
ATG	Antigua and Barbuda	AG	442	Antigua and Barbuda
AUS	Australia	AU	7741220	Australia
AUT	Austria	AT	83859	Österreich
AZE	Azerbaijan	AZ	86600	Azärbaycan
BDI	Burundi	BI	27834	Burundi/Uburundi
BEL	Belgium	BE	30518	België/Belgique
BEN	Benin	BJ	112622	Bénin
BFA	Burkina Faso	BF	274000	Burkina Faso
BGD	Bangladesh	BD	143998	Bangladesh
BGR	Bulgaria	BG	110994	Balgarija
BHR	Bahrain	BH	694	Al-Bahrayn
BHS	Bahamas	BS	13878	The Bahamas
BIH	Bosnia and Herzegovina	BA	51197	Bosna i Hercegovina
BLR	Belarus	BY	207600	Belarus
BLZ	Belize	BZ	22696	Belize
BMU	Bermuda	BM	53	Bermuda
BOL	Bolivia	BO	1098580	Bolivia
BRA	Brazil	BR	8547400	Brasil
BRB	Barbados	BB	430	Barbados
BRN	Brunei	BN	5765	Brunei Darussalam
BTN	Bhutan	BT	47000	Druk-Yul
BWA	Botswana	BW	581730	Botswana
CAF	Central African Republic	CF	622984	Centrafrique/Bê-Afrîka
CAN	Canada	CA	9970610	Canada
CCK	Cocos (Keeling) Islands	CC	14	Cocos (Keeling) Islands
CHE	Switzerland	CH	41284	Schweiz/Suisse/Svizzera/Svizra
CHL	Chile	CL	756626	Chile
CHN	China	CN	9572900	Zhongquo
CMR	Cameroon	CM	475442	Cameroun/Cameroon
COG	Congo	CG	342000	Congo
COK	Cook Islands	CK	236	The Cook Islands
COL	Colombia	CO	1138910	Colombia
COM	Comoros	KM	1862	Komori/Comores
CPV	Cape Verde	CV	4033	Cabo Verde
CRI	Costa Rica	CR	51100	Costa Rica
CUB	Cuba	CU	110861	Cuba
AFG	Afghanistan	AF	652090	Afganistan/Afqanestan
CXR	Christmas Island	CX	135	Christmas Island
CYM	Cayman Islands	KY	264	Cayman Islands
CYP	Cyprus	CY	9251	Kýpros/Kibris
CZE	Czech Republic	CZ	78866	¸esko
DEU	Germany	DE	357022	Deutschland
DJI	Djibouti	DJ	23200	Djibouti/Jibuti
DMA	Dominica	DM	751	Dominica
DNK	Denmark	DK	43094	Danmark
DOM	Dominican Republic	DO	48511	República Dominicana
DZA	Algeria	DZ	2381740	Al-Jaza’ir/Algérie
ECU	Ecuador	EC	283561	Ecuador
EGY	Egypt	EG	1001450	Misr
ERI	Eritrea	ER	117600	Ertra
ESH	Western Sahara	EH	266000	As-Sahrawiya
ESP	Spain	ES	505992	España
EST	Estonia	EE	45227	Eesti
ETH	Ethiopia	ET	1104300	YeItyop´iya
FIN	Finland	FI	338145	Suomi
FLK	Falkland Islands	FK	12173	Falkland Islands
FRA	France	FR	551500	France
FRO	Faroe Islands	FO	1399	Føroyar
GAB	Gabon	GA	267668	Le Gabon
GBR	United Kingdom	GB	242900	United Kingdom
GEO	Georgia	GE	69700	Sakartvelo
GHA	Ghana	GH	238533	Ghana
GIB	Gibraltar	GI	6	Gibraltar
GIN	Guinea	GN	245857	Guinée
GLP	Guadeloupe	GP	1705	Guadeloupe
GMB	Gambia	GM	11295	The Gambia
GNB	Guinea-Bissau	GW	36125	Guiné-Bissau
GNQ	Equatorial Guinea	GQ	28051	Guinea Ecuatorial
GRC	Greece	GR	131626	Elláda
GRD	Grenada	GD	344	Grenada
GRL	Greenland	GL	2166090	Kalaallit Nunaat/Grønland
GTM	Guatemala	GT	108889	Guatemala
GUF	French Guiana	GF	90000	Guyane française
GUM	Guam	GU	549	Guam
GUY	Guyana	GY	214969	Guyana
HKG	Hong Kong	HK	1075	Xianggang/Hong Kong
HND	Honduras	HN	112088	Honduras
HRV	Croatia	HR	56538	Hrvatska
HTI	Haiti	HT	27750	Haïti/Dayti
HUN	Hungary	HU	93030	Magyarország
IDN	Indonesia	ID	1904570	Indonesia
IND	India	IN	3287260	Bharat/India
IOT	British Indian Ocean Territory	IO	78	British Indian Ocean Territory
IRL	Ireland	IE	70273	Ireland/Éire
IRN	Iran	IR	1648200	Iran
IRQ	Iraq	IQ	438317	Al-´Iraq
ISL	Iceland	IS	103000	Ísland
ISR	Israel	IL	21056	Yisra’el/Isra’il
ITA	Italy	IT	301316	Italia
JAM	Jamaica	JM	10990	Jamaica
JOR	Jordan	JO	88946	Al-Urdunn
JPN	Japan	JP	377829	Nihon/Nippon
KEN	Kenya	KE	580367	Kenya
KGZ	Kyrgyzstan	KG	199900	Kyrgyzstan
KHM	Cambodia	KH	181035	Kâmpuchéa
KIR	Kiribati	KI	726	Kiribati
KNA	Saint Kitts and Nevis	KN	261	Saint Kitts and Nevis
KOR	South Korea	KR	99434	Taehan Min’guk (Namhan)
KWT	Kuwait	KW	17818	Al-Kuwayt
LAO	Laos	LA	236800	Lao
CIV	Côte d'Ivoire	CI	322463	Côte d’Ivoire
KAZ	Kazakhstan	KZ	2724900	Qazaqstan
FJI	Fiji	FJ	18274	Fiji Islands
FSM	Federated States of Micronesia	FM	702	Micronesia
COD	Democratic Republic of the Congo	CD	2344860	République Démocratique du Congo
LBN	Lebanon	LB	10400	Lubnan
LBR	Liberia	LR	111369	Liberia
LCA	Saint Lucia	LC	622	Saint Lucia
LIE	Liechtenstein	LI	160	Liechtenstein
LKA	Sri Lanka	LK	65610	Sri Lanka/Ilankai
LSO	Lesotho	LS	30355	Lesotho
LTU	Lithuania	LT	65301	Lietuva
LUX	Luxembourg	LU	2586	Luxembourg/Lëtzebuerg
LVA	Latvia	LV	64589	Latvija
MAC	Macao	MO	18	Macau/Aomen
MAR	Morocco	MA	446550	Al-Maghrib
MCO	Monaco	MC	1.5	Monaco
MDA	Moldova	MD	33851	Moldova
MDG	Madagascar	MG	587041	Madagasikara/Madagascar
MDV	Maldives	MV	298	Dhivehi Raajje/Maldives
MEX	Mexico	MX	1958200	México
MHL	Marshall Islands	MH	181	Marshall Islands/Majol
MKD	Macedonia	MK	25713	Makedonija
MLI	Mali	ML	1240190	Mali
MLT	Malta	MT	316	Malta
MMR	Myanmar	MM	676578	Myanma Pye
MNG	Mongolia	MN	1566500	Mongol Uls
MNP	Northern Mariana Islands	MP	464	Northern Mariana Islands
MOZ	Mozambique	MZ	801590	Moçambique
MRT	Mauritania	MR	1025520	Muritaniya/Mauritanie
MSR	Montserrat	MS	102	Montserrat
MTQ	Martinique	MQ	1102	Martinique
MUS	Mauritius	MU	2040	Mauritius
MWI	Malawi	MW	118484	Malawi
MYS	Malaysia	MY	329758	Malaysia
MYT	Mayotte	YT	373	Mayotte
NAM	Namibia	NA	824292	Namibia
NCL	New Caledonia	NC	18575	Nouvelle-Calédonie
NER	Niger	NE	1267000	Niger
NFK	Norfolk Island	NF	36	Norfolk Island
NGA	Nigeria	NG	923768	Nigeria
NIC	Nicaragua	NI	130000	Nicaragua
NIU	Niue	NU	260	Niue
NLD	Netherlands	NL	41526	Nederland
NOR	Norway	NO	323877	Norge
NPL	Nepal	NP	147181	Nepal
NRU	Nauru	NR	21	Naoero/Nauru
NZL	New Zealand	NZ	270534	New Zealand/Aotearoa
OMN	Oman	OM	309500	´Uman
PAK	Pakistan	PK	796095	Pakistan
PAN	Panama	PA	75517	Panamá
PCN	Pitcairn	PN	49	Pitcairn
PER	Peru	PE	1285220	Perú/Piruw
PHL	Philippines	PH	300000	Pilipinas
PLW	Palau	PW	459	Belau/Palau
PNG	Papua New Guinea	PG	462840	Papua New Guinea/Papua Niugini
POL	Poland	PL	323250	Polska
PRI	Puerto Rico	PR	8875	Puerto Rico
PRK	North Korea	KP	120538	Choson Minjujuui In´min Konghwaguk (Bukhan)
PRT	Portugal	PT	91982	Portugal
PRY	Paraguay	PY	406752	Paraguay
PSE	Palestine	PS	6257	Filastin
PYF	French Polynesia	PF	4000	Polynésie française
QAT	Qatar	QA	11000	Qatar
REU	Réunion	RE	2510	Réunion
RWA	Rwanda	RW	26338	Rwanda/Urwanda
SAU	Saudi Arabia	SA	2149690	Al-´Arabiya as-Sa´udiya
SDN	Sudan	SD	2505810	As-Sudan
SEN	Senegal	SN	196722	Sénégal/Sounougal
SGP	Singapore	SG	618	Singapore/Singapura/Xinjiapo/Singapur
SGS	South Georgia and the South Sandwich Islands	GS	3903	South Georgia and the South Sandwich Islands
SJM	Svalbard and Jan Mayen	SJ	62422	Svalbard og Jan Mayen
SLB	Solomon Islands	SB	28896	Solomon Islands
SLE	Sierra Leone	SL	71740	Sierra Leone
SLV	El Salvador	SV	21041	El Salvador
SMR	San Marino	SM	61	San Marino
SOM	Somalia	SO	637657	Soomaaliya
SPM	Saint Pierre and Miquelon	PM	242	Saint-Pierre-et-Miquelon
SUR	Suriname	SR	163265	Suriname
SVK	Slovakia	SK	49012	Slovensko
SVN	Slovenia	SI	20256	Slovenija
SWE	Sweden	SE	449964	Sverige
SWZ	Swaziland	SZ	17364	kaNgwane
SYC	Seychelles	SC	455	Sesel/Seychelles
SYR	Syria	SY	185180	Suriya
TCA	Turks and Caicos Islands	TC	430	The Turks and Caicos Islands
TCD	Chad	TD	1284000	Tchad/Tshad
TGO	Togo	TG	56785	Togo
THA	Thailand	TH	513115	Prathet Thai
TJK	Tajikistan	TJ	143100	Toçikiston
TKL	Tokelau	TK	12	Tokelau
TKM	Turkmenistan	TM	488100	Türkmenostan
TON	Tonga	TO	650	Tonga
TTO	Trinidad and Tobago	TT	5130	Trinidad and Tobago
TUN	Tunisia	TN	163610	Tunis/Tunisie
TUR	Turkey	TR	774815	Türkiye
TUV	Tuvalu	TV	26	Tuvalu
TWN	Taiwan	TW	36188	T’ai-wan
TZA	Tanzania	TZ	883749	Tanzania
UGA	Uganda	UG	241038	Uganda
UKR	Ukraine	UA	603700	Ukrajina
URY	Uruguay	UY	175016	Uruguay
USA	United States	US	9363520	United States
UZB	Uzbekistan	UZ	447400	Uzbekiston
VCT	Saint Vincent and the Grenadines	VC	388	Saint Vincent and the Grenadines
VEN	Venezuela	VE	912050	Venezuela
VNM	Vietnam	VN	331689	Viêt Nam
VUT	Vanuatu	VU	12189	Vanuatu
WLF	Wallis and Futuna	WF	200	Wallis-et-Futuna
WSM	Samoa	WS	2831	Samoa
YEM	Yemen	YE	527968	Al-Yaman
LBY	Libya	LY	1759540	Libiya
RUS	Russia	RU	17075400	Rossija
VIR	United States Virgin Islands	VI	347	Virgin Islands of the United States
VGB	British Virgin Islands	VG	151	British Virgin Islands
STP	São Tomé and Príncipe	ST	964	São Tomé e Príncipe
SHN	Saint Helena, Ascension and Tristan da Cunha	SH	314	Saint Helena
VAT	Vatican City	VA	0.4	Santa Sede/Città del Vaticano
ZAF	South Africa	ZA	1221040	South Africa
ZMB	Zambia	ZM	752618	Zambia
ZWE	Zimbabwe	ZW	390757	Zimbabwe
ABW	Aruba	AW	193	Aruba
MNE	Montenegro	\N	\N	\N
SRB	Serbia	\N	\N	\N
ROU	Romania	RO	238391	România
TLS	Timor-Leste	\N	14874	\N
ALA	Åland Islands	\N	\N	\N
BLM	Saint Barthélemy	\N	\N	\N
CUW	Curaçao	\N	\N	\N
GGY	Guernsey	\N	\N	\N
IMN	Isle of Man	\N	\N	\N
JEY	Jersey	\N	\N	\N
SSD	South Sudan	\N	\N	\N
SXM	Sint Maarten	\N	\N	\N
MAF	Saint Martin	\N	\N	\N
\.


--
-- Name: dropme; Type: SEQUENCE SET; Schema: sql101; Owner: avaczi
--

SELECT pg_catalog.setval('dropme', 4106, true);


--
-- Name: city2_pkey; Type: CONSTRAINT; Schema: sql101; Owner: avaczi
--

ALTER TABLE ONLY city
    ADD CONSTRAINT city2_pkey PRIMARY KEY (c_id);


--
-- Name: country_c_code3_key; Type: CONSTRAINT; Schema: sql101; Owner: avaczi
--

ALTER TABLE ONLY country
    ADD CONSTRAINT country_c_code3_key UNIQUE (c_code3);


--
-- Name: city2_c_country_code3_fkey; Type: FK CONSTRAINT; Schema: sql101; Owner: avaczi
--

ALTER TABLE ONLY city
    ADD CONSTRAINT city2_c_country_code3_fkey FOREIGN KEY (c_country_code3) REFERENCES country(c_code3);


--
-- PostgreSQL database dump complete
--

