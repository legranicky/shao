-- What is a relational database?  tables that might be in relations
-- What is a table?

/*
+------+------------+-------+-------+
| id   |    name    | code3 | code2 |
+======+============+=======+=======+
| 1    | Germany    | DEU   | DE    |
| 2    | Hungary    | HUN   | HU    |
| 3    | Ireland    | IRL   | IE    |
+------+------------+-------+-------+

Not a table:
+------+------------+-------+-------+
| id   |    name    | code3 | code2 |
+======+============+=======+=======+
| 1    | Germany    | DEU   | DE    |
| 2    | Hungary    | HUN   | HU    | highest point: Kékes, 1014 m |
| 3    | Ireland    | IRL   | IE    |
| 999  | Liberland  |
+------+------------+

also not a table:
+------+------------+-------+-------+----------------+
| id   |    name    | code3 | code2 | some_numbers   |
+======+============+=======+=======+================+
| 1    | Germany    | DEU   | DE    | 1              |
| 234  | Nauru      | NRU   | NR    | 71 | 90 | 9591 |
+------+------------+-------+-------+----+----+------+
*/

-- What is a query?
-- What is a statement?
    -- INSERT, UPDATE, DELETE, GRANT, SHOW etc.

-- simple queries
SELECT 1;  -- works like echo

-- there are more useful ones, too:
SELECT extract('week' FROM now());
SELECT CURRENT_DATE;

-- ex: how old are you (in days)?


-- queries against tables
\i database_20170419.sql -- or whichever way your client supports

SET search_path TO sql101, public;

SELECT * FROM country;  -- after FROM: a table, multiple tables, or anything that behaves like a table

-- eg. set returning function:
-- SELECT i::date FROM generate_series('2017-11-01', CURRENT_DATE, '1 day') AS t(i);

SELECT * FROM country LIMIT 3; -- LIMIT

-- why is this important?  there is no inherent order in a table. See:
-- UPDATE country SET population = population + 1 WHERE code = 'AFG'; and then repeat the previous: different results

SELECT * FROM country ORDER BY c_name LIMIT 3; -- ORDER BY

-- ex: last 5
SELECT * FROM country ORDER BY c_name DESC LIMIT 5;

-- add a column called c_uninteresting_fact to show the importance of _not_ using SELECT *

SELECT c_name, c_code2, c_code3 FROM ...;

SELECT count(*) FROM city; -- count()
-- SELECT count(9) FROM city; -- usually a constant also works, count(NULL) = 0, count(9) = 1

-- Q: count(*) vs LIMIT 3?
-- mention max(), min(), avg()

-- ex: return the (alphabetically) last city name (DESC LIMIT 1 or max())

SELECT c_name, c_country_code3 FROM city WHERE c_name = 'Szeged';

-- ex: return the number of cities named Berlin (count(*) ... WHERE 'Berlin')

-- which countries have at least one Berlin?
SELECT DISTINCT c_country_code3 FROM city WHERE c_name = 'Berlin'; -- DISTINCT

SELECT DISTINCT c_name, c_country_code3 FROM city WHERE c_name LIKE 'Berl_n'; -- LIKE
SELECT DISTINCT c_name, c_country_code3 FROM city WHERE c_name LIKE 'B%n';
-- ex: crosswords - find the cities whose names start with B, end in n and are 6 characters long (B____n)
-- which one has the funniest name?

-- mention AND and OR
-- ex: is there a Berlin in South Africa?
-- pick the code from country, then look for a Berlin in city (AND)

SELECT DISTINCT c_name, c_country_code3 FROM city WHERE c_name = 'Münster' OR c_name = 'Munster'; -- OR
-- vs
SELECT DISTINCT c_name, c_country_code3 FROM city WHERE c_name ~ 'M[uü]nster'; -- regexp
-- vs
SELECT c_name, c_country_code3 FROM city WHERE c_name IN ('Hannover', 'Hanover'); -- IN
-- equivalent to c_name = ANY(['Hannover', 'Hanover']_
-- many Hanovers omitted


-- A (random) city in India
SELECT city.c_name, c_population, c_local_name
  FROM city JOIN country ON c_country_code3 = c_code3
 WHERE country.c_name = 'India'
 LIMIT 1; -- JOIN

-- ex: find the 10 biggest cities in Indonesia
-- SELECT city.c_name, c_population, c_local_name
--   FROM city JOIN country ON c_country_code3 = c_code3
--  WHERE country.c_name = 'Indonesia'
--  ORDER BY c_population DESC
--  LIMIT 10;

SELECT count(*) FROM country;
SELECT count(*) FROM city WHERE c_is_capital;

-- find the countries without a capital: LEFT JOIN -> explain JOIN types
SELECT country.c_name, c_code3
FROM country LEFT JOIN city ON c_code3 = c_country_code3 AND c_is_capital
WHERE city.c_id IS NULL
ORDER BY c_code3; -- LEFT JOIN

-- ex: find countries with no city at all
/*
SELECT country.c_name, c_code3
FROM country LEFT JOIN city ON c_code3 = c_country_code3
WHERE city.c_id IS NULL
ORDER BY c_code3;
*/

-- oops, Antarctica is not a country
-- and Bonaire, Sint Eustatius and Saba also not anymore
-- oh, and Bouvet Island, and Heard Island and McDonald Islands, and United States Minor Outlying Islands
DELETE FROM country WHERE c_code3 = ANY('{ATA, BES, BVT, HMD}'); -- just another way of saying IN()

-- BEGIN; DELETE ... /* without WHERE */; ROLLBACK / COMMIT;
-- ex: DELETE United States Minor Outlying Islands DELETE FROM country WHERE c_code3 = 'UMI';

-- and Macedonia has no capital?  For sure it has:
UPDATE city SET c_is_capital = TRUE WHERE c_name = 'Skopje';

-- be careful with the conditions on LEFT JOIN:
SELECT country.c_name, c_code3
  FROM country LEFT JOIN city ON c_code3 = c_country_code3
 WHERE city.c_id IS NULL AND c_is_capital
 ORDER BY c_code3;

-- How many capitals does a country have? 0 or 1 we already now, but...
-- count the capitals per country.  Here we have to be very specific about what to count
SELECT country.c_name, count(city.c_id) AS number_of_capitals -- here count(9) won't work: explain it
  FROM country LEFT JOIN city ON c_code3 = c_country_code3 AND c_is_capital
 GROUP BY country.c_name
 ORDER BY number_of_capitals DESC, country.c_name; -- GROUP BY

