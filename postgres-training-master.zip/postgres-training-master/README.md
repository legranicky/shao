Introduction
============
This repository contains training material from the ACID team.

Some of these trainings are available as workshops at: (Available only from within Zalando)

* [https://acid-training-app.acid.zalan.do/](https://acid-training-app.acid.zalan.do/)
 
Prerequisites
============

Please read carefully the prerequisites for each course.
It is a matter of respect to other participants to ensure the prerequisites before the training starts.

Topics
======
 
SQL 101
----------
 
Introduction into PostgreSQL some elements are:

* Installing PostgreSQL locally
* Connecting to a database
* Restore a demo database
* Execute basic SQL queries
* Joins
* Grouping
 
SQL Intermediate
-----------------

Participants should have the knowledge covered by SQL 101.

* Grouping
* Having Clause
* Window functions
* Indexes
* Sorting using indexes
* Understanding Explain Command
* CTE

SProc Wrapper
-------------

Goal: participant shall be able to write sproc in plgpsql and call them from Java application via sproc wrapper.

PostgreSQL Advanced
-------------

Participants should have the knowledge covered by SQL Intermediate.

- HOT Updates
- Row header information
- MVCC, Vacuum
- Order by and work\_mem setting
- Privileges
- Background Writer
 
SQL Deploy
----------------

It is recommended that participants have attended the PostgreSQL Advanced course.

1. Review dbdiffs
    - Risks of Schema changes in a running application
    - (locks, pg\_catalog, implicit Scans [add foreign key, add column])
    - `_v` schema
 
1. Tooling for db deployer
    - scmup,
    - get\_db\_diffs.py
    - niceupdate
 
1. Analysis
    - pg_view
    - pg_taillog
    - logimporter.py
    - pgbadger
    - Pgobserver
 
DB Administration
---------------------

**Participants** should bring their laptop which has psql, db-utils, python, git, ssh installed.
They should ensure that they have access to [CMDB]( https://cmdb.zalando.net ).
They should have passed the DB-Deployer Training already.

This will be a hands on Session where paritipants will create a Postgres HA cluster
using the Zalando tooling. During this setup we will discuss the following topics:

1. System configuration
    - initialize database
    - folder struture
    - pg\_warm\_standby.py
    - checkpoints
    - shared buffers
    - ssl
    - Mountpoints in GTH/ITR
 
1. Configuration Management
    - config.yml
    - DDS
    - crontab
    - postgres.conf
 
1. Cluster management
    - Service IP
    - Routing and iptables in ITR
    - WAL shipping Flow
    - Backup
    - Monitoring
 
 
Miscellanea
===========
    1. From Tino:
        - transaction handling (what really happens under the hood especially what memory/load it may cost)
        - what really does a join - risk of swap out memory
        - how to review dbdiff
        - how to create proper rollback dbdiff
        - how to rollout dbdiff/test if they are already out
        - what permissions/roles are needed for what (API, dbdiff, write, read, basic reader etc.)
        - how to read an explain of a query and how to optimize
        - best practice at fetching data over a lot of tables (conditions at join versus in where etc.)
        - how to use DB Observer
        - which tooling around databases is available (pg_view, db-describe, etc.)
      all of which boils down to 3 main categories:
        - db deployment
        - advanced SQL/query tuning
        - monitoring & tooling
    2. From Ingo Weinzierl:
        - monitoring
    3. From Martin Schmidt:
        - monitoring
        - An alltime-topic is also statement and sproc performance. Very often one can still find sprocs which can be tuned from seconds to milliseconds with tiny changes...
 
* To balance „really need for daily work“ versus „cool a training, do not have to work 
  on other stuff“ I would prefer to give this kind of personal development to the 
  people leads - means give them a kind of contingent and they may make the decision 
  who will be „first come“ and who will be part of this training in 2nd or 3rd round.
  (from Tino)
