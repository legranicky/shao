Description
============

This talk describes non-conventional optimization techniques,
that generally apply even to the cases when the database is
running with up-to-date statistics and all indexes in place.

The contents of this talk is the interactive SQL file that
should be executed with psql against a non-production DB:

    psql -d postgres -f script.sql -e

