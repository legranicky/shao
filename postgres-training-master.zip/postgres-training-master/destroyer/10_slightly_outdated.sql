CREATE TABLE slightly_outdated (
    so_id serial PRIMARY KEY,
    so_outdatedness_type varchar(32),
    so_important_column text
);

INSERT INTO slightly_outdated (so_outdatedness_type, so_important_column)
SELECT CASE i % 10 WHEN 3 THEN 'flash' WHEN 5 THEN 'bang' ELSE 'boom' END, md5(i::text)
FROM generate_series(1, 100000) t (i);

-- add FK
-- add an active flag (NOT NULL, default true)
-- change so_outdatedness_type to an ENUM (uppercase)
