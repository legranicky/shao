## Rights to get
<ul>
<li class="fragment">apply for DBDiff-Approver in [ZACK](https://access.zalando.net/) for all projects of yours<br />
                     <span style="font-size: 60%;">(or the overarching role of your team that comprises the above)
</li>
<li class="fragment">you get DB ownership</li>
<li class="fragment">... but no CREATE ROLE</li>
</ul>



## Diffs
### scope
<ul>
<li class="fragment">[config diffs](https://db-diff-review.zalando/)</li>
<li class="fragment">structure-changing DB diffs</li>
<li class="fragment">data(-only) diffs</li>
<li class="fragment">migration scripts (YAML for niceupdate)</li>
</ul>


## Diffs
### timing
<ul>
<li class="fragment">normal (pre-API)</li>
<li class="fragment">post-API</li>
<li class="fragment">postdeploy</li>
</ul>



## DB diffs
<ul>
<li class="fragment">add new objects (types, tables, ...)</li>
<li class="fragment">modify existing ones</li>
<li class="fragment">add new data (configuration, for example)</li>
<li class="fragment">modify existing data (to match logic changes)</li>
</ul>


## Anatomy of a DB diff
    BEGIN;
        SELECT _v.register_patch('ACID-1234.eventlog');
        SELECT zz_utils.set_project_schema_owner_role('zel_data');
        -- ^^ new edition of SET ROLE TO zalando; ^^

        -- the body of the diff

    COMMIT;

    -- and some non-transactional elements come after the COMMIT;


## Non-transactional what?
<ul>
<li class="fragment">`ALTER TYPE`</span>
<li class="fragment">`CREATE (DROP) INDEX `<span class="important" style="font-size:100%">&nbsp;`CONCURRENTLY`</span></span>
<li class="fragment">`VACUUM`</span>
</ul>



## Review
[DBDiff Review Tool](https://db-diff-review.zalando)

<div class="fragment">What to look for?</div>
<ul>
<li class="fragment">coding standards</li>
<li class="fragment">best practices</li>
<li class="fragment">readability/self-explanatoriness</li>
<li class="fragment">design decisions (type choice, data model and so on)</li>
<li class="fragment">existence of included files</li>
</ul>
<div class="fragment" data-autoslide="2000">
    <span class="important">AND...</span>
</div>


## RISKS

<ul>
<li class="fragment">transactions too long</li>
<li class="fragment">breaking the API</li>
<li class="fragment">breaking the deployment</li>
</ul>


## <span class="important" style="font-size: 100%">RISKS</span>
### transactions too long
<ul>
<li class="fragment">`ADD COLUMN ... DEFAULT ...`</li>
<li class="fragment">big updates</li>
<li class="fragment">foreign key on column with data</li>
<li class="fragment">`CREATE INDEX`</li>
</ul>

Note:

fire up pg_view and BEGIN; ALTER TABLE b ALTER COLUMN id SET NOT NULL;
for i in {1..2}; do sleep 2; (psql -h dbhost -d test -c "INSERT INTO b VALUES (0)" &) ; done
dbhost=foobar.acid.staging.db.zalan.do
i=1
while [ 1 -eq 1 ]; do
    sleep 3
    (psql -h $dbhost -d destroyer -c "INSERT INTO dest.something VALUES ($i)" &)
    ((i++))
done


## <span class="important" style="font-size: 100%">RISKS</span>
### breaking the API
<ul>
<li class="fragment">`ALTER COLUMN ... TYPE ...`</li>
<li class="fragment">`DROP TABLE`</li>
<li class="fragment">`DROP COLUMN`</li>
<li class="fragment">renaming things</li>
<li class="fragment">introducing new constraint against the will of the sprocs</li>
</ul>


## <span class="important" style="font-size: 100%">RISKS</span>
### breaking the deployment
<ul>
<li class="fragment">trying to roll out something that has (syntax) errors</li>
<li class="fragment">constraint on data that do not match</li>
</ul>



## Tools for DB diff rollout
* db-utils repo: https://github.bus.zalan.do/acid/db-utils
  * scmup.py
  * get_db_diffs.py



## API deployment
* deploy tool



## Monitoring
<ul>
<li class="fragment">pg_view</li>
<li class="fragment">pg_taillog</li>
<li class="fragment">[PGObserver](https://pgobserver.zalando.net/)</li>
</ul>



## Links
#### Guidelines, best practices
<ul class="listed-links">
  <li>https://techwiki.zalando.net/display/DT/Golden+Rules+of+database+development</li>
  <li>https://techwiki.zalando.net/display/DT/Database+logging+guidelines</li>
  <li>https://techwiki.zalando.net/display/DT/Data+migration</li>
  <li>https://techwiki.zalando.net/display/DT/About+indexes</li>
</ul>

#### Google group
<ul class="listed-links">
  <li>https://groups.google.com/a/zalando.de/forum/#!forum/zooport-elephant</li>
</ul>

#### Hipchat
<ul class="listed-links">
  <li>#guild-Databases <span class="note">(general discussion)</span></li>
  <li>#Elephant <span class="note">(problems, tasks)</span></li>
</ul>


## Links
#### demo SQL files:
<ul class="listed-links">
  <li>https://github.bus.zalan.do/acid/postgres-training/blob/master/destroyer/alter_table_default.sql</li>
  <li>https://github.bus.zalan.do/acid/postgres-training/blob/master/destroyer/foreign_key.sql</li>
  <li>https://github.bus.zalan.do/acid/postgres-training/blob/master/destroyer/10_slightly_outdated.sql</li>
</ul>
