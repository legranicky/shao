DROP SCHEMA IF EXISTS deployer CASCADE;
CREATE SCHEMA deployer;
SET search_path TO deployer;

\set ECHO queries

CREATE TABLE give_me_rows (
    gmr_id integer PRIMARY KEY,
    gmr_name text
);

INSERT INTO give_me_rows (gmr_id, gmr_name)
SELECT i, 'here_you_are' || i::text
  FROM generate_series(1, 1000000) t(i);

\prompt '########################### let''s see some of it ############################' dummy

SELECT * FROM give_me_rows LIMIT 10;

\prompt '########################### let''s add a new column with a default ############################' dummy
BEGIN;

    ALTER TABLE give_me_rows
      ADD COLUMN gmr_is_active boolean NOT NULL DEFAULT TRUE;

    \prompt '########################### what do we find in there? ############################' dummy

    SELECT * FROM give_me_rows LIMIT 10;

    \prompt '########################### rollback ###########################' dummy

ROLLBACK;

    \prompt '########################### now let''s do it properly ############################' dummy


BEGIN;

    ALTER TABLE give_me_rows
      ADD COLUMN gmr_is_active boolean;

    ALTER TABLE give_me_rows
      ALTER COLUMN gmr_is_active SET DEFAULT TRUE;

COMMIT;

SELECT * FROM give_me_rows LIMIT 10;
\prompt '########################### and after the COMMIT ############################' dummy

UPDATE give_me_rows
   SET gmr_is_active = TRUE
 WHERE gmr_is_active IS NULL;

ALTER TABLE give_me_rows
  ALTER COLUMN gmr_is_active SET NOT NULL;
