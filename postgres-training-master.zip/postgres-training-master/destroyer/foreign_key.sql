\set ECHO queries

CREATE TABLE this_depends (
    td_id serial PRIMARY KEY,
    td_data text
);

INSERT INTO this_depends (td_data)
SELECT 'data_' || i::text
  FROM generate_series(1, 1000000) t(i);

\prompt '########################### let''s create a foreign key to it ############################' dummy

BEGIN;

    ALTER TABLE give_me_rows
      ADD COLUMN this_depends_id integer REFERENCES this_depends (td_id);

    \d give_me_rows

    \prompt '########################### that was fast ############################' dummy

ROLLBACK;

BEGIN;

    ALTER TABLE give_me_rows
      ADD COLUMN this_depends_id integer;

    UPDATE give_me_rows
       SET this_depends_id = gmr_id;

    ALTER TABLE give_me_rows
      ADD FOREIGN KEY (this_depends_id) REFERENCES this_depends (td_id);

    \prompt '########################### that took too long ############################' dummy

ROLLBACK;
