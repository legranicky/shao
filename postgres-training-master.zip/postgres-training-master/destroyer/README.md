# DB Deployer Training

(Nearly) everything that is needed for reviewing and rolling out 
DB diffs and deploying API schemas

**The trainer** should send the following links to the **participants** 
a few days before the class:

Documentation
-------------

<!-- - https://techwiki.zalando.net/display/TECH/Database+Development+Guidelines
- https://techwiki.zalando.net/display/TECH/Database+Change+Guidelines -->
- (some are gone from techwiki)
- https://techwiki.zalando.net/display/DT/Data+migration

GUI tools
---------

- https://db-diff-review.zalando/
- http://pgobserver.zalando.net/
